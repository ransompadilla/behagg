-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2018 at 05:53 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `livestock`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_for_livestock`
--

CREATE TABLE `category_for_livestock` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(35) NOT NULL,
  `cat_description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_for_livestock`
--

INSERT INTO `category_for_livestock` (`cat_id`, `cat_name`, `cat_description`) VALUES
(1, 'Piggery', 'Piggery'),
(2, 'Poultry', 'Poultry');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `delivery_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `delivery_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `google_users`
--

CREATE TABLE `google_users` (
  `id` int(11) NOT NULL,
  `oauth_provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `picture_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profile_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `livestock_category`
--

CREATE TABLE `livestock_category` (
  `livestock_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `cat_img` text NOT NULL,
  `rate` decimal(11,2) NOT NULL,
  `rate_by` varchar(15) NOT NULL COMMENT '''day'', ''week'',''month''',
  `supp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `livestock_category`
--

INSERT INTO `livestock_category` (`livestock_id`, `cat_id`, `cat_img`, `rate`, `rate_by`, `supp_id`) VALUES
(3, 1, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0ros180830124634.jpg\";}}', '450.00', 'month', 8),
(4, 2, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0ros180901054652.PNG\";}}', '120.00', 'pcs', 8),
(5, 1, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180905043205.png\";}}', '3000.00', 'month', 7),
(6, 2, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180905043325.PNG\";}}', '80.00', 'month', 7),
(7, 2, 'a:1:{s:6:\"images\";s:0:\"\";}', '300.00', 'month', 8),
(8, 2, 'a:1:{s:6:\"images\";s:0:\"\";}', '400.00', 'month', 8),
(9, 2, 'a:1:{s:6:\"images\";s:0:\"\";}', '200.00', 'week', 8),
(10, 1, 'a:1:{s:6:\"images\";s:0:\"\";}', '5600.00', 'month', 8),
(11, 1, 'a:1:{s:6:\"images\";s:0:\"\";}', '20.00', 'week', 2),
(12, 2, 'a:1:{s:6:\"images\";s:0:\"\";}', '0.00', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` enum('0','1','','') NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seen` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from`, `to`, `message`, `is_read`, `time`, `seen`) VALUES
(1, 3, 1, '0', '0', '2018-06-26 05:03:31', 4),
(2, 3, 1, '0', '0', '2018-06-26 05:03:50', 4),
(3, 4, 3, '0', '1', '2018-06-26 05:07:17', 3),
(4, 3, 4, 'hey', '1', '2018-06-26 05:08:27', 4),
(5, 3, 4, 'whhaha', '1', '2018-06-26 05:08:57', 4),
(6, 3, 4, 'sdfdf', '1', '2018-06-26 05:11:13', 4),
(7, 3, 4, 'dsfdf', '1', '2018-06-26 05:11:27', 4),
(8, 3, 4, 'sdfdf', '1', '2018-06-26 05:20:23', 4),
(9, 3, 4, 'we', '1', '2018-06-26 05:22:09', 4),
(10, 3, 4, 'sdfdf', '1', '2018-06-26 05:22:50', 4),
(11, 3, 4, 'fdfdf', '1', '2018-06-26 05:23:29', 4),
(12, 3, 4, 'boom', '1', '2018-06-26 05:24:21', 4),
(13, 3, 4, 'sdf', '1', '2018-06-26 05:40:05', 4),
(14, 3, 4, 'yoy', '1', '2018-06-26 05:40:27', 4),
(15, 3, 4, 'dsfdf', '1', '2018-06-26 05:40:31', 4),
(16, 3, 4, 'erer', '1', '2018-06-26 05:40:44', 4),
(17, 3, 4, 'hhhh', '1', '2018-06-26 05:41:02', 4),
(18, 3, 4, 'erer', '1', '2018-06-26 05:41:46', 4),
(19, 3, 4, 'ggg', '1', '2018-06-26 05:41:51', 4),
(20, 3, 4, 'erer', '1', '2018-06-26 05:41:59', 4),
(21, 3, 4, 'yow', '1', '2018-06-26 05:42:23', 4),
(22, 4, 3, 'hey', '1', '2018-06-26 05:42:32', 3),
(23, 4, 3, 'how are you ?', '1', '2018-06-26 05:42:54', 3),
(24, 4, 3, 'hey', '1', '2018-06-26 05:44:22', 3),
(25, 4, 3, 'yow', '1', '2018-06-26 05:44:40', 3),
(26, 4, 3, 'yowoy', '1', '2018-06-26 05:44:52', 3),
(27, 4, 3, 'wow', '1', '2018-06-26 05:45:05', 3),
(28, 4, 3, 'wow', '1', '2018-06-26 05:45:08', 3),
(29, 4, 3, 'mwmwer', '1', '2018-06-26 05:45:19', 3),
(30, 4, 3, 'hey', '1', '2018-06-26 05:46:15', 3),
(31, 4, 3, 'yow', '1', '2018-06-26 05:46:31', 3),
(32, 4, 3, 'boompanes', '1', '2018-06-26 05:47:34', 3),
(33, 4, 3, 'how are you', '1', '2018-06-26 05:47:49', 3),
(34, 4, 3, 'are you okey ?', '1', '2018-06-26 05:47:58', 3),
(35, 4, 3, 'hey', '1', '2018-06-26 05:49:46', 3),
(36, 4, 3, 'yow', '1', '2018-06-26 05:51:43', 3),
(37, 4, 3, 'yow are you okey ?', '1', '2018-06-26 05:51:51', 3),
(38, 4, 3, 'ahha', '1', '2018-06-26 05:53:26', 3),
(39, 4, 3, 'ngano man ka ?', '1', '2018-06-26 05:53:33', 3),
(40, 4, 3, 'asa ka ?', '1', '2018-06-26 05:53:38', 3),
(41, 4, 3, 'ngano man ka ?', '1', '2018-06-26 05:54:02', 3),
(42, 4, 3, 'gaunsa ka ?', '1', '2018-06-26 05:55:27', 3),
(43, 4, 3, 'ha?', '1', '2018-06-26 05:55:44', 3),
(44, 3, 4, 'hey', '1', '2018-06-26 05:58:25', 4),
(45, 3, 4, 'yow', '1', '2018-06-26 05:59:38', 4),
(46, 4, 3, 'gaunsa ka ?', '1', '2018-06-26 05:59:49', 3),
(47, 3, 4, 'hey', '1', '2018-06-26 06:00:41', 4),
(48, 3, 4, 'yow', '1', '2018-06-26 06:03:11', 4),
(49, 3, 4, 'how', '1', '2018-06-26 06:04:13', 4),
(50, 4, 3, 'dekarabaw', '1', '2018-06-26 06:04:25', 3),
(51, 3, 0, '', '0', '2018-06-26 06:08:17', 4),
(52, 3, 4, 'hey', '1', '2018-06-26 06:13:27', 4),
(53, 3, 4, 'yow', '1', '2018-06-26 06:23:36', 4),
(54, 3, 4, 'hoe', '1', '2018-06-26 06:25:11', 4),
(55, 4, 3, 'nag unsa ka ?', '1', '2018-06-26 06:25:22', 3),
(56, 3, 4, 'hey', '1', '2018-06-26 06:26:43', 4),
(57, 3, 4, 'yow', '1', '2018-06-26 06:28:04', 4),
(58, 3, 4, 'oy', '1', '2018-06-26 06:29:40', 4),
(59, 4, 3, 'unsa man', '1', '2018-06-26 06:29:47', 3),
(60, 3, 4, 'ha?', '1', '2018-06-26 06:30:36', 4),
(61, 3, 4, 'erer', '1', '2018-06-26 06:32:25', 4),
(62, 3, 4, 'yow', '1', '2018-06-26 06:32:47', 4),
(63, 4, 3, 'gey', '1', '2018-06-26 06:32:53', 3),
(64, 3, 4, 'ha?', '1', '2018-06-26 06:33:29', 4),
(65, 4, 3, 'errer', '1', '2018-06-26 06:34:19', 3),
(66, 3, 4, 'hey', '1', '2018-06-26 06:35:19', 4),
(67, 3, 4, 'oye', '1', '2018-06-26 06:41:25', 4),
(68, 3, 4, 'erer', '1', '2018-06-26 06:43:16', 4),
(69, 3, 4, 'erer', '1', '2018-06-26 06:43:16', 4),
(70, 3, 4, 'boom', '1', '2018-06-26 06:46:40', 4),
(71, 4, 3, 'wla gyud', '1', '2018-06-26 06:46:48', 3),
(72, 3, 4, 'yot', '1', '2018-06-26 06:47:45', 4),
(73, 3, 4, 'gaunsa kayot ?', '1', '2018-06-26 06:47:52', 4),
(74, 4, 3, 'wla ra yot', '1', '2018-06-26 06:47:55', 3),
(75, 3, 4, 'hasol', '1', '2018-06-26 06:50:30', 4),
(76, 3, 4, 'naunsa na ?', '1', '2018-06-26 06:50:40', 4),
(77, 4, 3, 'hahha', '1', '2018-06-26 06:50:48', 3),
(78, 3, 4, 'ngano mani', '1', '2018-06-26 06:50:55', 4),
(79, 4, 3, 'buanga', '1', '2018-06-26 06:51:02', 3),
(80, 3, 3, 'ngano ka oy', '1', '2018-06-26 06:51:51', 3),
(81, 4, 3, 'wla raman', '1', '2018-06-26 06:51:56', 3),
(82, 3, 3, 'wla ma ngud', '1', '2018-06-26 06:52:24', 3),
(83, 3, 3, 'hahah', '1', '2018-06-26 06:52:32', 3),
(84, 3, 3, 'anyare', '1', '2018-06-26 06:54:57', 3),
(85, 3, 3, 'hye', '1', '2018-06-26 07:00:18', 3),
(86, 4, 3, 'gaunsa ka', '1', '2018-06-26 07:00:34', 3),
(87, 3, 3, 'wla raman', '1', '2018-06-26 07:01:22', 3),
(88, 4, 3, 'kinsa man nag ingon?', '1', '2018-06-26 07:01:43', 3),
(89, 3, 3, 'hoy', '1', '2018-06-26 07:26:32', 3),
(90, 3, 4, 'gaunsa ka?', '1', '2018-06-26 07:27:48', 4),
(91, 3, 3, 'hey', '1', '2018-06-26 07:32:16', 3),
(92, 4, 3, 'what ?', '1', '2018-06-26 07:35:32', 3),
(93, 3, 4, 'how are  ouy', '1', '2018-06-26 07:36:46', 4),
(94, 3, 4, 'what ?', '1', '2018-06-26 07:37:21', 4),
(95, 4, 3, 'ge', '1', '2018-06-26 07:38:13', 3),
(96, 3, 4, 'what', '1', '2018-06-26 07:39:36', 4),
(97, 3, 4, 'ngano ka ', '1', '2018-06-26 07:41:31', 4),
(98, 3, 4, 'sdf', '1', '2018-06-26 07:42:36', 4),
(99, 3, 4, 'g', '1', '2018-06-26 07:48:39', 4),
(100, 3, 4, 'wew', '1', '2018-06-26 07:51:06', 4),
(101, 4, 3, 'ngano man ni oy', '1', '2018-06-26 07:51:28', 3),
(102, 3, 4, 'naubang na', '1', '2018-06-26 07:51:36', 4),
(103, 4, 3, 'unsa ?', '1', '2018-06-26 07:51:52', 3),
(104, 3, 4, 'ang unsa man ?', '1', '2018-06-26 07:52:04', 4),
(105, 4, 3, 'kan kinsa man na\\', '1', '2018-06-26 07:52:18', 3),
(106, 3, 4, 'sure dh aoy ?', '1', '2018-06-26 07:52:27', 4),
(107, 4, 3, 'unsa ka ?', '1', '2018-06-26 07:52:33', 3),
(108, 4, 3, 'wla oyy', '1', '2018-06-26 07:53:30', 3),
(109, 3, 4, 'nag unsa ka miss', '1', '2018-06-26 07:55:39', 4),
(110, 4, 3, 'ngano naman sad ka ?', '1', '2018-06-26 07:55:56', 3),
(111, 4, 3, 'nako', '1', '2018-06-26 07:57:42', 3),
(112, 3, 4, 'anyare', '1', '2018-06-26 07:57:49', 4),
(113, 4, 3, 'iwan ko b', '1', '2018-06-26 07:57:57', 3),
(114, 3, 4, 'bakit ka nag ka ganyan', '1', '2018-06-26 07:58:05', 4),
(115, 4, 3, 'hey', '1', '2018-06-26 07:59:24', 3),
(116, 3, 4, 'ha?', '1', '2018-06-26 07:59:31', 4),
(117, 3, 4, '', '1', '2018-06-26 07:59:46', 4),
(118, 4, 3, 'hsahsh', '1', '2018-06-26 07:59:52', 3),
(119, 3, 4, 'dsdsds', '1', '2018-06-26 07:59:57', 4),
(120, 4, 3, '', '1', '2018-06-26 08:00:10', 3),
(121, 3, 4, '', '1', '2018-06-26 08:00:17', 4),
(122, 4, 3, 'hello', '1', '2018-06-26 08:00:22', 3),
(123, 4, 3, '', '1', '2018-06-26 08:00:32', 3),
(124, 4, 3, 'hey yow', '1', '2018-06-28 05:37:23', 3),
(125, 3, 4, 'hey men', '1', '2018-06-28 05:38:14', 4),
(126, 3, 4, 'how are you ?', '1', '2018-06-28 05:38:22', 4),
(127, 4, 3, 'im fine thankyou !', '1', '2018-06-28 05:38:33', 3),
(128, 4, 3, 'hiw', '1', '2018-06-28 05:44:28', 3),
(129, 3, 4, 'hiwe', '1', '2018-06-28 05:44:35', 4),
(130, 4, 3, 'waht', '1', '2018-06-28 05:44:41', 3),
(131, 4, 3, 'whattt', '1', '2018-06-28 05:45:04', 3),
(132, 3, 4, 'jejeje', '1', '2018-06-28 05:45:08', 4),
(133, 4, 3, 'gegeg', '1', '2018-06-28 08:33:09', 3),
(134, 4, 3, 'hey yow!', '1', '2018-06-28 08:33:30', 3),
(135, 4, 3, 'tedirt', '1', '2018-06-28 08:33:52', 3),
(136, 4, 3, 'ngano ni?', '1', '2018-06-28 08:34:03', 3),
(137, 4, 3, 'gege', '1', '2018-06-28 08:34:31', 3),
(138, 4, 3, 'gg kids', '1', '2018-06-28 08:35:43', 3),
(139, 4, 3, 'hey', '1', '2018-06-28 08:41:37', 3),
(140, 4, 3, 'gege', '1', '2018-06-28 08:46:11', 3),
(141, 4, 3, 'hays', '1', '2018-06-28 08:46:55', 3),
(142, 4, 3, 'last', '1', '2018-06-28 08:47:24', 3),
(143, 4, 3, 'tangi', '1', '2018-06-28 08:48:56', 3),
(144, 4, 3, 'ngano ma nka?', '1', '2018-06-28 08:49:07', 3),
(145, 4, 3, 'gaga', '1', '2018-06-28 08:50:14', 3),
(146, 4, 3, '', '1', '2018-06-28 08:50:20', 3),
(147, 4, 3, 'wew', '1', '2018-06-28 08:50:38', 3),
(148, 4, 3, '', '1', '2018-06-28 08:50:45', 3),
(149, 4, 3, 'gey', '1', '2018-06-28 08:54:14', 3),
(150, 4, 3, 'ngao lageh', '1', '2018-06-28 08:54:59', 3),
(151, 4, 3, 'hey', '1', '2018-06-28 08:56:14', 3),
(152, 4, 3, 'gege', '1', '2018-06-28 08:57:40', 3),
(153, 4, 3, 'hay nako', '1', '2018-06-28 08:58:56', 3),
(154, 4, 3, 'atay', '1', '2018-06-28 08:59:17', 3),
(155, 4, 3, 'mao d ay', '1', '2018-06-28 08:59:24', 3),
(156, 3, 4, 'ngano man ka ?', '1', '2018-06-28 09:00:48', 4),
(157, 4, 3, 'wla man', '1', '2018-06-28 09:00:55', 3),
(158, 3, 4, 'sure oy ?', '1', '2018-06-28 09:01:08', 4),
(159, 4, 3, 'lageh', '1', '2018-06-28 09:01:27', 3),
(160, 3, 4, 'bantay bitaw', '1', '2018-06-28 09:03:11', 4),
(161, 4, 3, 'why ?', '1', '2018-06-28 09:03:58', 3),
(162, 3, 4, 'ha?', '1', '2018-06-28 09:07:21', 4),
(163, 4, 3, 'ho?', '1', '2018-06-28 09:07:51', 3),
(164, 3, 4, 'wa man', '1', '2018-06-28 09:07:59', 4),
(165, 4, 3, 'sure oy ?', '1', '2018-06-28 09:08:15', 3),
(166, 3, 4, 'lageh ?', '1', '2018-06-28 09:08:21', 4),
(167, 4, 3, 'we?', '1', '2018-06-28 09:11:37', 3),
(168, 3, 4, 'hey', '1', '2018-06-28 09:11:48', 4),
(169, 3, 4, 'hey', '1', '2018-06-28 09:11:51', 4),
(170, 4, 3, 'gg', '1', '2018-06-28 09:12:03', 3),
(171, 3, 4, 'ngano man ?', '1', '2018-06-28 09:12:10', 4),
(172, 4, 3, 'wla lang ', '1', '2018-06-28 09:23:29', 3),
(173, 3, 4, 'sure oy ?', '1', '2018-06-28 09:23:35', 4),
(174, 4, 3, 'lageh', '1', '2018-06-28 09:23:51', 3),
(175, 3, 4, 'bantay bitaw ?', '1', '2018-06-28 09:23:58', 4),
(176, 3, 4, 'hey', '1', '2018-06-28 09:26:52', 4),
(177, 4, 3, 'wahaha', '1', '2018-06-28 09:26:58', 3),
(178, 3, 4, 'ngano man na ?', '1', '2018-06-28 09:27:06', 4),
(179, 4, 3, 'typing message!', '1', '2018-06-28 09:27:14', 3),
(180, 3, 4, 'ngano mana !', '1', '2018-06-28 09:27:23', 4),
(181, 3, 4, 'how', '1', '2018-07-03 05:32:28', 4),
(182, 3, 4, 'gaunsa ka', '1', '2018-07-03 05:32:38', 4),
(183, 3, 4, 'yow', '1', '2018-07-06 05:58:25', 4),
(184, 3, 4, 'boom', '1', '2018-07-06 06:01:59', 4),
(185, 4, 3, 'hoy', '1', '2018-07-10 05:40:23', 3),
(186, 4, 3, 'NN', '1', '2018-07-10 05:40:36', 3),
(187, 4, 3, 'NNN', '1', '2018-07-10 05:44:58', 3),
(188, 3, 4, 'boom', '1', '2018-07-12 20:44:26', 4),
(189, 3, 4, 'hey', '1', '2018-07-27 06:07:36', 4),
(190, 4, 3, 'oy kumusta ?', '1', '2018-07-27 06:53:08', 3),
(191, 3, 4, 'okey ra ikaw ? ahaa', '1', '2018-07-27 06:56:06', 4),
(192, 4, 3, 'ok ra sad ^^', '1', '2018-07-27 06:56:49', 3),
(193, 3, 4, 'hahahha boom', '1', '2018-07-27 06:57:27', 4),
(194, 3, 4, 'hahah', '1', '2018-07-27 06:58:51', 4),
(195, 4, 3, 'bom panes', '1', '2018-07-27 06:59:14', 3),
(196, 3, 4, 'hahah', '1', '2018-07-27 07:02:10', 4),
(197, 4, 3, 'huhuhu', '1', '2018-07-27 07:08:46', 3),
(198, 3, 4, 'ngano man aka ?', '1', '2018-07-27 07:09:04', 4),
(199, 3, 4, 'wew', '1', '2018-08-14 03:34:43', 4),
(200, 4, 3, 'ha ?', '1', '2018-08-14 03:39:11', 3),
(201, 4, 3, 'haha', '1', '2018-08-14 05:50:57', 3),
(202, 4, 3, 'wew', '1', '2018-08-14 06:02:41', 3),
(203, 3, 4, 'idol', '1', '2018-08-14 06:03:42', 4),
(204, 4, 3, 'unsa man idol', '1', '2018-08-14 06:03:51', 3),
(205, 4, 3, 'wew', '1', '2018-08-14 06:42:34', 3),
(206, 3, 4, 'hahaha', '1', '2018-08-14 06:42:49', 4),
(207, 4, 3, 'wew', '1', '2018-08-16 18:16:44', 3),
(208, 4, 4, 'hi', '1', '2018-08-20 13:16:18', 4),
(209, 3, 4, 'ha ?', '1', '2018-08-20 13:18:13', 4),
(210, 4, 3, 'wla oy', '1', '2018-08-20 13:18:22', 3),
(211, 3, 4, 'taurng dha oy', '1', '2018-08-20 13:18:39', 4),
(212, 4, 3, 'lageh', '1', '2018-08-20 13:18:44', 3),
(213, 3, 4, 'sure dha oy', '1', '2018-08-28 23:42:50', 4),
(214, 3, 4, 'dohh', '1', '2018-08-28 23:43:03', 4),
(215, 3, 4, 'hoyyy', '1', '2018-08-28 23:43:10', 4),
(216, 4, 3, 'saman doh', '1', '2018-08-28 23:43:30', 3),
(217, 3, 4, 'nag unsa ka ron ?', '1', '2018-08-28 23:43:40', 4),
(218, 4, 3, 'wla raman', '1', '2018-08-28 23:43:48', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notif_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `notif_message` text,
  `notif_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_read` datetime DEFAULT NULL,
  `notif_status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notif_id` int(11) NOT NULL,
  `notif_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `table_name` varchar(20) NOT NULL,
  `table_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `user_id` int(11) NOT NULL,
  `supp_id` int(11) NOT NULL,
  `is_read` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notif_id`, `notif_date`, `table_name`, `table_id`, `status`, `user_id`, `supp_id`, `is_read`) VALUES
(22, '2018-08-26 20:42:47', 'order_detail', 36, 2, 3, 2, 1),
(23, '2018-08-26 20:49:16', 'order_detail', 35, 2, 3, 2, 1),
(24, '2018-08-26 20:56:24', 'order_detail', 27, 2, 3, 2, 1),
(25, '2018-08-26 21:03:38', 'order_detail', 26, 2, 3, 2, 1),
(26, '2018-08-27 06:41:15', 'order_detail', 25, 2, 3, 2, 1),
(27, '2018-08-27 06:39:34', 'order_detail', 24, 2, 3, 2, 1),
(28, '2018-08-26 20:58:45', 'order_detail', 23, 2, 3, 2, 1),
(29, '2018-08-27 06:07:56', 'order_detail', 38, 2, 3, 2, 1),
(30, '2018-08-27 06:11:20', 'order_detail', 37, 2, 3, 2, 1),
(31, '2018-08-27 06:21:45', 'order_detail', 34, 2, 6, 4, 0),
(32, '2018-08-27 06:26:16', 'order_detail', 33, 1, 6, 4, 0),
(33, '2018-08-27 06:30:25', 'order_detail', 32, 2, 6, 4, 0),
(34, '2018-08-27 06:35:21', 'order_detail', 31, 2, 6, 4, 0),
(35, '2018-08-27 06:46:18', 'order_detail', 22, 2, 3, 2, 1),
(36, '2018-08-27 06:47:55', 'order_detail', 28, 2, 6, 4, 0),
(37, '2018-08-27 06:48:48', 'order_detail', 30, 2, 6, 4, 0),
(38, '2018-08-29 00:47:50', 'order_detail', 39, 1, 3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `order_id` int(11) NOT NULL,
  `order_num` varchar(25) NOT NULL,
  `product` text NOT NULL COMMENT 'array(prod_id, qty,sub_total)',
  `item_count` tinyint(4) NOT NULL,
  `total` decimal(11,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `supp_id` int(11) NOT NULL,
  `order_type` varchar(50) DEFAULT NULL COMMENT 'Pick-up Or Delivery',
  `payment_method` varchar(32) NOT NULL COMMENT 'Paypal or Cash-on-delivery',
  `is_read` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1-process, 2-done, 3-delivered'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`order_id`, `order_num`, `product`, `item_count`, `total`, `order_date`, `user_id`, `supp_id`, `order_type`, `payment_method`, `is_read`, `status`) VALUES
(19, 'GA32-1535185208', 'a:3:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1200;}i:1;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:2:\"28\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:7000;}i:2;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1080;}}', 0, '9280.00', '2018-08-25 02:20:08', 3, 2, 'pick-up', 'cash-on-delivery', 1, 0),
(20, 'GA32-1535187152', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:300;}}', 0, '300.00', '2018-08-25 02:52:32', 3, 2, 'pick-up', 'cash-on-delivery', 1, 0),
(21, 'GA32-1535187153', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:300;}}', 0, '300.00', '2018-08-25 02:52:33', 3, 2, 'pick-up', 'cash-on-delivery', 1, 0),
(22, 'GA32-1535248216', 'a:2:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:300;}i:1;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:2000;}}', 0, '2300.00', '2018-08-25 19:50:16', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(23, 'GA32-1535250243', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"5\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:675;}}', 0, '675.00', '2018-08-25 20:24:03', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(24, 'GA32-1535250433', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:2000;}}', 0, '2000.00', '2018-08-25 20:27:13', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(25, 'GA32-1535250610', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:2000;}}', 0, '2000.00', '2018-08-25 20:30:10', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(26, 'GA32-1535250784', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"7\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:945;}}', 0, '945.00', '2018-08-25 20:33:04', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(27, 'GA32-1535258051', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1200;}}', 0, '1200.00', '2018-08-25 22:34:11', 3, 2, 'delivery', 'paypal', 1, 2),
(28, 'RB64-1535259646', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:2:\"10\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:4500;}}', 0, '4500.00', '2018-08-25 23:00:46', 6, 4, 'pick-up', 'cash-on-delivery', 1, 2),
(29, 'RB64-1535265380', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"3\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1350;}}', 0, '1350.00', '2018-08-26 00:36:20', 6, 4, 'pick-up', 'cash-on-delivery', 1, 0),
(30, 'RB64-1535265511', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3600;}}', 0, '3600.00', '2018-08-26 00:38:31', 6, 4, 'pick-up', 'cash-on-delivery', 1, 2),
(31, 'RB64-1535271201', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3600;}}', 0, '3600.00', '2018-08-26 02:13:21', 6, 4, 'pick-up', 'cash-on-delivery', 1, 2),
(32, 'RB64-1535288142', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3600;}}', 0, '3600.00', '2018-08-26 06:55:42', 6, 4, 'pick-up', 'cash-on-delivery', 1, 2),
(33, 'RB64-1535288480', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3600;}}', 0, '3600.00', '2018-08-26 07:01:20', 6, 4, 'delivery', 'paypal', 1, 1),
(34, 'RB64-1535296532', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"9\";s:4:\"name\";s:4:\"Goat\";s:3:\"img\";s:26:\"a:1:{s:6:\"images\";s:0:\"\";}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"450.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3600;}}', 0, '3600.00', '2018-08-26 09:15:32', 6, 4, 'delivery', 'paypal', 1, 2),
(35, 'GA32-1535335800', 'a:3:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1200;}i:1;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:2000;}i:2;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1080;}}', 0, '4280.00', '2018-08-26 20:10:00', 3, 2, 'delivery', 'paypal', 1, 2),
(36, 'GA32-1535336315', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:2:\"28\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:3780;}}', 0, '3780.00', '2018-08-26 20:18:35', 3, 2, 'delivery', 'paypal', 1, 2),
(37, 'GA32-1535370175', 'a:2:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1200;}i:1;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:2000;}}', 2, '3200.00', '2018-08-27 05:42:55', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(38, 'GA32-1535370350', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1080;}}', 1, '1080.00', '2018-08-27 05:45:50', 3, 2, 'pick-up', 'cash-on-delivery', 1, 2),
(39, 'GA32-1535522501', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:2:\"28\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:4200;}}', 1, '4200.00', '2018-08-29 00:01:41', 3, 2, 'delivery', 'cash-on-delivery', 1, 1),
(40, 'GA32-1535522621', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"7\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1750;}}', 1, '1750.00', '2018-08-29 00:03:41', 3, 2, 'pick-up', 'cash-on-delivery', 0, 0),
(41, 'GA32-1535522694', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"8\";s:4:\"name\";s:7:\"Chicken\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821091417.jpg\";}}\";s:3:\"qty\";s:1:\"9\";s:5:\"price\";s:6:\"135.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1215;}}', 1, '1215.00', '2018-08-29 00:04:54', 3, 2, 'pick-up', 'cash-on-delivery', 0, 0),
(42, 'GA32-1535522899', 'a:2:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"5\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:750;}i:1;a:7:{s:7:\"prod_id\";s:1:\"7\";s:4:\"name\";s:3:\"Pig\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821083401.PNG\";}}\";s:3:\"qty\";s:1:\"5\";s:5:\"price\";s:6:\"250.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1250;}}', 2, '2000.00', '2018-08-29 00:08:19', 3, 2, 'pick-up', 'cash-on-delivery', 0, 0),
(43, 'GA32-1535523617', 'a:1:{i:0;a:7:{s:7:\"prod_id\";s:1:\"5\";s:4:\"name\";s:6:\"Piglet\";s:3:\"img\";s:57:\"a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821060940.jpg\";}}\";s:3:\"qty\";s:1:\"8\";s:5:\"price\";s:6:\"150.00\";s:3:\"per\";s:3:\"klg\";s:9:\"sub_total\";d:1200;}}', 1, '1200.00', '2018-08-29 00:20:17', 3, 2, 'pick-up', 'cash-on-pick-up', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `total` decimal(11,2) NOT NULL,
  `amount` int(11) NOT NULL COMMENT 'Amount na gibayad',
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `txn_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `payer_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `user_id`, `plan_id`, `txn_id`, `payment_gross`, `currency_code`, `payer_email`, `payment_status`, `payment_date`, `status`) VALUES
(1, 4, 3, '', 0.00, '', '', '', '2018-08-25 00:29:26', 1),
(2, 5, 3, '', 0.00, '', '', '', '2018-08-26 02:09:11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `plan_id` int(11) NOT NULL,
  `plan_category` varchar(50) DEFAULT NULL,
  `price` decimal(11,2) NOT NULL DEFAULT '0.00',
  `description` text,
  `days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`plan_id`, `plan_category`, `price`, `description`, `days`) VALUES
(1, 'Basic Plan', '20.00', 'Create listings\r\nBrowse all listings\r\nSend messages to anyone\r\nReceive messages from featured members only\r\nCan Upload Videos\r\nlisting will be featured on front page slider\r\nMobile number access**\r\nSocial media content access**', 15),
(2, 'Full Plan', '30.00', 'Create listings\r\nBrowse all listings\r\nSend messages to anyone\r\nReceive messages from featured members only\r\nCan Upload Videos\r\nlisting will be featured on front page slider\r\nMobile number access**\r\nSocial media content access**', 30),
(3, 'Free Plan', '0.00', 'Create listings\r\n30 Days Availability\r\nView all listings\r\nSend messages to Anyone', 30);

-- --------------------------------------------------------

--
-- Table structure for table `pricing`
--

CREATE TABLE `pricing` (
  `id_price` int(11) NOT NULL,
  `id_list` int(11) NOT NULL,
  `daily` tinyint(4) NOT NULL,
  `weekly` tinyint(4) NOT NULL,
  `monthly` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` int(11) NOT NULL,
  `prod_code` varchar(45) NOT NULL,
  `sub_id` int(11) DEFAULT NULL,
  `date_birth` date NOT NULL,
  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mother` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL COMMENT 'M-ale or F-emale',
  `status` tinyint(4) NOT NULL COMMENT '0=normal, 1=pregnant, 2=uncondition',
  `for_sale` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-not for sale 1-for sale 2-sold'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_code`, `sub_id`, `date_birth`, `date_add`, `mother`, `gender`, `status`, `for_sale`) VALUES
(114, 'Room1-58-P1-114', 34, '2018-01-10', '2018-09-01 16:41:29', 'Unknown', 'F', 0, 0),
(115, 'Room1-58-P1-115', 34, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'M', 0, 0),
(116, 'room1-58-P1-116', 35, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'F', 0, 0),
(117, 'room1-58-P1-117', 35, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'M', 0, 1),
(118, 'Room1-58-P1-118', 34, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'F', 0, 0),
(119, 'Room1-58-P1-119', 34, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'F', 0, 0),
(120, 'Room1-58-P1-120', 34, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'F', 0, 0),
(121, 'Room1-58-P1-121', 34, '2018-08-10', '2018-09-01 16:42:30', 'Unknown', 'F', 0, 0),
(122, 'room1-58-P3-122', 35, '2018-07-03', '2018-09-01 16:58:57', 'Unknown', 'F', 1, 0),
(123, 'room1-58-P3-123', 35, '2018-07-03', '2018-09-01 16:58:57', 'Unknown', 'F', 2, 1),
(124, 'room1-58-P3-124', 35, '2018-07-03', '2018-09-01 16:58:57', 'Unknown', 'F', 0, 1),
(125, 'room2-58-P3-125', 36, '2018-07-03', '2018-09-01 16:58:57', 'Unknown', 'F', 2, 0),
(126, 'room2-58-P3-126', 36, '2018-08-28', '2018-09-01 17:25:16', 'Unknown', 'M', 1, 0),
(127, 'Group1-42-P11-127', 40, '2018-08-28', '2018-09-06 09:23:13', 'Unknown', 'F', 0, 0),
(128, 'Group2-42-P11-128', 41, '2018-08-28', '2018-09-06 09:23:13', 'Unknown', 'F', 0, 1),
(129, 'Group1-42-P11-129', 40, '2018-08-28', '2018-09-06 09:23:13', 'Unknown', 'F', 0, 0),
(130, 'Group1-42-P11-130', 40, '2018-08-28', '2018-09-06 09:23:13', 'Unknown', 'F', 0, 0),
(131, 'Group2-42-P11-131', 41, '2018-07-25', '2018-09-06 09:26:15', 'Unknown', 'F', 0, 1),
(132, 'Group1-42-P11-132', 40, '2018-07-25', '2018-09-06 09:26:16', 'Unknown', 'M', 0, 0),
(133, 'Group2-42-P11-133', 41, '2018-07-25', '2018-09-06 09:26:16', 'Unknown', 'M', 0, 0),
(134, 'Group2-42-P11-134', 41, '2018-09-03', '2018-09-07 03:13:18', 'Unknown', 'M', 0, 0),
(135, 'Group2-42-P11-135', 41, '2018-09-03', '2018-09-07 03:13:19', 'Unknown', 'M', 0, 0),
(136, 'Group2-42-P11-136', 41, '2018-09-03', '2018-09-07 03:13:19', 'Unknown', 'M', 0, 0),
(137, 'nakalogn-42-P11-137', 59, '2018-09-07', '2018-09-07 03:29:34', 'Unknown', 'M', 0, 0),
(138, 'nakalogn-42-P11-138', 59, '2018-09-07', '2018-09-07 03:29:34', 'Unknown', 'M', 0, 0),
(139, 'nakalogn-42-P11-139', 59, '2018-09-07', '2018-09-07 03:29:34', 'Unknown', 'M', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_history`
--

CREATE TABLE `product_history` (
  `history_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `details` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_history`
--

INSERT INTO `product_history` (`history_id`, `prod_id`, `details`, `date`) VALUES
(1, 117, 'is Pregnant.', '2018-09-02'),
(2, 116, 'Diagnos with ?.', '2018-09-02'),
(3, 116, 'Diagnos with ?.', '2018-09-02'),
(4, 116, 'Details...', '2018-09-02'),
(5, 116, 'Diagnos with  cough', '2018-09-02'),
(6, 117, 'Gave birth with 5 males and 3  female piglets .', '2018-09-02'),
(7, 117, 'Gave birth with 5 males and 3  female piglets .', '2018-09-02'),
(8, 117, 'Gave birth with 5 males and 3  female piglets .', '2018-09-02'),
(9, 124, 'Cured from diagnos.', '2018-09-02'),
(10, 116, 'Cured from diagnos.', '2018-09-02'),
(11, 114, 'is Pregnant.', '2018-07-02'),
(12, 114, 'Gave birth with 5 males and 5 female piglets.', '2018-09-02'),
(13, 122, 'is Pregnant.', '2018-08-25'),
(14, 133, 'is Pregnant.', '2018-09-02'),
(15, 133, 'Gave birth with 4 males and 4 female piglets.', '2018-09-07');

-- --------------------------------------------------------

--
-- Table structure for table `product_pricing`
--

CREATE TABLE `product_pricing` (
  `prod_pricing_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `price_rate` decimal(11,2) NOT NULL,
  `date_post` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supp_id` int(11) NOT NULL,
  `livestock_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_pricing`
--

INSERT INTO `product_pricing` (`prod_pricing_id`, `prod_id`, `price_rate`, `date_post`, `supp_id`, `livestock_id`) VALUES
(1, 123, '3500.00', '2018-09-05 15:43:46', 8, 3),
(2, 124, '3000.00', '2018-09-05 15:46:43', 8, 3),
(3, 117, '2500.00', '2018-09-05 15:50:25', 8, 3),
(4, 131, '2800.00', '2018-09-06 13:18:13', 2, 11),
(5, 128, '2000.00', '2018-09-06 13:22:53', 2, 11);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_id` int(11) NOT NULL,
  `sub_title` varchar(10) NOT NULL,
  `sub_description` varchar(50) NOT NULL,
  `livestock_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_id`, `sub_title`, `sub_description`, `livestock_id`) VALUES
(34, 'Room1', 'for less 1 month old', 3),
(35, 'room1', 'for sale room', 3),
(36, 'room2', 'for uncondition room', 3),
(40, 'Group1', 'for 2month old', 11),
(41, 'Group2', 'for 3month old', 11),
(59, 'nakalogn', 'nakalog naka oy', 11);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supp_id` int(11) NOT NULL,
  `supp_name` varchar(150) NOT NULL,
  `supp_desc` text NOT NULL,
  `supp_address` text NOT NULL,
  `supp_contact` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `media` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supp_id`, `supp_name`, `supp_desc`, `supp_address`, `supp_contact`, `user_id`, `media`) VALUES
(2, 'Behag Livestockss', 'Behag LIvestockss', 'a:3:{s:7:\"address\";s:10:\"Mambalings\";s:5:\"state\";a:2:{s:6:\"abbrev\";s:2:\"SA\";s:4:\"name\";s:15:\"South Australia\";}s:4:\"city\";s:10:\"Oodnadatta\";}', '09234815395', 4, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821070109.jpg\";}}'),
(4, 'Pinnacle  Poultry and Livestocks Corporation', 'Pinnacle, Poultry and Livestocks Corporation', 'a:3:{s:7:\"address\";s:7:\"Biasong\";s:5:\"state\";a:2:{s:6:\"abbrev\";s:3:\"NSW\";s:4:\"name\";s:15:\"New South Wales\";}s:4:\"city\";s:11:\"Broken Hill\";}', '09423606851', 4, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821070725.PNG\";}}'),
(5, 'Newadded branch', 'Newadded branch', 'a:3:{s:7:\"address\";s:7:\"Talisay\";s:5:\"state\";a:2:{s:6:\"abbrev\";s:3:\"QLD\";s:4:\"name\";s:10:\"Queensland\";}s:4:\"city\";s:7:\"Emerald\";}', '09423606851', 4, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0Ran180821074847.PNG\";}}'),
(7, 'Josh piggery', 'Mamaligya ug baboy', 'a:3:{s:7:\"address\";s:27:\"Biasong, Talisay City, Cebu\";s:5:\"state\";a:2:{s:6:\"abbrev\";s:3:\"ACT\";s:4:\"name\";s:28:\"Australian Capital Territory\";}s:4:\"city\";s:8:\"Canberra\";}', '1238798791283123', 4, 'a:1:{s:6:\"images\";s:0:\"\";}'),
(8, 'Rosemyth Livestocks and corporation digital', 'Rosemyth Livestocks', 'a:3:{s:7:\"address\";s:5:\"Lahug\";s:5:\"state\";a:2:{s:6:\"abbrev\";s:3:\"NSW\";s:4:\"name\";s:15:\"New South Wales\";}s:4:\"city\";s:6:\"Bowral\";}', '0909232423', 5, 'a:1:{s:6:\"images\";a:1:{i:0;s:20:\"0ros180829050125.PNG\";}}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(160) NOT NULL,
  `last_name` varchar(160) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL,
  `email` varchar(160) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0-admin 1-buyer 2-supplier',
  `account_status` tinyint(4) NOT NULL COMMENT '0- disable 1-enable',
  `subscription_type` tinyint(4) NOT NULL COMMENT '0 - regular user 1-premium',
  `user_type` tinyint(4) NOT NULL COMMENT '0-room/property owners  1- tenants',
  `token` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `age`, `gender`, `status`, `email`, `phone`, `password`, `role`, `account_status`, `subscription_type`, `user_type`, `token`, `date_added`, `date_modified`, `avatar`) VALUES
(1, 'admin', 'admin', 0, '', '', 'admin@aussie.com', '', '601f1889667efaebb33b8c12572835da3f027f78', 0, 1, 0, 0, '', '2018-04-24 00:00:00', '2018-05-07 10:21:27', ''),
(3, 'gene', 'abano', 0, 'female', '', 'stamfire@gmail.com', '', '601f1889667efaebb33b8c12572835da3f027f78', 1, 1, 0, 0, '', '2018-04-24 10:46:42', '2018-08-25 21:42:28', ''),
(4, 'Ransom', 'Carino', 23, 'male', '', 'padillaransom@gmail.com', '09232423223', '601f1889667efaebb33b8c12572835da3f027f78', 2, 1, 0, 0, '', '0000-00-00 00:00:00', '2018-08-21 07:18:23', ''),
(5, 'rosemyth', 'rosace??a', 24, 'female', 'student', 'sotomayorrose16@gmail.com', '09232232523', '0df8ed4fda719fa98130d5f692e4cac6ffca7ca4', 2, 1, 0, 0, 'QiWFqui6ywOy', '2018-07-24 16:51:25', '2018-08-26 02:09:12', ''),
(6, 'ronald barry', 'bonje', 24, 'male', 'student', 'rbbonje@gmail.com', '09232232523', 'fd3d2bcad4a6cb0d969b5b9a1eda6da8193f39fd', 1, 1, 0, 0, 'goTnV6u9QAfM', '2018-07-26 13:55:26', '2018-07-26 05:55:26', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_listing`
--

CREATE TABLE `user_listing` (
  `ulist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `supp_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `junk` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_listing`
--

INSERT INTO `user_listing` (`ulist_id`, `user_id`, `supp_id`, `date`, `junk`) VALUES
(35, 3, 4, '2018-08-23 15:52:01', 0),
(36, 3, 2, '2018-08-23 21:33:18', 0),
(37, 6, 4, '2018-08-25 23:00:10', 0),
(38, 3, 5, '2018-08-29 00:54:18', 1),
(39, 3, 7, '2018-08-29 03:21:12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `supp_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `curr_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_for_livestock`
--
ALTER TABLE `category_for_livestock`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`delivery_id`),
  ADD KEY `delv_orderID` (`order_id`);

--
-- Indexes for table `google_users`
--
ALTER TABLE `google_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `livestock_category`
--
ALTER TABLE `livestock_category`
  ADD PRIMARY KEY (`livestock_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notif_id`),
  ADD KEY `notif_payment` (`payment_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notif_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `payment_orderID` (`order_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `payment_user` (`user_id`),
  ADD KEY `payment_plan` (`plan_id`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`plan_id`);

--
-- Indexes for table `pricing`
--
ALTER TABLE `pricing`
  ADD PRIMARY KEY (`id_price`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `prod_supID` (`date_add`);

--
-- Indexes for table `product_history`
--
ALTER TABLE `product_history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `product_pricing`
--
ALTER TABLE `product_pricing`
  ADD PRIMARY KEY (`prod_pricing_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supp_id`),
  ADD KEY `sup_userID` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_listing`
--
ALTER TABLE `user_listing`
  ADD PRIMARY KEY (`ulist_id`),
  ADD KEY `list_userID` (`user_id`),
  ADD KEY `list_supID` (`supp_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wishlist_id`),
  ADD KEY `wish_prodID` (`prod_id`),
  ADD KEY `wish_userID` (`user_id`),
  ADD KEY `wish_supID` (`supp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_for_livestock`
--
ALTER TABLE `category_for_livestock`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `google_users`
--
ALTER TABLE `google_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `livestock_category`
--
ALTER TABLE `livestock_category`
  MODIFY `livestock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notif_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notif_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `plan`
--
ALTER TABLE `plan`
  MODIFY `plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pricing`
--
ALTER TABLE `pricing`
  MODIFY `id_price` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `product_history`
--
ALTER TABLE `product_history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product_pricing`
--
ALTER TABLE `product_pricing`
  MODIFY `prod_pricing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_listing`
--
ALTER TABLE `user_listing`
  MODIFY `ulist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delv_orderID` FOREIGN KEY (`order_id`) REFERENCES `order_detail` (`order_id`) ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notif_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`) ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_orderID` FOREIGN KEY (`order_id`) REFERENCES `order_detail` (`order_id`) ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payment_plan` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `supplier`
--
ALTER TABLE `supplier`
  ADD CONSTRAINT `sup_userID` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_listing`
--
ALTER TABLE `user_listing`
  ADD CONSTRAINT `list_supID` FOREIGN KEY (`supp_id`) REFERENCES `supplier` (`supp_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `list_userID` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wish_prodID` FOREIGN KEY (`prod_id`) REFERENCES `product` (`prod_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `wish_supID` FOREIGN KEY (`supp_id`) REFERENCES `supplier` (`supp_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `wish_userID` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
