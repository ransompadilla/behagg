bootChat();
var mes="";
var to = $('#to').val();
$('ul.chat-box-body').animate({scrollTop: $('ul.chat-box-body').prop("scrollHeight")}, 500);
                   
load_thread(to, 6);
$(document).on('keypress', '.input-section #input-message', function(e){
        var txtarea = $(this);
        var message = txtarea.val();
        var user      = $('#to').val();
        if(message !== "" && e.which == 13){
            txtarea.val('');
            // save the message
            $.ajax({ type: "POST", url: base_url+"messages/messages/save_message", data: {message: message, user : user},cache: false,
                success: function(response){
                    msg = response.message;
                    li = '<li class="bubble '+ msg.type +'"><img src="'+base_url+'assets/images/thumbs/'+msg.avatar+'" class="avt img-responsive">\
                    <div class="message">\
                    <span class="chat-arrow"></span>\
                    <a href="javascript:void(0)" class="chat-name">'+msg.name+'</a>&nbsp;\
                    <span class="chat-datetime">at '+msg.time+'</span>\
                    <span class="chat-body">'+msg.body+'</span></div></li>';

                    $('ul.chat-box-body').append(li);
                       
                    $('ul.chat-box-body').animate({scrollTop: $('ul.chat-box-body').prop("scrollHeight")}, 500);
                   
                     html = '<div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>\
                            <div id="message-name">'+msg.list_name+' '+msg.unread+' <span id="m-date">'+msg.time+'</span></div>\
                            <div id="message-content"> '+msg.body+'</div>\
                            <div id="span-seen"> '+msg.seen+'</div>';
                            $('.unread').find('a[id="'+msg.recipient+'"]').html(html);

                }
            });
        }
});

$('.message-send').click(function(){
     var txtarea = $('.input-section #input-message');
        var message = txtarea.val();
        var user      = $('#to').val();

        if(message !== ""){
            txtarea.val('');
            // save the message
            $.ajax({ type: "POST", url: base_url+"messages/messages/save_message", data: {message: message, user : user},cache: false,
                success: function(response){
                    msg = response.message;
                    li = '<li class="bubble '+ msg.type +'"><img src="'+base_url+'assets/images/thumbs/'+msg.avatar+'" class="avt img-responsive">\
                    <div class="message">\
                    <span class="chat-arrow"></span>\
                    <a href="javascript:void(0)" class="chat-name">'+msg.name+'</a>&nbsp;\
                    <span class="chat-datetime">at '+msg.time+'</span>\
                    <span class="chat-body">'+msg.body+'</span></div></li>';

                    $('ul.chat-box-body').append(li);
                    $('ul.chat-box-body').animate({scrollTop: $('ul.chat-box-body').prop("scrollHeight")}, 500);
                 
                    html = '<div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>\
                            <div id="message-name">'+msg.list_name+' '+msg.unread+' <span id="m-date">'+msg.time+'</span></div>\
                            <div id="message-content"> '+msg.body+'</div>\
                            <div id="span-seen"> '+msg.seen+'</div>';
                            $('.unread').find('a[id="'+msg.recipient+'"]').html(html);

                }
            });
        }
        
});
function bootChat()
{
    refresh = setInterval(function()
    {
 
    $.ajax(
        {
            type: 'POST',
            url : base_url+"messages/messages/updates",
            async : true,
            cache : false,
            success: function(data){
                if(data.success){
                     thread = data.messages;
                     senders = data.senders;
                     
                     $.each(thread, function() {
                            chatbuddy = $("#to").val();
                                if(this.sender == chatbuddy){
                                  li = '<li class="'+ this.type +'"><img src="'+base_url+'assets/images/thumbs/'+this.avatar+'" class="avt img-responsive">\
                                    <div class="message">\
                                    <span class="chat-arrow"></span>\
                                    <a href="javascript:void(0)" class="chat-name">'+this.name+'</a>&nbsp;\
                                    <span class="chat-datetime">at '+this.time+'</span>\
                                    <span class="chat-body">'+this.body+'</span></div></li>';
                                    $('ul.chat-box-body').append(li);
                                    $('ul.chat-box-body').animate({scrollTop: $('ul.chat-box-body').prop("scrollHeight")}, 500);
                                    
                                    //Mark this message as read
                                $.ajax({ type: "POST", url: base_url + "messages/messages/mark_read", data: {buddy:chatbuddy, id: this.msg}});
                                }
                                else{
                                    from = this.sender;
                                    $.each(senders, function() {
                                        if(this.user == from){
                                            
                                        }
                                    });
                                }
                        html = '<div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>\
                            <h5 id="message-name">'+this.list_name+' '+this.unread+' <span id="m-date">'+this.time+'</span></h5>\
                            <h5 id="message-content"> '+this.body+'</h5>\
                            <div id="span-seen"> '+this.seen+'</div>';
                        $('.unread').find('a[id="'+this.sender+'"]').html(html);
                                
                         
                     });
                   
                    var audio = new Audio(base_url+'assets/notify/notify.mp3').play();
                }
            },
                error : function(XMLHttpRequest, textstatus, error) { 
                            console.log(error); 
                }
        }
    );

       }, 2000);
}
function load_thread(user, limit){
        //send an ajax request to get the user conversation 
       $.ajax({ type: "POST", url: base_url+"messages/messages/messages", data: {user : user, limit:limit },cache: false,
        success: function(data){
          if(data.success){
            buddy = data.buddy;
            $('ul.chat-box-body').html('');
            if(buddy.more){
             $('ul.chat-box-body').append('<li id="load-more-wrap" style="text-align:center"><a onclick="javascript: load_thread(\''+buddy.id+'\', \''+buddy.limit+'\')" class="btn btn-xs btn-info" style="width:100%">View older messsages('+buddy.remaining+')</a></li>');
            }
            thread = data.thread;
            $.each(thread, function() {
                    li = '<li class="'+ this.type +'"><img src="'+base_url+'assets/images/thumbs/'+this.avatar+'" class="avt img-responsive">\
                      <div class="message">\
                      <span class="chat-arrow"></span>\
                      <a href="javascript:void(0)" class="chat-name">'+this.name+'</a>&nbsp;\
                      <span class="chat-datetime">at '+this.time+'</span>\
                      <span class="chat-body">'+this.body+'</span></div></li>';

                    $('ul.chat-box-body').append(li);
                    html = '<div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>\
                            <h5 id="message-name">'+this.list_name+' '+this.unread+' <span id="m-date">'+this.time+'</span></h5>\
                            <h5 id="message-content"> '+this.body+'</h5>\
                            <div id="span-seen"> '+this.seen+'</div>';
                    $('.unread').find('a[id="'+this.user+'"]').html(html);     

            });
            if(buddy.scroll){
                $('ul.chat-box-body').animate({scrollTop: $('ul.chat-box-body').prop("scrollHeight")}, 500);
            }
          }
          
        }});
}

