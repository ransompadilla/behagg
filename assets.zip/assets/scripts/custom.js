(function($){"use strict";$(document).ready(function(){$(function(){function mmenuInit(){var wi=$(window).width();if(wi<='1024'){$(".mmenu-init").remove();$("#navigation").clone().addClass("mmenu-init").insertBefore("#navigation").removeAttr('id').removeClass('style-1 style-2').find('ul, div').removeClass('style-1 style-2 mega-menu mega-menu-content mega-menu-section').removeAttr('id');$(".mmenu-init").find("ul").addClass("mm-listview");$(".mmenu-init").find(".mobile-styles .mm-listview").unwrap();$(".mmenu-init").mmenu({"counters":true},{offCanvas:{pageNodetype:"#wrapper"}});var mmenuAPI=$(".mmenu-init").data("mmenu");var $icon=$(".hamburger");$(".mmenu-trigger").click(function(){mmenuAPI.open();});mmenuAPI.bind("open:finish",function(){setTimeout(function(){$icon.addClass("is-active");});});mmenuAPI.bind("close:finish",function(){setTimeout(function(){$icon.removeClass("is-active");});});}
$(".mm-next").addClass("mm-fullsubopen");}
mmenuInit();$(window).resize(function(){mmenuInit();});});$('.user-menu').on('click',function(){$(this).toggleClass('active');});$("#header").not("#header.not-sticky").clone(true).addClass('cloned unsticky').insertAfter("#header");$("#navigation.style-2").clone(true).addClass('cloned unsticky').insertAfter("#navigation.style-2");$("#logo .sticky-logo").clone(true).prependTo("#navigation.style-2.cloned ul#responsive");var headerOffset=$("#header-container").height()*2;$(window).scroll(function(){if($(window).scrollTop()>=headerOffset){$("#header.cloned").addClass('sticky').removeClass("unsticky");$("#navigation.style-2.cloned").addClass('sticky').removeClass("unsticky");}else{$("#header.cloned").addClass('unsticky').removeClass("sticky");$("#navigation.style-2.cloned").addClass('unsticky').removeClass("sticky");}});var pxShow=600;var scrollSpeed=500;$(window).scroll(function(){if($(window).scrollTop()>=pxShow){$("#backtotop").addClass('visible');}else{$("#backtotop").removeClass('visible');}});$('#backtotop a').on('click',function(){$('html, body').animate({scrollTop:0},scrollSpeed);return false;});function inlineCSS(){$(".main-search-container, section.fullwidth, .listing-slider .item, .address-container, .img-box-background, .image-edge, .edge-bg").each(function(){var attrImageBG=$(this).attr('data-background-image');var attrColorBG=$(this).attr('data-background-color');if(attrImageBG!==undefined){$(this).css('background-image','url('+attrImageBG+')');}
if(attrColorBG!==undefined){$(this).css('background',''+attrColorBG+'');}});}
inlineCSS();function parallaxBG(){$('.parallax').prepend('<div class="parallax-overlay"></div>');$(".parallax").each(function(){var attrImage=$(this).attr('data-background');var attrColor=$(this).attr('data-color');var attrOpacity=$(this).attr('data-color-opacity');if(attrImage!==undefined){$(this).css('background-image','url('+attrImage+')');}
if(attrColor!==undefined){$(this).find(".parallax-overlay").css('background-color',''+attrColor+'');}
if(attrOpacity!==undefined){$(this).find(".parallax-overlay").css('opacity',''+attrOpacity+'');}});}
parallaxBG();$('.category-box').each(function(){$(this).append('<div class="category-box-background"></div>');$(this).children('.category-box-background').css({'background-image':'url('+$(this).attr('data-background-image')+')'});});$('.img-box').each(function(){$(this).append('<div class="img-box-background"></div>');$(this).children('.img-box-background').css({'background-image':'url('+$(this).attr('data-background-image')+')'});});if("ontouchstart"in window){document.documentElement.className=document.documentElement.className+" touch";}
if(!$("html").hasClass("touch")){$(".parallax").css("background-attachment","fixed");}
function fullscreenFix(){var h=$('body').height();$(".content-b").each(function(i){if($(this).innerHeight()>h){$(this).closest(".fullscreen").addClass("overflow");}});}
$(window).resize(fullscreenFix);fullscreenFix();function backgroundResize(){var windowH=$(window).height();$(".parallax").each(function(i){var path=$(this);var contW=path.width();var contH=path.height();var imgW=path.attr("data-img-width");var imgH=path.attr("data-img-height");var ratio=imgW/imgH;var diff=100;diff=diff?diff:0;var remainingH=0;if(path.hasClass("parallax")&&!$("html").hasClass("touch")){remainingH=windowH-contH;}
imgH=contH+remainingH+diff;imgW=imgH*ratio;if(contW>imgW){imgW=contW;imgH=imgW/ratio;}
path.data("resized-imgW",imgW);path.data("resized-imgH",imgH);path.css("background-size",imgW+"px "+imgH+"px");});}
$(window).resize(backgroundResize);$(window).focus(backgroundResize);backgroundResize();function parallaxPosition(e){var heightWindow=$(window).height();var topWindow=$(window).scrollTop();var bottomWindow=topWindow+heightWindow;var currentWindow=(topWindow+bottomWindow)/2;$(".parallax").each(function(i){var path=$(this);var height=path.height();var top=path.offset().top;var bottom=top+height;if(bottomWindow>top&&topWindow<bottom){var imgH=path.data("resized-imgH");var min=0;var max=-imgH+heightWindow;var overflowH=height<heightWindow?imgH-height:imgH-heightWindow;top=top-overflowH;bottom=bottom+overflowH;var value=0;if($('.parallax').is(".titlebar")){value=min+(max-min)*(currentWindow-top)/(bottom-top)*2;}else{value=min+(max-min)*(currentWindow-top)/(bottom-top);}
var orizontalPosition=path.attr("data-oriz-pos");orizontalPosition=orizontalPosition?orizontalPosition:"50%";$(this).css("background-position",orizontalPosition+" "+value+"px");}});}
if(!$("html").hasClass("touch")){$(window).resize(parallaxPosition);$(window).scroll(parallaxPosition);parallaxPosition();}
if(navigator.userAgent.match(/Trident\/7\./)){$('body').on("mousewheel",function(){event.preventDefault();var wheelDelta=event.wheelDelta;var currentScrollPosition=window.pageYOffset;window.scrollTo(0,currentScrollPosition-wheelDelta);});}
var config={'.chosen-select':{disable_search_threshold:10,width:"100%"},'.chosen-select-deselect':{allow_single_deselect:true,width:"100%"},'.chosen-select-no-single':{disable_search_threshold:100,width:"100%"},'.chosen-select-no-single.no-search':{disable_search_threshold:10,width:"100%"},'.chosen-select-no-results':{no_results_text:'Oops, nothing found!'},'.chosen-select-width':{width:"95%"}};for(var selector in config){if(config.hasOwnProperty(selector)){$(selector).chosen(config[selector]);}}
$('.mfp-gallery-container').each(function(){$(this).magnificPopup({type:'image',delegate:'a.mfp-gallery',fixedContentPos:true,fixedBgPos:true,overflowY:'auto',closeBtnInside:false,preloader:true,removalDelay:0,mainClass:'mfp-fade',gallery:{enabled:true,tCounter:''}});});$('.popup-with-zoom-anim').magnificPopup({type:'inline',fixedContentPos:false,fixedBgPos:true,overflowY:'auto',closeBtnInside:true,preloader:false,midClick:true,removalDelay:300,mainClass:'my-mfp-zoom-in'});$('.mfp-image').magnificPopup({type:'image',closeOnContentClick:true,mainClass:'mfp-fade',image:{verticalFit:true}});$('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({disableOn:700,type:'iframe',mainClass:'mfp-fade',removalDelay:160,preloader:false,fixedContentPos:false});$('.fullwidth-slick-carousel').slick({centerMode:true,centerPadding:'15%',slidesToShow:3,dots:true,arrows:false,responsive:[{breakpoint:1441,settings:{centerPadding:'10%',slidesToShow:3}},{breakpoint:1025,settings:{centerPadding:'10px',slidesToShow:2,}},{breakpoint:767,settings:{centerPadding:'10px',slidesToShow:1}}]});$('.testimonial-carousel').slick({centerMode:true,centerPadding:'34%',slidesToShow:1,dots:true,arrows:false,responsive:[{breakpoint:1025,settings:{centerPadding:'10px',slidesToShow:2,}},{breakpoint:767,settings:{centerPadding:'10px',slidesToShow:1}}]});$('.listing-slider').slick({centerMode:true,centerPadding:'20%',slidesToShow:2,responsive:[{breakpoint:1367,settings:{centerPadding:'15%'}},{breakpoint:1025,settings:{centerPadding:'0'}},{breakpoint:767,settings:{centerPadding:'0',slidesToShow:1}}]});$('.simple-slick-carousel').slick({infinite:true,slidesToShow:3,slidesToScroll:3,dots:true,arrows:true,responsive:[{breakpoint:992,settings:{slidesToShow:2,slidesToScroll:2}},{breakpoint:769,settings:{slidesToShow:1,slidesToScroll:1}}]});$('.simple-fw-slick-carousel').slick({infinite:true,slidesToShow:5,slidesToScroll:1,dots:true,arrows:false,responsive:[{breakpoint:1610,settings:{slidesToShow:4,}},{breakpoint:1365,settings:{slidesToShow:3,}},{breakpoint:1024,settings:{slidesToShow:2,}},{breakpoint:767,settings:{slidesToShow:1,}}]});$('.logo-slick-carousel').slick({infinite:true,slidesToShow:5,slidesToScroll:4,dots:true,arrows:true,responsive:[{breakpoint:992,settings:{slidesToShow:3,slidesToScroll:3}},{breakpoint:769,settings:{slidesToShow:1,slidesToScroll:1}}]});var $tabsNav=$('.tabs-nav-temp'),$tabsNavLis=$tabsNav.children('li');$tabsNav.each(function(){var $this=$(this);$this.next().children('.tab-content').stop(true,true).hide().first().show();$this.children('li').first().addClass('active').stop(true,true).show();});$tabsNavLis.on('click',function(e){var $this=$(this);$this.siblings().removeClass('active').end().addClass('active');$this.parent().next().children('.tab-content').stop(true,true).hide().siblings($this.find('a').attr('href')).fadeIn();e.preventDefault();});var hash=window.location.hash;var anchor=$('.tabs-nav a[href="'+hash+'"]');if(anchor.length===0){$(".tabs-nav li:first").addClass("active").show();$(".tab-content:first").show();}else{anchor.parent('li').click();}
var $accor=$('.accordion');$accor.each(function(){$(this).toggleClass('ui-accordion ui-widget ui-helper-reset');$(this).find('h3').addClass('ui-accordion-header ui-helper-reset ui-state-default ui-accordion-icons ui-corner-all');$(this).find('div').addClass('ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom');$(this).find("div").hide();});var $trigger=$accor.find('h3');$trigger.on('click',function(e){var location=$(this).parent();if($(this).next().is(':hidden')){var $triggerloc=$('h3',location);$triggerloc.removeClass('ui-accordion-header-active ui-state-active ui-corner-top').next().slideUp(300);$triggerloc.find('span').removeClass('ui-accordion-icon-active');$(this).find('span').addClass('ui-accordion-icon-active');$(this).addClass('ui-accordion-header-active ui-state-active ui-corner-top').next().slideDown(300);}
e.preventDefault();});$(".toggle-container").hide();$('.trigger, .trigger.opened').on('click',function(a){$(this).toggleClass('active');a.preventDefault();});$(".trigger").on('click',function(){$(this).next(".toggle-container").slideToggle(300);});$(".trigger.opened").addClass("active").next(".toggle-container").show();$(".tooltip.top").tipTip({defaultPosition:"top"});$(".tooltip.bottom").tipTip({defaultPosition:"bottom"});$(".tooltip.left").tipTip({defaultPosition:"left"});$(".tooltip.right").tipTip({defaultPosition:"right"});$('.like-icon, .widget-button, .like-button').on('click',function(e){e.preventDefault();$(this).toggleClass('liked');$(this).children('.like-icon').toggleClass('liked');});$('.more-search-options-trigger').on('click',function(e){e.preventDefault();$('.more-search-options, .more-search-options-trigger').toggleClass('active');$('.more-search-options.relative').animate({height:'toggle',opacity:'toggle'},300);});$(window).on('load resize',function(){var winWidth=$(window).width();var headerHeight=$("#header-container").height();$('.fs-inner-container, .fs-inner-container.map-fixed, #dashboard').css('padding-top',headerHeight);if(winWidth<992){$('.fs-inner-container.map-fixed').insertBefore('.fs-inner-container.content');}else{$('.fs-inner-container.content').insertBefore('.fs-inner-container.map-fixed');}});$(window).on('load resize',function(){$('.dashboard-stat-content h4').counterUp({delay:100,time:800});});$('.leave-rating input').change(function(){var $radio=$(this);$('.leave-rating .selected').removeClass('selected');$radio.closest('label').addClass('selected');});$('.dashboard-nav ul li a').on('click',function(){if($(this).closest('li').has('ul').length){$(this).parent('li').toggleClass('active');}});$(window).on('load resize',function(){var wrapperHeight=window.innerHeight;var headerHeight=$("#header-container").height();var winWidth=$(window).width();if(winWidth>992){$(".dashboard-nav-inner").css('max-height',wrapperHeight-headerHeight);}else{$(".dashboard-nav-inner").css('max-height','');}});$(".tip").each(function(){var tipContent=$(this).attr('data-tip-content');$(this).append('<div class="tip-content">'+tipContent+'</div>');});$(".verified-badge.with-tip").each(function(){var tipContent=$(this).attr('data-tip-content');$(this).append('<div class="tip-content">'+tipContent+'</div>');});$(window).on('load resize',function(){var verifiedBadge=$('.verified-badge.with-tip');verifiedBadge.find('.tip-content').css({'width':verifiedBadge.outerWidth(),'max-width':verifiedBadge.outerWidth(),});});$(".add-listing-section").each(function(){var switcherSection=$(this);var switcherInput=$(this).find('.switch input');if(switcherInput.is(':checked')){$(switcherSection).addClass('switcher-on');}
switcherInput.change(function(){if(this.checked===true){$(switcherSection).addClass('switcher-on');}else{$(switcherSection).removeClass('switcher-on');}});});$('.dashboard-responsive-nav-trigger').on('click',function(e){e.preventDefault();$(this).toggleClass('active');var dashboardNavContainer=$('body').find(".dashboard-nav");if($(this).hasClass('active')){$(dashboardNavContainer).addClass('active');}else{$(dashboardNavContainer).removeClass('active');}});$(window).on('load resize',function(){var msgContentHeight=$(".message-content").outerHeight();var msgInboxHeight=$(".messages-inbox ul").height();if(msgContentHeight>msgInboxHeight){$(".messages-container-inner .messages-inbox ul").css('max-height',msgContentHeight)}});function newMenuItem(){var newElem=$('tr.pricing-list-item.pattern').first().clone();newElem.find('input').val('');newElem.appendTo('table#pricing-list-container');}
if($("table#pricing-list-container").is('*')){$('.add-pricing-list-item').on('click',function(e){e.preventDefault();newMenuItem();});$(document).on("click","#pricing-list-container .delete",function(e){e.preventDefault();$(this).parent().parent().remove();});$('.add-pricing-submenu').on('click',function(e){e.preventDefault();var newElem=$(''+
'<tr class="pricing-list-item pricing-submenu">'+
'<td>'+
'<div class="fm-move"><i class="sl sl-icon-cursor-move"></i></div>'+
'<div class="fm-input"><input type="text" placeholder="Category Title" /></div>'+
'<div class="fm-close"><a class="delete" href="#"><i class="fa fa-remove"></i></a></div>'+
'</td>'+
'</tr>');newElem.appendTo('table#pricing-list-container');});$('table#pricing-list-container tbody').sortable({forcePlaceholderSize:true,forceHelperSize:false,placeholder:'sortableHelper',zIndex:999990,opacity:0.6,tolerance:"pointer",start:function(e,ui){ui.placeholder.height(ui.helper.outerHeight());}});}
var fieldUnit=$('.pricing-price').children('input').attr('data-unit');$('.pricing-price').children('input').before('<i class="data-unit">'+fieldUnit+'</i>');$("a.close").removeAttr("href").on('click',function(){function slideFade(elem){var fadeOut={opacity:0,transition:'opacity 0.5s'};elem.css(fadeOut).slideUp();}
slideFade($(this).parent());});function close_panel_dropdown(){$('.panel-dropdown').removeClass("active");$('.fs-inner-container.content').removeClass("faded-out");}
$('.panel-dropdown a').on('click',function(e){if($(this).parent().is(".active")){close_panel_dropdown();}else{close_panel_dropdown();$(this).parent().addClass('active');$('.fs-inner-container.content').addClass("faded-out");}
e.preventDefault();});$('.panel-buttons button').on('click',function(e){$('.panel-dropdown').removeClass('active');$('.fs-inner-container.content').removeClass("faded-out");});var mouse_is_inside=false;$('.panel-dropdown').hover(function(){mouse_is_inside=true;},function(){mouse_is_inside=false;});$("body").mouseup(function(){if(!mouse_is_inside)close_panel_dropdown();});$('.checkboxes.categories input').on('change',function(){if($(this).hasClass('all')){$(this).parents('.checkboxes').find('input').prop('checked',false);$(this).prop('checked',true);}else{$('.checkboxes input.all').prop('checked',false);}});$('input[type="range"].distance-radius').rangeslider({polyfill:false,onInit:function(){this.output=$('<div class="range-output" />').insertBefore(this.$range).html(this.$element.val());var radiustext=$('.distance-radius').attr('data-title');$('.range-output').after('<i class="data-radius-title">'+radiustext+'</i>');},onSlide:function(position,value){this.output.html(value);}});$('.show-more-button').on('click',function(e){e.preventDefault();$(this).toggleClass('active');$('.show-more').toggleClass('visible');if($('.show-more').is(".visible")){var el=$('.show-more'),curHeight=el.height(),autoHeight=el.css('height','auto').height();el.height(curHeight).animate({height:autoHeight},400);}else{$('.show-more').animate({height:'450px'},400);}});$(window).on('load resize',function(){var containerWidth=$(".container").width();$('.listing-nav-container.cloned .listing-nav').css('width',containerWidth);});if(document.getElementById("listing-nav")!==null){$(window).scroll(function(){var window_top=$(window).scrollTop();var div_top=$('.listing-nav').not('.listing-nav-container.cloned .listing-nav').offset().top+90;if(window_top>div_top){$('.listing-nav-container.cloned').addClass('stick');}else{$('.listing-nav-container.cloned').removeClass('stick');}});}
$(".listing-nav-container").clone(true).addClass('cloned').prependTo("body");$('.listing-nav a, a.listing-address, .star-rating a').on('click',function(e){e.preventDefault();$('html,body').scrollTo(this.hash,this.hash,{gap:{y:-20}});});$(".listing-nav li:first-child a, a.add-review-btn, a[href='#add-review']").on('click',function(e){e.preventDefault();$('html,body').scrollTo(this.hash,this.hash,{gap:{y:-100}});});$(window).on('load resize',function(){var aChildren=$(".listing-nav li").children();var aArray=[];for(var i=0;i<aChildren.length;i++){var aChild=aChildren[i];var ahref=$(aChild).attr('href');aArray.push(ahref);}
$(window).scroll(function(){var windowPos=$(window).scrollTop();for(var i=0;i<aArray.length;i++){var theID=aArray[i];var divPos=$(theID).offset().top-150;var divHeight=$(theID).height();if(windowPos>=divPos&&windowPos<(divPos+divHeight)){$("a[href='"+theID+"']").addClass("active");}else{$("a[href='"+theID+"']").removeClass("active");}}});});var radios=document.querySelectorAll('.payment-tab-trigger > input');for(var i=0;i<radios.length;i++){radios[i].addEventListener('change',expandAccordion);}
function expandAccordion(event){var allTabs=document.querySelectorAll('.payment-tab');for(var i=0;i<allTabs.length;i++){allTabs[i].classList.remove('payment-tab-active');}
event.target.parentNode.parentNode.classList.add('payment-tab-active');}
var shake="No";$('#message').hide();$('#contact input[type=text], #contact input[type=number], #contact input[type=email], #contact input[type=url], #contact input[type=tel], #contact select, #contact textarea').each(function(){});$('#name, #comments, #subject').focusout(function(){if(!$(this).val()){$(this).addClass('error').parent().find('mark').removeClass('valid').addClass('error');}
else{$(this).removeClass('error').parent().find('mark').removeClass('error').addClass('valid');}
$('#submit').prop('disabled',false).removeClass('disabled');});$('#email').focusout(function(){if(!$(this).val()||!isEmail($(this).val())){$(this).addClass('error').parent().find('mark').removeClass('valid').addClass('error');}else{$(this).removeClass('error').parent().find('mark').removeClass('error').addClass('valid');}});$('#email').focusin(function(){$('#submit').prop('disabled',false).removeClass('disabled');});$('#submit').on('click',function(){$("#contact-message").slideUp(200,function(){$('#contact-message').hide();$('#name, #subject, #phone, #comments, #website, #email').triggerHandler("focusout");if($('#contact mark.error').size()>0){if(shake=="Yes"){$('#contact').effect('shake',{times:2},75,function(){$('#contact input.error:first, #contact textarea.error:first').focus();});}else $('#contact input.error:first, #contact textarea.error:first').focus();return false;}});});$('#contactform').submit(function(){if($('#contact mark.error').size()>0){if(shake=="Yes"){$('#contact').effect('shake',{times:2},75);}
return false;}
var action=$(this).attr('action');$('#contact #submit').after('<img src="images/loader.gif" class="loader" />');$('#submit').prop('disabled',true).addClass('disabled');$.post(action,$('#contactform').serialize(),function(data){$('#contact-message').html(data);$('#contact-message').slideDown();$('#contactform img.loader').fadeOut('slow',function(){$(this).remove();});if(data.match('success')!==null)$('#contactform').slideUp('slow');});return false;});function isEmail(emailAddress){var pattern=new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);return pattern.test(emailAddress);}});})(this.jQuery);/*!* jquery.scrollto.js 0.0.1 - https://github.com/yckart/jquery.scrollto.js
* Copyright (c) 2012 Yannick Albert (http://yckart.com)
* Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php).
**/$.scrollTo=$.fn.scrollTo=function(x,y,options){if(!(this instanceof $))return $.fn.scrollTo.apply($('html, body'),arguments);options=$.extend({},{gap:{x:0,y:0},animation:{easing:'swing',duration:600,complete:$.noop,step:$.noop}},options);return this.each(function(){var elem=$(this);elem.stop().animate({scrollLeft:!isNaN(Number(x))?x:$(y).offset().left+options.gap.x,scrollTop:!isNaN(Number(y))?y:$(y).offset().top+options.gap.y},options.animation);});};function numericalRating(ratingElem){$(ratingElem).each(function(){var dataRating=$(this).attr('data-rating');if(dataRating>=4.0){$(this).addClass('high');}else if(dataRating>=3.0){$(this).addClass('mid');}else if(dataRating<3.0){$(this).addClass('low');}});}numericalRating('.numerical-rating');

function starRating(ratingElem){
    $(ratingElem).each(function(){
        var dataRating=$(this).data('rating');
        function starsOutput(firstStar,secondStar,thirdStar,fourthStar,fifthStar){
            return(''+'<span class="'+firstStar+'"></span>'+'<span class="'+secondStar+'"></span>'+'<span class="'+thirdStar+'"></span>'+'<span class="'+fourthStar+'"></span>'+'<span class="'+fifthStar+'"></span>');
        }
        var fiveStars=starsOutput('star','star','star','star','star');
        var fourHalfStars=starsOutput('star','star','star','star','star half');
        var fourStars=starsOutput('star','star','star','star','star empty');
        var threeHalfStars=starsOutput('star','star','star','star half','star empty');
        var threeStars=starsOutput('star','star','star','star empty','star empty');
        var twoHalfStars=starsOutput('star','star','star half','star empty','star empty');
        var twoStars=starsOutput('star','star','star empty','star empty','star empty');
        var oneHalfStar=starsOutput('star','star half','star empty','star empty','star empty');
        var oneStar=starsOutput('star','star empty','star empty','star empty','star empty');
        if(dataRating>=4.75){
            $(this).append(fiveStars);
        }else if(dataRating>=4.25){
            $(this).append(fourHalfStars);
        }else if(dataRating>=3.75){
            $(this).append(fourStars);
        }else if(dataRating>=3.25){
            $(this).append(threeHalfStars);
        }else if(dataRating>=2.75){
            $(this).append(threeStars);
        }else if(dataRating>=2.25){
            $(this).append(twoHalfStars);
        }else if(dataRating>=1.75){
            $(this).append(twoStars);
        }else if(dataRating>=1.25){
            $(this).append(oneHalfStar);
        }else if(dataRating<1.25){
            $(this).append(oneStar);
        }
    });
}        
starRating('.star-rating');


$('#listingni2').submit(function(e){
    e.preventDefault();
    var form = new FormData($(this)[0]);
    var url = $(this).attr('action');
    var get = {};
    get['url'] = url;
    get['post'] = form;

    autoCall(get, function (data) {
        console.log(data);
        data = JSON.parse(data);

        if(data.status){
            $('.notify').html("<div class='notification success closeable'>"+ data.msg +"</div>");
            $('body, html').animate({scrollTop:$('#titlebar').offset().top}, 'slow');

        }else{
            $('.notify').html("<div class='notification error closeable'>"+ data.msg +"</div>");
            $('body, html').animate({scrollTop:$('#titlebar').offset().top}, 'slow');
        }
    });
});

$(document).ready(function(){

    $(document).on('change','#file-input',function(){
        var files = $(this)[0].files;
        
        if(files.length > 6){
            var message = "<div class ='notification error'>Image was not Uploaded. Maximum allowed photos is (6). You must subscribe to upload more files. <strong><u><a href='<?php echo base_url('subscribe') ?>'>Click here</a></u></strong> to subscribe.</div>";
        
            
            $('.modal').show();
            $('.popcontent').html(message);
            $('#file-input').val('');
            $('#preview').hide();

        }
    });

    $('.popclose').click(function(){
        $('.modal').hide();
        $('#preview').hide();
        $('#file-input').val('');
    });

});


function autoCall(parArray, callback) {
	$.ajax({
		async: false,
		url: parArray['url'],
		//dataType: "json",
		type: "POST",
        data:parArray['post'],
        processData: false,
        contentType: false,
		success: callback,
		error : function(jqXHR) {
            console.log(jqXHR);
			var msg = '';
			if (jqXHR.status === 0) {
				msg = 'Not connect.\n Verify Network.';
			} else if (jqXHR.status == 404) {
				msg = 'Requested page not found. [404]';
			} else if (jqXHR.status == 500) {
				msg = 'Internal Server Error [500].';
			} else if (exception === 'parsererror') {
				msg = 'Requested JSON parse failed.';
			} else if (exception === 'timeout') {
				msg = 'Time out error.';
			} else if (exception === 'abort') {
				msg = 'Ajax request aborted.';
			} else {
				msg = 'Uncaught Error.\n' + jqXHR.responseText;
			}
			console.log(msg);
		}
	});
}
$('.btnDelete').click(function(){
	var data = $(this).attr('id');
	var arr = data.split('_');
	if(confirm("Do you want to delete this List TITLE: "+arr[0]+" ?")){
		window.location = base_url+"user/delete_listing/"+arr[1];
	}
	else{return false;}
});
$('.btnDeleteBranch').click(function(){
	var data = $(this).attr('id');
	var arr = data.split('_');
	if(confirm("Do you want to delete this Branch Name "+arr[1]+" ?")){
		window.location = base_url+"branches/delete_branch/"+data;
	}
	else{return false;}
});
$('.btnDeleteProduct').click(function(){
	var data = $(this).attr('id');
	var arr = data.split('_');
	if(confirm("Do you want to delete this Product Name "+arr[1]+" ?")){
		window.location = base_url+"livestocks/deleteLivestock/"+data;
	}
	else{return false;}
});

var estate=""; var ecity=""; 
$.ajax({
    url: base_url+"assets/scripts/statejson.json",
    type: "GET",
    dataType: "json",
	success: function(data){
		estate = $('#estate').val();
		ecity = $('#ecity').val();
        for(var i=0;i<data.length; i++){
        	if(estate == data[i].name){
        	 $('#state').append("<option value='"+data[i].short+","+data[i].name+"' selected>"+data[i].name+"("+data[i].short+")" + "</option>");
        	}
        	else{
        		$('#state').append("<option value='"+data[i].short+","+data[i].name+"'>"+data[i].name+"("+data[i].short+")" + "</option>");
        	}
        	for (var j=0;j<data[i].city.length;j++) {
	        	if(ecity == data[i].city[j]){
	        		$('#city').append("<option value='"+data[i].city[j]+"' selected>"+data[i].city[j]+"</option>");
	        	}
	        	else{
	        	 	$('#city').append("<option value='"+data[i].city[j]+"'>"+data[i].city[j]+"</option>");
	        	}
	        }
        	
       	}
         $('#state').change(function(){
         	$('#city').children().remove();
         	$('#location').children().remove();

         	$('#city').append("<option value=''>Select City</option>");
			
         	for(var i=0;i<data.length; i++){

        	 	var selected = $('#state').val();
        	 	var state = data[i].short+","+data[i].name;
        	 	if(selected == state){
        	 		$('#location').append("<input type='hidden' name='capital' value='"+data[i].capital+"'>");
	        		for (var j=0;j<data[i].city.length;j++) {
	        			$('#city').append("<option value='"+data[i].city[j]+"'>"+data[i].city[j]+"</option>");
	        		}
          		}
          	}
        });

    }
});
var ctr = 0, key = 0, removeStock = 0, removeAddon = 0, count = 0, found = false, pos = 0;
var html = "";
$('.addLivestock').click(function(){
	ctr++;
	var livestock = $('.input-livestock').val();
	var c_count = $('.edit').val();
	if(c_count > 0){
		c_count = (c_count - 1);
		c_count += ctr;
	}
	else{c_count = ctr;}
	$('.input-livestock').val('');
	if(livestock != ""){
		$('.append-livestock').append('\
		<li class="'+c_count+'">\
		<div class="col-md-10">\
			<input type="hidden" name="livestock_ctr" class="add" value="'+c_count+'">\
			<input type="text" name="livestock[]" class="search-field" value="'+livestock+'">\
		</div>\
		<div class="col-md-2 ">\
            <div class="img-wrap">\
              <span class="removeLivestock close" name="'+c_count+'" style="height: 50px;width: 100%;">&times;</span>\
            </div>\
        </div>\
        </li>\
		');
	}
	else{
		alert('Empty Field Livestock Name');
	}

	$('.removeLivestock').click(function(){
		var eq = $(this).attr('name');
		$('.append-livestock').find('li[class='+eq+']').remove();
	});
});

$('.removeLivestock').click(function(){
		var eq = $(this).attr('name');
		$('.append-livestock').find('li[class='+eq+']').remove();
});
$('span.close').click(function(){
		var id = $(this).attr('id');
		$('.img-wrap').find('[id='+id+']').remove();
});

$('.addOns').click(function(){
	ctr++;
	var add_on = $('.input-add-on').val();
	var key = $('#key').val();
	if(key > 0){
		key = (key - 1);
		key += ctr;
	}
	else{key = 0;}
	$('.input-add-on').val('');
	if(add_on != ""){
		html = '<div id="'+key+'" class="col-md-6">\
				<div class="row">\
				  <div class="col-sm-1">\
		            <div class="img-wrap">\
		              <span class="removeAddOn close" name="'+key+'" >&times;</span>\
		            </div>\
		          </div>\
		          <div class="col-sm-11">\
                    <input type="text" name="product['+key+']" placeholder="Product" value="'+add_on+'" required>\
		          </div>\
				</div>\
                <div class="row">\
                  <div class="col-md-6">\
                    <div class="col-sm-3">\
                      <label style="float: right;">Price:</label>\
                    </div>\
                    <div class="col-sm-9">\
                      <input type="text" placeholder="Price" name="add_on_price'+key+'" style="height: 30px;" required>\
                     </div>\
                  </div>\
                  <div class="col-md-6">\
                    <div class="col-sm-3">\
                      <label style="float: right;">Per:</label>\
                    </div>\
                    <div class="col-sm-5">\
                      <div class="fm-input">\
                        <input type="number" name="add_on_num'+key+'" style="height: 30px;padding: 5px;" required>\
                      </div>\
                    </div>\
                    <div class="col-sm-4">\
                      <select name="add_on_per'+key+'" style="height: 30px;padding: 5px;">\
                        <option value="klg">klg</option>\
                        <option value="pcs">pcs</option>\
                        <option value="cont">cont</option>\
                      </select>\
                    </div>\
                  </div>\
                </div>\
                </div>';
		$('.append-new-addon').append(html);
	}
	else{
		alert('Empty Field Livestock Name');
	}

	$('.removeAddOn').click(function(){
		var eq = $(this).attr('name');
		$('.append-new-addon').find('div[id='+eq+']').remove();
		removeAddon++;
		removeAddons(removeAddon);
	});
});
$('.removeAddOn').click(function(){
		var eq = $(this).attr('name');
		$('.append-new-addon').find('div[id='+eq+']').remove();
		removeAddon++;
		removeAddons(removeAddon);
});
$('span.close').click(function(){
		var id = $(this).attr('id');
		$('.img-wrap').find('[id='+id+']').remove();
});

//Edit or Add New Livestocks
$('.addNewLivestock').click(function(){
	var remv = removeStock;
	ctr++;
	var livestock = $('.input-livestock').val();
		key = $('#key').val();

		// key = (key - remv);
		key = (key - 1);
		key = (key + ctr);
		key = (key - remv);
		key = (key - count);
		//
	
		
	$('.input-livestock').val('');
	if(livestock != ""){
		
		html = '<div id="'+key+'" class="col-md-6">\
				<div class="row">\
				  <div class="col-sm-1">\
		            <div class="img-wrap">\
		              <span class="removeLivestock close" name="'+key+'" >&times;</span>\
		            </div>\
		          </div>\
		          <div class="col-sm-11">\
                    <input type="text" name="livestock[]" placeholder="Name" value="'+livestock+' = '+key+'" required>\
		          </div>\
				</div>\
                <div class="row">\
                  <div class="col-md-6">\
                    <div class="col-sm-3">\
                      <label style="float: right;">Price:</label>\
                    </div>\
                    <div class="col-sm-9">\
                      <input type="text" placeholder="Price" name="livestock_price'+key+'" style="height: 30px;" required>\
                     </div>\
                  </div>\
                  <div class="col-md-6">\
                    <div class="col-sm-3">\
                      <label style="float: right;">Per:</label>\
                    </div>\
                    <div class="col-sm-5">\
                      <div class="fm-input">\
                        <input type="number" name="livestock_num'+key+'" style="height: 30px;padding: 5px;" required>\
                      </div>\
                    </div>\
                    <div class="col-sm-4">\
                      <select name="livestock_per'+key+'" style="height: 30px;padding: 5px;">\
                        <option value="klg">klg</option>\
                        <option value="pcs">pcs</option>\
                        <option value="cont">cont</option>\
                      </select>\
                    </div>\
                  </div>\
                </div>\
                </div>';
		$('.append-newlivestock').append(html);
	}
	else{
		alert('Empty Field Livestock Name');
	}
	$('.removeLivestock').click(function(){
		var len = key + 1;
		var rem = 0;
		var eq = $(this).attr('name');
		for (var i = 0; i < len; i++) {
			if(eq == i){
				found = true;
				count = 1;
				pos = i;
				$('.append-newlivestock').find('div[id='+eq+']').remove();

			}
		}
	});

});
$('.removeLivestock').click(function(){
		removeStock++;
		var eq = $(this).attr('name');
		$('.append-newlivestock').find('div[id='+eq+']').remove();
});
function key(){
	key = $('#key').val();

	return 
}
function removeAddons(count_remove){
	return count_remove;
}
//END
$('.btnJunkSupplier').click(function(){
	var li;
	var str = $(this).attr('id');
	var data = str.split('-');
	$.ajax({ type: "POST", url: base_url+"listing/listing/junkSupplier", data: {data: data},cache: false,
        success: function(response){
        	console.log(response);
        	if(response.status){
        		html = '<li id="'+response.supp_id+'"><div class="notification success closeable">\
							<strong>Successfully junked!</strong>\
							<a class="close"></a>\
						 </div></li>';
        		setTimeout(function(){
        			data = new Array(response.user_id, 1);
        			$('#loading-modal').modal('toggle');
        			$('#supplier-list').find('li[id='+response.supp_id+']').html(html);
        			window.location = base_url+'user/user_supplier';
        		}, 2000);
        		//setTimeout(function(){window.location = base_url+'user/user_supplier';}, 3000);
        	}
        }
    });
    
});

$('.btnUnJunkSupplier').click(function(){
	var str = $(this).attr('id');
	var data = str.split('-');
	UnJunkSuppliers(data);
});
function UnJunkSuppliers(data){
	$.ajax({ type: "POST", url: base_url+"listing/listing/UnJunkSupplier", data: {data: data},cache: false,
        success: function(res){
        	console.log(res);
        	if(res.status){
        		setTimeout(function(){
        			$('#loading-modal').modal('toggle');
        			$('#junk-supplier-list').find('li[id=junk-'+res.supp_id+']').remove();
        			
        		}, 1000);
        		window.location = base_url+'user/user_supplier';
        	}
        }
    });
}
$('.addToMyList').click(function(){
	var supp_id = $(this).attr('id');
	$.ajax({ type: "POST", url: base_url+"page/page/addToMyList", data: {supp_id: supp_id},cache: false,
        success: function(response){
        	setTimeout(function(){$('.addToMyList').replaceWith('<button type="button" class="button fullwidth margin-top-25">Listed!</button>');}, 2000);
        	$('.addToMyList').replaceWith('<button type="button" class="addToMyList button fullwidth margin-top-25">'+response.msg+'</button>');
       }
    });
});

$('.addToWishList').click(function(){
	var str = $(this).attr('id');
	var arr = str.split('_');
	var qty = $('#qty'+arr[0]).val();
	var data = [];
	for (var i = 0; i < arr.length; i++) {
		data[i] = arr[i];
	}
	data[arr.length] = qty;
	$.ajax({ type: "POST", url: base_url+"wishlist/wishlist/addToWishList", data: {data: data},cache: false,
        success: function(response){
        	if(response.status == true){
        		$('#loading-modal').show();
        		setTimeout(function(){ 
        			$('#loading-modal').hide(); 
        			$('#qty'+response.prod_id).val('');
        			$('#qtyModal'+response.prod_id).modal('toggle');
        			$('#shwCart').html(response.a_wish_count); 
        			$('.rating-counter'+response.prod_id).html(response.wish_count); 
        			updateCart(response);
        		}, 2000);

        	}
       }
    });
});

function updateCart(response){
	
	$.ajax({ type: "POST", url: base_url+"wishlist/wishlist/viewCartItems2", data: {data:response},cache: false,
	        		success: function(response_data){
	        			var total = 0, sub_total = 0;
	        			var img,li = '';
	        			var items = response_data.items;
	        			console.log(items);
	        			if(response_data.status){
	        			for (var i = 0; i < items.length; i++) {
	        				if(items[i].p_img.images != ""){
								img = '<img src="'+base_url+'uploads/listing/'+items[i].p_img.images+'" alt="">';							}
							else{
								img = '<img src="'+base_url+'assets/images/listing-item-01.jpg" alt="">';
							}
	        				sub_total = (items[i].p_price * items[i].qty);
	        				total += sub_total;

	        			li+='<div class="dashboard-list-box">\
	        				<li style="padding:0px 3px 0px 3px;margin: -10px;">\
									<div class="list-box-listing">\
									<div class="list-box-listing-img">\
									'+img+'\
									</div>\
									<div class="list-box-listing-content">\
										<div class="inner col-sm-6">\
											<h3>'+items[i].p_name+'</h3>\
											<div>'+items[i].p_desc+'</div>\
											<span>Price: '+items[i].p_price+'/'+items[i].p_per+'</span>\
										</div>\
										<div class="col-sm-6">\
											<h3></h3>\
											<div>Qty: '+items[i].qty+' '+items[i].p_per+'</div>\
											<div>Sub Total: '+sub_total+' </div>\
										</div>\
									</div>\
								</div>\
							</li></div>';
						
						}
						//div = '<div class="dashboard-list-box">'+li+'</div>';
						$('#load-html').html(li);
						$('#load-total').html('<h3>Total: '+total+' </h3>');
						}
		        	}
		       	});
	
}
$('#order_type').change(function(){
	var order_type = $(this).val();
	option = '<option value="cash-on-'+order_type+'">Cash on '+order_type+'</option>\
			 <option value="paypal">Paypal</option>';
	$('#payment_method').html(option);
});
$('.btnOrder').click(function(){
	var or_str = $(this).attr('id');
	var or_arr = or_str.split('-');
	var order_type = $('#order_type').val();
	var payment_method = $('#payment_method').val();
	var data = new Array(or_arr[0],or_arr[1], order_type, payment_method);
	
	$.ajax({ type: "POST", url: base_url+"wishlist/wishlist/wishlistToOrder", data: {data:data},cache: false,
	    success: function(response){
	    	console.log(response);
	    	if(response.status){
	    		$('.btnOrder').html('Order <i class="fa fa-spinner fa-spin"></i>');
				setTimeout(function(){
					$('#loading-modal').modal('toggle');
					window.location = base_url+'user/my-orderedlist';
				},
				 2000);

	    	}

		}
	});
});
bootNotificationSupplier();
function bootNotificationSupplier(){
	refresh = setInterval(function()
    {
		$.ajax({ 
			type: "POST", 
			url: base_url+"orderedlist/orderedlist/load_orderedlist", 
			async:true, 
			cache: false,
		    success: function(response){
		    	var li = '';var or_process='';
		    	console.log(response);
		    	if(response.count > 0){
		    		$('#notif-count').html('Notification <i class="notif-counter">'+response.count+'</i>');
		    	}
		    	if(response.status){
		    		
		    		var thread = response.thread;
		    		$.each(thread, function() {
		    			if(this.status == 0){
		    				or_process = '<span class="process border with-icon">Process</span>';
		    			}
		    			else if(this.status == 1){
		    				or_process = '<span class="processing with-icon">Processing <i class="fa fa-spinner fa-spin"></i></span>';
		    			}
		    			else{
		    				or_process = '<span class="ready-to-deliver with-icon" >Ready to '+this.type+'</span>';
		    			}
		    			if(this.is_read == 0){
		    				li +='<a href="'+base_url+'user/order-no/'+this.order_num+'/'+this.order_id+'">\
		    						<li class="is_read0">\
									<div class="row">\
									<div class="col-sm-2 img-50px"><img src="'+base_url+'assets/images/'+this.avatar+'" alt=""></div>\
									<div class="col-sm-7">\
										<h4>'+this.name+'</h4>\
										<div class="font-size-08em"><strong>Order No. </strong>'+this.order_num+'<strong> Amount: </strong> '+this.total+'</div>\
										<div class="font-size-08em"><strong>Order Type: </strong>'+this.order_type+'</div>\
										<div class="font-size-08em"><strong>Payment Method: </strong>'+this.payment_method+'</div>\
									</div>\
									<div class="col-sm-3">\
										<i class="time sl sl-icon-clock"> '+this.time+'</i>\
										<div>'+this.item_count+'</div>\
									</div>\
									</div>\
								</div>\
							</li></a>';
		    			}
		    			else{
		    				li +='<a href="'+base_url+'user/order-no/'+this.order_num+'/'+this.order_id+'">\
		    					<li class="is_read1">\
									<div class="row">\
									<div class="col-sm-2 img-50px"><img src="'+base_url+'assets/images/'+this.avatar+'" alt=""></div>\
									<div class="col-sm-7">\
										<h4>'+this.name+'</h4>\
										<div class="font-size-08em"><strong>Order No. </strong>'+this.order_num+'<strong> Amount: </strong> '+this.total+'</div>\
										<div class="font-size-08em"><strong>Order Type: </strong>'+this.order_type+'</div>\
										<div class="font-size-08em"><strong>Payment Method: </strong>'+this.payment_method+'</div>\
									</div>\
									<div class="col-sm-3">\
										<i class="time sl sl-icon-clock"> '+this.time+'</i>\
										<div>'+or_process+'</div>\
										<div>'+this.item_count+'</div>\
									</div>\
									</div>\
							</li></a>';
		    			}  
                    });
                    //var audio = new Audio(base_url+'assets/notify/notify.mp3').play();
                    $('#notification').html(li);
		    	}
		    }
	    });
	}, 2000);
}
//PROCESS ORDER
$('.btnProcess').click(function(){
	var order = $(this).attr('id');
	var arr = order.split('-');
	var html = '<button type="button" id="'+arr[0]+'-'+arr[1]+'-'+arr[2]+'-'+arr[3]+'" class="btnProcessDone style-with-100 button with-icon bg-process" >Processing <i class="fa fa-spinner fa-spin"></i></button>';
	var method = 'process_order';
	process(method, order, html);
});
$('.btnProcessDone').click(function(){
	var order = $(this).attr('id');
	var arr = order.split('-');
	var process_data = '';
	if(arr[3] == 'pick-up') { 
		process_data = 'Pick UP <i class="fa fa-thumbs-up"></i>'; 
	}
	else{ 
		process_data = 'Deliver <i class="fa fa-truck"></i>';
	}
	var html = '<button type="button" id="'+arr[0]+'-'+arr[1]+'-'+arr[2]+'-'+arr[3]+'" class="btnDelivery style-with-100 button with-icon bg-delivery">Ready to '+process_data+'</button>';
	var method = 'process_order_done';
	process(method, order, html);
});
function process(method, order, html){
	$.ajax({ 
			type: "POST", 
			url: base_url+"orderedlist/orderedlist/"+method, 
			async:true, 
			cache: false,
			data:{data:order},
		    success: function(response){
		    	if(response.status){
		    		$('.process-order').html(html);
		    	}
		    	$('.btnProcessDone').click(function(){
					var order1 = $('.btnProcessDone').attr('id');
					var arr1 = order1.split('-');
					var process_data = "";
					if(arr1[3] == 'pick') { 
						process_data = 'Pick UP <i class="fa fa-thumbs-up"></i>'; 
					}
					else{ 
						process_data = 'Deliver <i class="fa fa-truck"></i>';
					}
					var html1 = '<button type="button" id="'+arr1[0]+'-'+arr1[1]+'-'+arr1[2]+'-'+arr1[3]+'" class="btnDelivery style-with-100 button with-icon bg-delivery">Ready to '+process_data+'</button>';
					var method1 = 'process_order_done';
					process(method1, order1, html1);
				});
		    }

	});
}
bootNotificationUser();
function bootNotificationUser(){
	refresh = setInterval(function()
    {
		$.ajax({ 
			type: "POST", 
			url: base_url+"notification/notification/getNotificationByUser", 
			async:true, 
			cache: false,
		    success: function(response){
		    	var li='';var or_process='';
		    	console.log(response);
		    	if(response.notif_status==true){
		    		var notification = response.notification;
		    		if(response.count > 0){
			    		$('#notif-count').html('Notification <i class="notif-counter">'+response.count+'</i>');
			    	}
		    		
		    		$.each(notification, function(){
		    			if(this.status == 0){
		    				or_process = '<span class="process border with-icon">Process</span>';
		    			}
		    			else if(this.status == 1){
		    				or_process = '<span class="processing with-icon">Processing <i class="fa fa-spinner fa-spin"></i></span>';
		    			}
		    			else{
		    				or_process = '<span class="ready-to-deliver with-icon" >Ready to '+this.type+'</span>';
		    			}
		    			if(this.is_read == 0){
		    				li +='<a href="#">\
		    						<li class="is_read0">\
									<div class="row">\
									<div class="col-sm-2 img-50px"><img src="'+base_url+'assets/images/happy-client-01.jpg" alt=""></div>\
									<div class="col-sm-7">\
										<h4>'+this.supp_name+'</h4>\
										<div class="font-size-09em">'+this.msg+'</div>\
									</div>\
									<div class="col-sm-3">\
										<i class="time sl sl-icon-clock"> '+this.time+'</i>\
										<div>'+or_process+'</div>\
									</div>\
									</div>\
								</div>\
							</li></a>';
		    			}
		    			else{
		    				li +='<a href="#">\
		    						<li class="is_read1">\
									<div class="row">\
									<div class="col-sm-2 img-50px"><img src="'+base_url+'assets/images/happy-client-01.jpg" alt=""></div>\
									<div class="col-sm-7">\
										<h4>'+this.supp_name+'</h4>\
										<div class="font-size-09em">'+this.msg+'</div>\
									</div>\
									<div class="col-sm-3">\
										<i class="time sl sl-icon-clock"> '+this.time+'</i>\
										<div>'+or_process+'</div>\
									</div>\
									</div>\
								</div>\
							</li></a>';
		    			}
		    		});
		    		//var audio = new Audio(base_url+'assets/notify/notify.mp3').play();
		    		$('#notification').html(li);

		    	}
		    }
	    });
	}, 2000);
}

$('.user-notif').click(function(){
	$.ajax({ 
			type: "POST", 
			url: base_url+"notification/notification/update_UserNotification", 
			async:true, 
			cache: false,
		    success: function(response){
		    	console.log(response);
		    	if(response.status==true){
		    		if(response.count > 0){
			    		$('#notif-count').html('Notification <i class="notif-counter">'+response.count+'</i>');
			    	}
		    	}
		    }
	});
});

$('.btnAddSubcategory').click(function(){
	var livestock_id = $('#livestock_id').val();
	var desc = $('#description').val();
	var title = $('#title').val();

	var url1 = $('#url1').val();
	var url2 = $('#url2').val();
	if(title != "" && desc != ""){
	var data = new Array(livestock_id, title, desc, url1, url2);
		$.ajax({ 
				type: "POST", 
				url: base_url+"livestocks/livestocks/add_sub_category", 
				async:true, 
				cache: false,
				data:{data:data},
			    success: function(response){
			    	console.log(response);
			    	$('#title').val('');
			    	$('#description').val('');
			    	html = '<div id="'+response.sub_title+'" class="col-lg-3 col-md-6" >\
			    				<span id="'+response.sub_title+'" class="remove_sub_cat close" style="position: absolute; right: 20px; top: -5px;">&times;</span>\
				                <div class="dashboard-stat color-2">\
				                    <div class="dashboard-stat-content">\
				                    <h2><strong>'+response.sub_title+'</strong></h2> <h4>0</h4><span>'+response.sub_description+'</span></div>\
				                     <div class="dashboard-stat-icon"><a href="#add-product" data-toggle="modal" style="color: #fefefe;"><i class="sl sl-icon-plus"></i></a></div>\
				                </div>\
				            </div>';
			    	$('#sub_category').append(html);
			    	$('.remove_sub_cat').click(function(){
						var title = $(this).attr('id');
						$.ajax({ 
									type: "POST", 
									url: base_url+"livestocks/livestocks/remove_sub_category", 
									async:true, 
									cache: false,
									data:{data:title},
								    success: function(response){
								    	$('#sub_category').find('div[id='+title+']').remove();
								    }
							});
					});

			    	window.location = base_url+'user/q/'+response.var+'/'+response.var2;
			    }
		});
	}
	else{
		if(title == ""){
			$('#sub_cat_msg').append('<p>Title field is Empty</p>');
		}
		else if(desc == ""){
			$('#sub_cat_msg').append('<p>Description field is Empty</p>');
		}
	}
	setTimeout(function(){$('#sub_cat_msg').remove();}, 2000);
});

$('.remove_sub_cat').click(function(){
	var title = $(this).attr('id');
	$.ajax({ 
				type: "POST", 
				url: base_url+"livestocks/livestocks/remove_sub_category", 
				async:true, 
				cache: false,
				data:{data:title},
			    success: function(response){
			    	$('#sub_category').find('div[id='+title+']').remove();
			    }
		});
});
$('.product_qty #prod_qty').keyup(function(){
	var qty = $(this).val();
	var sub_id = $('#sub_id').val();
	var code = $('.product_code #prod_code').val();
	var arr = code.split('-');
	var gen = parseInt(arr[2]);
	var input="";
		for(var i=1; i <= qty; i++){
			generate = (gen + i);
			input += '<input type="text" name="prod_code[]" value="'+arr[0]+'-'+arr[1]+'-'+generate+'" readonly/>';
			
		}
		$('.product_code #p_code').html(input);
});
$('.change-status .new_status').change(function(){
	var new_status = $(this).val();
	var arr = new_status.split('-');
	var html, details, date = "";
	var detail_keyup = false;
	if(arr[2] == 1){
		html = 'Gave birth with ? males and ? female piglets.';
		$('.status-details textarea').text(html);
	}
	if(arr[2] == 2){
		html = 'Cured from diagnos.';
		$('.status-details textarea').text(html);
	}
	// if(arr[0] == 0){
	// 	html = 'Details...';
	// 	$('.status-details textarea').text(html);
	// }
	if(arr[0] == 1){
		html = 'is Pregnant.';
		$('.status-details textarea').text(html);
	}
	if(arr[0] == 2){
		html = 'Diagnos with ?.';
		$('.status-details textarea').text(html);
	}
	$('.status-details #status_details').keyup(function(){
		detail_keyup = true;
		details = $(this).val();
	});
	$('.status-details #date_change_status').change(function(){
		date = $(this).val();
	});
	if(detail_keyup == false){
		details = html;
	}
	$('.btnChangeProductStatus').click(function(){
		var data = new Array(arr[1], arr[0], details, date);
		if(date != '' && details != ''){
			$.ajax({ 
				type: "POST", 
				url: base_url+"livestocks/livestocks/change_product_status", 
				async:true, 
				cache: false,
				data:{data:data},
			    success: function(response){
			    	console.log(response);
			    	if(response.status == true){
			    		$('.change-status-modal #change-success-msg').html('Changes: <span style="color: green">Success</span>');
			    		$('.status-details textarea').val('');
			    		$('.status-details #date_change_status').val('');
			    	}
			    	else{
			    		$('.change-status-modal #change-success-msg').html('Change: <span style="color: red">Failed</span>');	
			    	}
			    }
			});	
		}
		else{
			alert('There are empty fields!');
		}
	});
});
