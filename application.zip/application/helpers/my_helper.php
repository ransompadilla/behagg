<?php

	function success_msg($msg = '') {
		$n_msg = '';
		$n_msg = '<div class="notification success closeable">'. $msg .'</div>';
		return $n_msg;
	}

	function error_msg($msg = '') {
		$n_msg = '';
		$n_msg = '<div class="notification error closeable">'. $msg .'</div>';
		return $n_msg;
	}