<?php

class MY_Model extends CI_Model{

	var $table_name;
	var $user_id;

	public function __construct(){
		parent::__construct();
	}

	
	// global function for insertion
	function insert($data){
		if($this->db->insert($this->table, $data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	function insertData($tables, $data){
		return $this->db->insert($tables, $data);
			
	}
	// global function for update
	function update($data, $where){
		return $this->db->update($this->table, $data, $where);
	}

	function delete($where){
		$this->db->where($where);
		return $this->db->delete($this->table);
	}

	function getRow($where){
		$this->db->where($where);
		$query = $this->db->get($this->table);
		
		if($query->row()){
			return $query->row();
		}else{
			return false;
		}
	}

	public function getAll(){
		$query = $this->db->get($this->table);
		if($query->result()){
			return $query->result();
		}else{
			return false;
		}
	}

	function getWhere($where){
		$this->db->where($where);
		$query = $this->db->get($this->table);
		if($query->result()){
			return $query->result();
		}else{
			return false;
		}
		
	}

	function getRowQuery($query){
		$query = $this->db->query($query);
		if($query->row()) {
			return $query->row();
		} else {
			return false;
		}	
	}

	function getallQuery($query){
		$query = $this->db->query($query);
		if($query->result()) {
			return $query->result();
		} else {
			return false;
		}	
	}

}

?>
