<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Add Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Add Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/add-listing2'), array('id'=>'listingni1')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                </div>
       
            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Pricing</h3>
                    <!-- Switcher -->
                   <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <div class="row with-forms">
                <?php 
                    $livestock = $this->session->userdata('livestock');
                    if($livestock):
                    for($i=0;$i < count($livestock);$i++) : ?>
                    <div class="col-md-6">
                         <h3><?=$livestock[$i]?></h3>

                        <div class="row">
                        <div class="col-md-6">
                          <div class="col-sm-3">
                            <label style="float: right;">Price:</label>
                          </div>
                          <div class="col-sm-9">
                            <input type="text" placeholder="Price" name="livestock_price<?=$i?>" style="height: 30px;" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="col-sm-3">
                            <label style="float: right;">Per:</label>
                          </div>
                          <div class="col-sm-5">
                            <div class="fm-input">
                              <input type="number" name="livestock_num<?=$i?>" style="height: 30px;padding: 5px;" required>
                            </div>
                          </div>
                          <div class="col-sm-4">
                            <select name="livestock_per<?=$i?>" style="height: 30px;padding: 5px;">
                            <?php
                             $per = array('klg', 'pcs', 'cont');
                                foreach ($per as $key => $value):?>
                                  <option value="<?= $value?>"><?= $value?></option>
                                    <?php endforeach;?>
                            </select>
                          </div>
                        </div>
                        </div>
                    </div>
                
                    <?php 
                        endfor; 
                    endif;
                    ?>
                </div>
                <!-- Row / End -->

            </div>
            <!-- Section / End -->
            <div class="add-listing-section margin-top-45">
                            
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Add-Ons Pricing</h3><hr>
                    <div class="row with-forms">
                    <div class="col-md-10">
                        <input type="input" name="input-add-on" class="input-add-on search-field" placeholder="Add-Ons">
                    </div>
                    <div class="col-md-2 ">
                        <button class="addOns" type="button" style="height: 50px;width: 100%;">Add</button>
                    </div>
                    <div class="col-md-12 ">
                    <div class="append-new-addon">
                    
                    </div>
                    </div>
                </div>  
                </div>

            </div>    
            <div class="add-listing-section margin-top-45">
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Images</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                </div>
                <div class="submit-section">                    
                   <input id="file-input" type="file" multiple="multiple" name="photo[]">
                    <div id="preview"></div>
                </div>

            </div>

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>