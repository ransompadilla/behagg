<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Edit Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Edit Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!--?php echo site_url('listing/addList'); ?-->
            <form action="" method="post" enctype="multipart/form-data" id="listingni">
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify)){
                            echo $notify; 
                            }
                        ?>
                            
                    </div>
                    <h3><i class="sl sl-icon-doc"></i> Basic Informations</h3>
                </div>

                <!-- category -->
                <!-- State -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Category</h5>
                        <select name="category"  class="chosen-select-no-single" >
                        <?php 

                        
                        if(count($categories) > 0):
                                foreach($categories as $val): ?>
                                <option value="<?php echo $val->cat_id; ?>" <?php echo ($listing->cat_id == $val->cat_id ? 'selected' : ''); ?>><?php echo ucfirst($val->cat_name); ?></option>
                        <?php   endforeach; 
                              endif; ?>
                        </select>
                    </div> 
                </div> 

                <!-- Title -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Title<i class="tip" data-tip-content="Name of the business"></i></h5>
                        <input name="title" class="search-field" type="text" value="<?php echo $listing->title_for; ?>"/>
                    </div>
                </div>  

                 <!-- Checkboxes -->
               <!--  <h5 class="margin-top-30 margin-bottom-10">Type</h5>
                <div class="checkboxes in-row margin-bottom-20">
            
                    <input id="check-a" type="checkbox" name="room_type[]" value="Rooms in an existing sharehouse">
                    <label for="check-a">Rooms in an existing sharehouse</label>

                    <input id="check-b" type="checkbox" name="room_type[]" value="Whole property for rent">
                    <label for="check-b">Whole property for rent</label>

                    <input id="check-c" type="checkbox" name="room_type[]" value="Student Accomodation">
                    <label for="check-c">Student Accomodation</label>

                    <input id="check-d" type="checkbox" name="room_type[]" value="Home stay">
                    <label for="check-d">Home stay</label>
                    
                </div> -->
                <!-- Checkboxes / End --> 
            </div>
            <!-- Section / End -->


              <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> Details</h3>
                </div>

                  <!-- Row -->
                <!--div class="row with-forms">
                    <div class="col-md-4">
                        <h5>Bedroom</h5>
                        <input name="bedroom" type="text" value="<?php //echo set_value('bedroom'); ?>">
                    </div>
                    <div class="col-md-4">
                        <h5>Bathroom</h5>
                        <input name="bathroom" type="text" value="<?php //echo set_value('bathroom'); ?>">
                    </div>
                    <div class="col-md-4">
                        <h5>Guest Room</h5>
                        <input name="guestroom" type="text" value="<?php //echo set_value('guestroom'); ?>">
                    </div>
                </div-->
                <!-- Row / End -->

                <!-- Description -->
                <div class="form">
                    <h5>Description</h5>
                    <textarea class="WYSIWYG" name="description" cols="40" rows="3" id="summary" spellcheck="true"></textarea>
                </div>                       
               

                <!-- Checkboxes -->
                <h5 class="margin-top-30 margin-bottom-10">Amenities <span>(optional)</span></h5>
                <div class="checkboxes in-row margin-bottom-20">
                    <?php if(count($amenities) > 0):
                        foreach($amenities as $val): ?>
                            <input id="check-<?php echo $val->am_id; ?>" type="checkbox" name="amenities[]" value="<?php echo $val->am_name; ?>">
                            <label for="check-<?php echo $val->am_id; ?>"><?php echo ucfirst($val->am_name); ?></label>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <!-- Checkboxes / End -->

            </div>
            <!-- Section / End -->

            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Pricing</h3>
                    <!-- Switcher -->
                   <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-4">
                        <h5>Rate </h5>
                        <input name="price" type="text" value="<?php echo set_value('daily'); ?>">
                    </div>
                    <div class="col-md-4">
                        <h5>&nbsp;</h5>
                        <select name="price_by">
                            <option value="night">per day</option>
                            <option value="night">per night</option>
                            <option value="week">per week</option>
                            <option value="week">per month</option>
                        </select>
                    </div>
                </div>
                <!-- Row / End -->

            </div>
            <!-- Section / End -->


            <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-location"></i> Location</h3>
                </div>

                <div class="submit-section">

                    <!-- Row -->
                    <div class="row with-forms">

                        <!-- Address -->
                        <div class="col-md-12">
                            <h5>Address</h5>
                            <input name="address" type="text" value="<?php echo set_value('address'); ?>" placeholder="e.g. 964 School Street">
                        </div>

                    </div>
                    <!-- Row / End -->

                </div>
            </div>
            <!-- Section / End -->            

            <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Images</h3>
                </div>
                <div class="submit-section">                    
                   <input id="file-input" type="file" multiple="multiple" name="photo[]">
                    <div id="preview"></div>
                </div>

            </div>
            <!-- Section / End -->

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            </form>
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
        </div>
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);


    $(document).ready(function(){
        $('#listingni').on('submit', function(e){
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: $(this).attr('action'),
                data: new FormData($(this)[0]),
                // datatype: "html",
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    $('body, html').animate({scrollTop:$('#titlebar').offset().top}, 'slow');
                    $('#notify').append().html(data);
                    setTimeout(function(){
                        window.location.href= base_url+'/listing';
                    }, 3000);

              }
            });
        });

         $(document).on('change','#file-input',function(){
            var files = $(this)[0].files;
            
            if(files.length > 6){
                var message = "<div class ='notification error'>Image was not Uploaded. Maximum allowed photos is (6). You must subscribe to upload more files. <strong><u><a href='<?php echo base_url('subscribe') ?>'>Click here</a></u></strong> to subscribe.</div>";
              
                
                $('.modal').show();
                $('.popcontent').html(message);
                $('#file-input').val('');
                $('#preview').hide();

            }
        });

        $('.popclose').click(function(){
             $('.modal').hide();
             $('#preview').hide();
             $('#file-input').val('');
        });

       

    });
</script>