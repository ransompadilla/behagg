<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $pagename; ?></h2>
                    <?php if($order): ?>
	                	<p><strong>Order Type: </strong><?= $order->order_type ?></p>
	                	<p><strong>Payment Method: </strong><?= $order->payment_method ?></p>
	                <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Payments -->
            <div class="col-lg-12">
            	
                <div class="dashboard-list-box invoices with-icons margin-top-20">
                	<div class="row">
                	<div class="col-md-4">
                		<h3>Products </h3> 
                	</div>
                	<div class="col-md-4">
                		<div class="process-order">
                		<?php if($order->status == 0) : ?>
                			<button type="button" id="<?= $order->order_id ?>-<?= $order->user_id ?>-<?= $order->supp_id ?>-<?= $order->order_type ?>" class="btnProcess style-with-100 button border with-icon">Process</button>
                		<?php elseif($order->status == 1): ?>
                			<button type="button" id="<?= $order->order_id ?>-<?= $order->user_id ?>-<?= $order->supp_id ?>-<?= $order->order_type ?>" class="btnProcessDone style-with-100 button with-icon bg-process">Processing <i class="fa fa-spinner fa-spin"></i></button>
                		<?php else: ?>
                			<button type="button" id="<?= $order->order_id ?>-<?= $order->user_id ?>-<?= $order->supp_id ?>-<?= $order->order_type ?>" class="btnDeliver style-with-100  button with-icon bg-delivery">Ready to <?= ($order->order_type == 'pick-up') ? 'Pick UP <i class="fa fa-thumbs-up"></i>' : 'Deliver <i class="fa fa-truck"></i>';?></button>
                		<?php endif; ?>
                		</div>
                	</div>
                	<div class="col-md-4" style="text-align: center;"><h3>Total: <?= $order->total ?></h3></div>
                </div>
                	<div class="dashboard-list-box">
                    <?php 
						if($order): 
						$product = unserialize($order->product);
							?>
						<ul id="supplier-list">
						<?php
								foreach($product as $val):	
									$val = (object) $val;
									
								?>
									<li>
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="#">
												<?php
												
												if($val->img != ''):
													$media = unserialize($val->img);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php 
												endif;
												?>
												</a>
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->name; ?></a></h3>
													<div>Price: <?php echo $val->price; ?></div>
													<div>Qty: <?php echo $val->qty; ?> <?php echo $val->per; ?></div>
													<div>Sub Total: <?= ($val->price * $val->qty) ?></div>
												</div>
											</div>
										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
                </div>
                
                </div>
            </div>

            <!-- Copyrights -->
            <?php $this->load->view('inc/copyrights'); ?>
            
        </div>
