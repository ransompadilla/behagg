<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $pagename; ?></h2>
                </div>
            </div>
        </div>

        <!-- Notice -->
        <div class="row">
            <div class="col-md-12">
                <?php 
                if(isset($notify)){

                } ?>
            </div>
        </div>
        <div class="row">
            <!-- Payments -->
            <div class="col-lg-12">
                <div class="dashboard-list-box invoices with-icons margin-top-20">
                   
                    <?php if($orderedlist): ?>
                    <table class="table-responsive table table-stripped">
                    <th>Order Number</th><th>Product</th><th>item's</th><th>Total</th><th>Order Type</th><th>Payment Method</th><th>Supplier</th><th>Date</th>
                        <?php 
                            foreach ($orderedlist as $list){
                            $strDate = strtotime($list->order_date);
                            $date = date('F j, Y', $strDate);
                            $products = unserialize($list->product);

                        ?>
                       
                            <tr>
                                <td><?php echo $list->order_num; ?></td>
                                <td>
                                	<div class="row">
                                	<?php
                                		foreach ($products as $key => $prod) {
                                			$prod = (object) $prod;?>
                                			<div class="col-sm-3">
                                			<div  style=" width: 50px;">
                                			
										<span style="font-size: 0.8em;">
                                            <?php echo $prod->name ?>
                                        </span>
                                        <span style="font-size: 0.8em">
                                            <?php echo $prod->price;?>
                                        </span><br>
                                        <span style="font-size: 0.8em">
                                            <?php echo $prod->qty.$prod->per;?>
                                        </span>
										</div>
										</div>
									<?php } ?>
                                	</div>
                                </td>
                                <td><?php echo $list->item_count; ?></td>
                                <td><?php echo $list->total; ?></td>
                                <td><?php echo $list->order_type; ?></td>
                                <td><?php echo $list->payment_method; ?></td>
                                <td><?php echo $list->supp_name; ?></td>
                                <td><?php echo $date;?></td>
                            </tr>

                        <?php } ?>
                        
                       </table>
                    <?php else:?>
                        <h3 style="padding: 10px;">No Records...</h3>
                    <?php endif;?>
                   
                </div>
            </div>

            <!-- Copyrights -->
            <?php $this->load->view('inc/copyrights'); ?>
            
        </div>
