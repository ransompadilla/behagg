<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>My Listings</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?php echo site_url();?>">Home</a></li>
							<li><a href="dashboard">Dashboard</a></li>
							<li>My Listings</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<!-- Headline -->
		<div class="row">
			<div class="col-md-12">
				<div id="notify" class="notify" align="center">
					<?php 
					
					if($this->session->flashdata('notify') != '' ){
						$notify = $this->session->flashdata('notify');
						if($notify['status'] == true){
							echo '<div class="notification success closeable">
								<p>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}else{
							echo '<div class="notification error closeable">
								<p><span>Error! </span>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}
					}
					?>
						
				</div>
			</div>
		</div>

		<div class="row">
			
			<!-- Listings -->
			<div class="col-lg-12 col-md-12 margin-top-45">
				<div class="dashboard-list-box margin-top-0">
					<h4>My Listings</h4>
						
						<?php 
						if($listings != ""): ?>
						<ul>
						<?php
								foreach($listings as $val):	
									$loc = unserialize($val->location);
									$abbrev = $loc['state']['abbrev'];
									$name = $loc['state']['name'];
								?>
									<li >
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="#list<?php echo $val->id_list;?>" class="popup-with-zoom-anim">
												<?php
												
												if($val->media != ''):
													$media = unserialize($val->media);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->com_name ?>"></a>
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php 
												endif;
												?>
												
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->com_name; ?></a></h3>
													<span><?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></span>
													
													<!--div class="star-rating" data-rating="3.5">
														<div class="rating-counter">(12 reviews)</div>
													</div-->
												</div>
											</div>
										</div>
										<div class="buttons-to-right">
											<a href="<?php echo site_url('user/edit_listing/'.$val->id_list); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>

											<a href="#" class="btnDelete button gray" id="<?php echo $val->com_name."_".$val->id_list; ?>"><i class="sl sl-icon-close"></i> Delete</a>
										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
						
				</div>
			</div>
            
            <!-- Copyrights -->
            <?php include 'inc/copyrights.php'; ?>

        </div>
<?php 
	if($listings != ""): 
		foreach($listings as $val): 
			$loc = unserialize($val->location);
			$abbrev = $loc['state']['abbrev'];
			$name = $loc['state']['name'];
			?>

		<div id="list<?php echo $val->id_list;?>" class="zoom-anim-dialog mfp-hide">
            
            <div class="message-reply margin-top-0">
            	<div class="row">
            		<div class="col-sm-8">
            			<?php
						if($val->media != ''):
							$media = unserialize($val->media);
							if(array_key_exists('images', $media) && $media['images'] != ''):
								$display = $media['images'];
						?>
							<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->com_name ?>"></a>
							<?php 	else: ?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
							<?php
							endif;
							else:
							?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
							<?php 
						endif;
						?>
            		</div>
            		<div class="col-sm-4">
						<h1><?php echo $val->com_name;?></h1>
						<h3>Description: </h3><h4><?php echo $val->description;?></h4>
						<h3>Livestock: </h3>
						
							<?php
							$livestock = unserialize($val->livestock);
							if($livestock){
								if($livestock['livestock'] != ""){
									foreach ($livestock['livestock'] as $stock) { ?>
									<h4>
										<?= 'Name: '.$stock['name'].' => Price: '.$stock['price'].'/'.$stock['num'].$stock['per'] ?><br>
									</h4>
								<?php	
									}
								}
								?>
								<h3>Add Ons</h3>
								<?php
								if($livestock['add_on'] != ""){
									foreach ($livestock['add_on'] as $add) { ?>
									<h4>
										<?= 'Product: '.$add['product'].' => Price: '.$add['price'].'/'.$add['num'].''.$add['per'] ?><br>
									</h4>
								<?php	
									}
								}
							}
							?>
						
						<h3>Location: </h3><h4><?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></h4>
            		</div>
            	</div>
            </div>
    	</div>
 <?php 
	endforeach; 
  endif; 
 ?>