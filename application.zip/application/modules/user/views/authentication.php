<section class="container">
	<div class="row text-center">
		<h1><?php echo $pagename?></h1>
		<?php if($notify['status'] == true): ?>
		<p class="notification success"><?php echo $notify['msg']; ?></p>
		<?php else: ?>
		<p class="notification error"><?php echo $notify['msg']; ?></p>
		<?php endif; ?>
	</div>	
</section>
	



			