
<div class="row">
    <div class="col-lg-12">
    <h2>Place / Branch</h2>
    <?php 
    if($branch != ""):
        $loc = unserialize($branch->supp_address);
        $abbrev = $loc['state']['abbrev'];
        $name = $loc['state']['name'];
    ?>
    <div class="dashboard-list-box">
                    
                        <ul>
                        <li >
                                        <div class="list-box-listing">
                                            <div class="list-box-listing-img"><a href="#list<?php echo $branch->supp_id;?>" class="popup-with-zoom-anim">
                                                <?php
                                                
                                                if($branch->media != ''):
                                                    $media = unserialize($branch->media);
                                                        if(array_key_exists('images', $media) && $media['images'] != ''):
                                                            $display = $media['images'];
                                                ?>
                                                    <img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $branch->supp_name ?>">
                                                <?php   else: ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php
                                                        endif;
                                                else:
                                                ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php 
                                                endif;
                                                ?>
                                                </a>
                                            </div>
                                            <div class="list-box-listing-content">
                                                <div class="inner">
                                                    <h3><a href="#"><?php echo $branch->supp_name; ?></a></h3>
                                                    <div><?php echo $branch->supp_desc; ?></div>
                                                    <span><?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></span>
                                                    
                                                    <!--div class="star-rating" data-rating="3.5">
                                                        <div class="rating-counter">(12 reviews)</div>
                                                    </div-->
                                                </div>
                                            </div>
                                        <div class="buttons-to-right">
                                            <a href="<?php echo site_url('user/edit_branch/'.$branch->supp_id); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>

                                            <a href="#" class="btnDeleteBranch button gray" id="<?php echo $branch->supp_id."_".$branch->supp_name; ?>"><i class="sl sl-icon-close"></i> Delete</a>
                                        </div>

                                        </div>
                                    </li>
                        
                        </ul>

                        
                </div>
    </div>
    <div class="col-lg-12">
            <h2><?php echo $pagename ?></h2>
    </div>
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/add-product/'.$branch->supp_name.'/'.$branch->supp_id)); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if($this->session->flashdata('notify') != '' ){
                        $notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                </div>
       
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Category</h5>
                    	<select name="category">
                            <option value="">Choose Category</option>
                            <?php
                                if($categories){
                                    foreach ($categories as $key => $val) { ?>
                                    <option value="<?= $val->cat_id?>"><?= $val->cat_name ?></option>
                            <?php         
                                    }
                                }
                            ?>
                        </select>
                    	<div class="row">
                            <div class="col-sm-6">
                            <h5>No. of OLD</h5>
                                <div class="col-sm-8">
                                <input type="number" name="num" style="height: 40px;">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <h5>No. of Old By</h5>
                                <div class="col-sm-8">
                                <select name="old_by" style="height: 40px;padding: 5px;">
                                    <option value="day">Day</option>
                                    <option value="week">Week</option>
                                    <option value="month">Month</option>
                                    <option value="year">Year</option>
                                </select>
                                </div>
                            </div>
                        </div>
                        

                        
                    </div>
                
                </div>
                <!-- Row / End -->

            </div>
            
            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>  
    <div id="list<?php echo $branch->supp_id;?>" class="zoom-anim-dialog mfp-hide">
            
            <div class="message-reply margin-top-0">
                <div class="row">
                    <div class="col-sm-6">

                        <h2><?php echo $branch->supp_name;?></h2>
                        <h4><i class="fa fa-map-marker"></i> <?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></h4>
                        <?php
                        if($branch->media != ''):
                            $media = unserialize($branch->media);
                            if(array_key_exists('images', $media) && $media['images'] != ''):
                                $display = $media['images'];
                        ?>
                            <img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $branch->supp_name ?>">
                            <?php   else: ?>
                            <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                            <?php
                            endif;
                            else:
                            ?>
                            <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                            <?php 
                        endif;
                        ?>
                        <h4><?php echo $branch->supp_desc;?></h4>
                        
                    </div>
                    <div class="col-sm-6">
                        <h2>Products </h2>
                        <?php 
                        if($products){?> 
                        <ul>
                        <?php
                            foreach ($products as $key => $value) { 
                                $value = (object) $value;
                        ?>
                        <div class="row">
                        <div class="col-lg-12">
                            <div class="dashboard-list-box">
                                <li >
                                    <div class="list-box-listing">
                                    <div class="list-box-listing-img">
                                    <?php
                                                            
                                    if($value->cat_img != ''):
                                        $media = unserialize($value->cat_img);
                                        if(array_key_exists('images', $media) && $media['images'] != ''):
                                        $display = $media['images'];
                                                            ?>
                                        <img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $value->cat_name ?>">
                                        <?php   else: ?>
                                        <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                        <?php
                                        endif;
                                    else:
                                    ?>
                                        <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                    <?php endif;?>
                                    </div>
                                    <div class="list-box-listing-content">
                                        <div class="inner">
                                        <h3>Name: <?= $value->cat_name; ?></h3>
                                        <div><strong>Old: </strong><?= $value->num_of_old.' '.$value->old_by ?> </div>
                                        <div><strong>Rate: </strong><?= $value->rate.' / '.$value->rate_by ?></div>           
                                        <!--div class="star-rating" data-rating="3.5">
                                        <div class="rating-counter">(12 reviews)</div>
                                        </div-->
                                        </div>
                                    </div>
                                    <div class="buttons-to-right">
                                        <a href="<?php echo site_url('user/edit_product/'.$value->prod_id); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>
                                        <a href="#" class="btnDeleteProduct button gray" id="<?php echo $value->prod_id."_".$value->cat_name."_".$branch->supp_name; ?>"><i class="sl sl-icon-close"></i> Delete</a>
                                    </div>
                                    </div>
                                </li>
                                    
                            </div>
                        </div>
                    </div>
                        <?php   
                            }
                        ?>
                    </ul>
                    <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php else:?>
            <div>
            <p class="center"><stong>No Data Found</stong></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Copyrights -->
    <?php $this->load->view('inc/copyrights'); ?>

</div>
