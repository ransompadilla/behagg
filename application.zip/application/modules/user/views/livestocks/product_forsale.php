<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <!-- Breadcrumbs -->
	                <nav id="breadcrumbs">
	                    <ul>
	                        <li>
                                <a href="<?php echo site_url('user/branch_list'); ?>"><?php echo ($page1) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var); ?>"><?php echo ($page2) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var.'/'.$var2
                                ); ?>"><?php echo ($page3) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$var3
                                ); ?>"><?php echo ($page4) ?></a>
                            </li>
	                    </ul>
	                </nav>
                </div>
            </div>
        </div>
<div class="row">
    		<div class="col-md-3"></div>
    		<div class="col-md-6">
    			<div class="plan featured" style="margin-top: 20px;">
    				<a href="#">
					<div class="plan-price">
						<h3>For Sale</h3>
						<span class="value"> <?= $count_prod_forsale ?> </span>
						<span class="period">Product for sale</span>
					</div>
					</a>
				</div>
    		</div>
    		<div class="col-md-3"></div>
    	</div>
<?php if($product_forsale){ foreach ($product_forsale as $key => $prod) { 
	$result = $this->livestocks->getProductAge($prod->prod_id);
	?>
	
					<!-- Listing Item -->
					<div class="col-lg-3 col-md-6">
						<a href="#see-product-forsale<?= $prod->prod_id ?>" data-toggle="modal" class="listing-item-container">
							<div class="listing-item">
									<?php 
									$media = unserialize($prod->cat_img);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $prod->prod_code ?>">
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php 
									endif;
									?>
																
								<div class="listing-item-content">
									<h3><?php echo $result['age'] ?><i class="verified-icon"></i></h3>
									<span>Code:<?php echo $result['code'];?></span><br>
									<span>Price: <?php echo $prod->price_rate;?></span>
								</div>
								<span class="like-icon"></span>
							</div>
							<!-- <div class="star-rating" data-rating="3.5">
								<div class="rating-counter">(12 reviews)</div>
							</div> -->
						</a>
					</div>

<?php } } ?>
<?php include 'modals/see_product_forsale.php'; ?>