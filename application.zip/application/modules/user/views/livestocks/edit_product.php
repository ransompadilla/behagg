<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo $pagename ?></h2>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/edit_product')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if($this->session->flashdata('notify') != '' ){
						$notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                </div>
       
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-12">
                    	<input type="hidden" name="prod_id" value="<?php echo $product->prod_id ?>">
                    	<input type="hidden" name="supp_id" value="<?php echo $product->supp_id ?>">
                    	<h5>Livestock Name</h5>
                    	<input type="input" name="product" class="input-livestock search-field" placeholder="Name" value="<?php echo $product->prod_name ?>">
                        <h5>Description</h5>
                        <textarea class="WYSIWYG" name="description" cols="40" rows="3" id="summary" spellcheck="true"><?php echo $product->prod_description ?></textarea>
                        <h5>Price Rate</h5>
                        <div class="row">
                        <div class="col-md-6">
                          <div class="col-sm-3">
                            <label style="float: right;">Price:</label>
                          </div>
                          <div class="col-sm-9">
                            <input type="text" placeholder="Price" name="price" value="<?php echo $product->prod_price ?>" style="height: 40px;" required>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="col-sm-3">
                            <label style="float: right;">Per:</label>
                          </div>
                          <div class="col-sm-4">
                            <select name="per" style="height: 40px;padding: 5px;">
                            <?php
                             $per = array('klg', 'pcs', 'cont');
                                foreach ($per as $key => $value):?>
                                  <option <?= ($value == $product->price_per) ? 'selected' : '';?> value="<?= $value?>"><?= $value?></option>
                                    <?php endforeach;?>
                            </select>
                          </div>
                        </div>
                        </div>
                    </div>
                
                </div>
                <!-- Row / End -->

            </div>
         	<!-- Section -->
            <div class="add-listing-section margin-top-45" style="overflow:hidden">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Photos</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                </div>
                <div class="submit-section">                    
                    <!-- Row -->
                    <div class="row with-forms"> 
                        <div class="col-md-12">  
                            Add Photos                
                            <input id="file-input" type="file" multiple="multiple" name="photo[]">
                            <div id="preview"></div>
                        </div>
                    </div>
                    <div class="row with-forms" style="border-top:1px solid #ddd;padding-top:20px;margin-top:20px">
                        <?php // *** photos *** //
                            if($product){
                                $media  = unserialize($product->prod_img);
                        ?>
                        <h4>Uploaded Photos</h4>
                         
                        <?php 
                            if(array_key_exists("images",$media) && $media['images'] != ''):
                                for($i=0;$i<count($media['images']);$i++):

                                $getname    = $media['images'][$i];
                                $imgname    = explode('.',$getname);
                        ?>
                            
                            <div class="col-lg-3 col-md-4 col-xs-6">
                                <div class="img-wrap">
                                    <input id="<?= $i ?>" type="hidden" name="current_photo[]" value="<?= $getname ?>">
                                    <span id="<?= $i ?>" class="close" >&times;</span>
                                    <img id="<?= $i ?>" src="<?php echo site_url('uploads/listing/'.$getname); ?>" class="img-thumbnail" alt="<?php echo $imgname[1] ?>">
                                </div>
                            </div>
                        <?php 

                                endfor; 
                            endif;
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>  
            
        
    </div>

    <!-- Copyrights -->
    <?php $this->load->view('inc/copyrights'); ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>