<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $page3; ?></h2>
                    <!-- Breadcrumbs -->
	                <nav id="breadcrumbs">
	                    <ul>
	                        <li>
                                <a href="<?php echo site_url('user/branch_list'); ?>"><?php echo ($page1) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var); ?>"><?php echo ($page2) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var2
                                ); ?>"><?php echo ($page3) ?></a>
                            </li>
	                    </ul>
	                </nav>
                </div>
            </div>
        </div>

<div class="row">
    <div class="col-lg-12">
    <?php 
    if($categories != ""):
        
    ?>
    <div class="dashboard-list-box">
                    
                        <ul>
        <?php foreach ($categories as $key => $val) { ?>
                        <li >

                                        <div class="list-box-listing">
                                            <div class="list-box-listing-img"><a href="#">

                                                <?php
                                                
                                                if($val->cat_img != ''):
                                                    $media = unserialize($val->cat_img);
                                                        if(array_key_exists('images', $media) && $media['images'] != ''):
                                                            $display = $media['images'];
                                                ?>
                                                    <img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->cat_name ?>">
                                                <?php   else: ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php
                                                        endif;
                                                else:
                                                ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php 
                                                endif;
                                                ?>
                                                </a>
                                            </div>
                                            <div class="list-box-listing-content">
                                                <div class="inner">
                                                    <h3><a href="#"><?= $val->cat_name; ?></a></h3>
                                                    <!-- <div>Rate: <?= $val->rate.' / '.$val->rate_by ?></div> -->
                                                   
                                                </div>
                                            </div>
                                        <div class="buttons-to-right">
                                            <input type="hidden" id="livestock_id" name="livestock_id" value="<?= $val->livestock_id ?>">
                                            <input type="hidden" id="url1" name="var" value="<?= $var ?>">
                                            <input type="hidden" id="url2" name="var2" value="<?= $var2 ?>">
                                            <input type="text" id="title" name="title" placeholder="Title">
                                            <input type="text" id="description" name="description" placeholder="Descripition">
                                            <button type="button" class="btnAddSubcategory button gray" style="width: 100%"><i class="sl sl-icon-plus"></i> ADD</button>
                                            <div id="sub_cat_msg"></div>
                                        </div>

                                        </div>
                                    </li>
                        <?php } ?>
                        </ul>
        </div>
        <?php else:?>
            <div>
            <p class="center"><stong>No Data Found</stong></p>
            </div>
        <?php endif; ?>
    </div>
    <?php if($product_forsale){ ?>
    <div class="col-lg-12">
    	<div class="row">
    		<div class="col-md-3"></div>
    		<div class="col-md-6">
    			<div class="plan featured" style="margin-top: 20px;">
    				<a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/product-forsale') ?>" data-toggle="modal">
					<div class="plan-price">
						<h3>For Sale</h3>
						<span class="value"><?= $count_prod_forsale ?> </span>
						<span class="period">Product for sale</span>
					</div>
					</a>
				</div>
    		</div>
    		<div class="col-md-3"></div>
    	</div>
    </div>
<?php } ?>
    <div id="sub_category" class="img-wrap">
    	<?php if($sub_categories){ foreach ($sub_categories as $key => $val) { 
    		$t_qty=0;
    		$p_qty = $this->livestocks->getProductQty(array('sub_id'=>$val->sub_id, 'for_sale'=>0));
    		$products = $this->livestocks->getProducts(array('cat.supp_id'=>$branch->supp_id,'sub.livestock_id'=>$val->livestock_id, 'prod.sub_id'=>$val->sub_id, 'prod.for_sale'=> 0));
    		$d_len = strlen($val->sub_description);
			if($d_len > 25){
				$description = substr($val->sub_description, 0, 25).'...';
			}
			else{$description = $val->sub_description;}
    		?>
    		<?php 
			if($this->session->flashdata('notify') != '' ){
				$notify = $this->session->flashdata('notify');
				if($notify['status'] == true && $notify['new_sub_title'] == $val->sub_title){ ?>
    		<div class="col-lg-3 col-md-6" id="<?= $val->sub_title ?>">
    			
    			<span id="<?= $val->sub_title ?>" class="remove_sub_cat close" style="position: absolute; right: 20px; top: -5px;">&times;</span>
    			<a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$val->sub_title.'.'.$val->sub_id) ?>">
                <div class="dashboard-stat color-2">
                    <div class="dashboard-stat-content">
                    	<h2>
                    		<strong><?= ucwords($val->sub_title) ?></strong>
                    	</h2> 
                    <?php if($p_qty){ foreach ($p_qty as $key => $qty) { $t_qty += $qty->p_qty; } } ?>
                    <h4><?= $t_qty ?></h4>
                    <span style="color: yellow;font-size: 0.9em; padding: -80px"><?= $notify['msg'] ?></span>
                    
                	</div>
                    <div class="dashboard-stat-icon"><a href="#add-product<?= $val->sub_id ?>" data-toggle="modal" style="color: #fefefe;"><i class="sl sl-icon-plus"></i></a></div>
                </div>
                </a>
            </div>
			<?php } else{ ?>
				<div class="col-lg-3 col-md-6" id="<?= $val->sub_title ?>">
	    			
	    			<span id="<?= $val->sub_title ?>" class="remove_sub_cat close" style="position: absolute; right: 20px; top: -5px;">&times;</span>
	    			<a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$val->sub_title.'.'.$val->sub_id) ?>">
	                <div class="dashboard-stat color-2">
	                    <div class="dashboard-stat-content">
	                    	<h2>
	                    		<strong><?= ucwords($val->sub_title) ?></strong>
	                    	</h2> 
	                    <?php if($p_qty){ foreach ($p_qty as $key => $qty) { $t_qty += $qty->p_qty; } } ?>
	                    <h4><?= $t_qty ?></h4>
	                    <span style="color: #fefefe; font-size: 0.9em;"><?= $description ?></span></div>
	                    <div class="dashboard-stat-icon"><a href="#add-product<?= $val->sub_id ?>" data-toggle="modal" style="color: #fefefe;"><i class="sl sl-icon-plus"></i></a></div>
	                </div>
	                </a>
	            </div>
			 <?php } }else{ ?>
				<div class="col-lg-3 col-md-6" id="<?= $val->sub_title ?>">
	    			
	    			<span id="<?= $val->sub_title ?>" class="remove_sub_cat close" style="position: absolute; right: 20px; top: -5px;">&times;</span>
	    			<a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$val->sub_title.'.'.$val->sub_id) ?>">
	                <div class="dashboard-stat color-2">
	                    <div class="dashboard-stat-content">
	                    	<h2>
	                    		<strong><?= ucwords($val->sub_title) ?></strong>
	                    	</h2> 
	                    <?php if($p_qty){ foreach ($p_qty as $key => $qty) { $t_qty += $qty->p_qty; } } ?>
	                    <h4><?= $t_qty ?></h4>
	                    <span style="color: #fefefe;font-size: 0.9em;"><?= $description ?></span></div>
	                    <div class="dashboard-stat-icon"></div>
	                </div>
	                </a>
	            </div>
			<?php } ?>
	

    	<?php } } ?>
    </div>
   
    <!-- Copyrights -->
    <?php $this->load->view('inc/copyrights'); ?>

</div>
