<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <!-- Breadcrumbs -->
	                <nav id="breadcrumbs">
	                    <ul>
	                        <li>
                                <a href="<?php echo site_url('user/branch_list'); ?>"><?php echo ($page1) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var); ?>"><?php echo ($page2) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var.'/'.$var2
                                ); ?>"><?php echo ($page3) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$var3
                                ); ?>"><?php echo ($page4) ?></a>
                            </li>
	                    </ul>
	                </nav>
                </div>
            </div>
        </div>
<div class="row">
    		<div class="col-md-3"></div>
    		
    		<div class="col-md-6">
                <div class="dashboard-stat color-2">
                    <div class="dashboard-stat-content">
                    	<h2>
                    		<strong><?= $sub_cat->sub_title ?></strong>
                    	</h2> 
                    
                    <h4><?= $p_qty ?></h4>
                    <span><?= $sub_cat->sub_description ?></span>
                	</div>
                    <div class="dashboard-stat-icon">
                    	<a href="#add-product<?= $sub_cat->sub_id ?>" data-toggle="modal" style="color: #fefefe;"><i class="sl sl-icon-plus"></i></a>
                    </div>
                </div>
            </div>
    		<div class="col-md-3"></div>
    	</div>
<?php if($products){
	$msg = ""; foreach ($products as $key => $prod) { 
	$result = $this->livestocks->getProductAge($prod->prod_id);

?>
					<!-- Listing Item -->
					<div class="col-lg-3 col-md-6">
						<a href="#see-product<?= $prod->prod_id ?>" data-toggle="modal" class="listing-item-container">
						
							<div class="listing-item">

									<?php 
									$media = unserialize($prod->cat_img);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $prod->prod_code ?>">
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php 
									endif;
									?>
															
								<div class="listing-item-content">
									<button class="button" data-toggle="modal" data-target="#change-product-status<?= $prod->prod_id ?>"><i class="sl sl-icon-plus"></i></button>
									<h3><?php echo $result['age'].'  '.$msg ?></h3>
									<span>Code:<?php echo $result['code'];?></span><br>
									<span><?php echo $result['gender'];?></span><br>

									<span>
										<button class="button" data-toggle="modal" data-target="#edit-product<?= $prod->prod_id ?>"><i class="sl sl-icon-note"></i></button>
									
									
									<button class="button" data-toggle="modal" data-target="#move-product<?= $prod->prod_id ?>"><i class="fa fa-arrow-right"></i></button></span>
								</div>
							</div>
                                          
                                        
							<!-- <div class="star-rating" data-rating="3.5">
								<div class="rating-counter">(12 reviews)</div>
							</div> -->
						</a>
					</div>


				<?php include 'modals/see_product.php'; ?>
				<?php include 'modals/edit_product.php'; ?>
				<?php include 'modals/move_product.php'; ?>
				<?php include 'modals/forsale_product.php'; ?>
				<?php include 'modals/change_product_status.php'; ?>
<?php } } ?>

				<?php include 'modals/add_product.php'; ?>