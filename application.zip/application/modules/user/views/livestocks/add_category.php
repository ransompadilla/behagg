<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo $pagename ?></h2>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/add_livestock_category')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if($this->session->flashdata('notify') != '' ){
                        $notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                </div>
       
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-12">
                    	
                    	<h5>Category Name</h5>
                    	<input type="input" name="cat_name" class="input-livestock search-field" placeholder="Name" value="<?php echo set_value('cat_desc') ?>">
                        <h5>Category Description</h5>
                        <textarea class="WYSIWYG" name="cat_desc" cols="40" rows="3" id="summary" spellcheck="true"><?php echo set_value('cat_desc') ?></textarea>
                        
                    </div>
                
                </div>
                
               <!--  <div class="row">
                    <div class="col-md-6">
                    <h5>Price Rate</h5>
                    <div class="col-sm-8">
                        <input type="number" placeholder="Rate" name="rate" value="<?php echo set_value('price') ?>" style="height: 40px;" required>
                    </div>
                    </div>
                    <div class="col-md-6">
                    <h5>Rate By</h5>
                    <div class="col-sm-8">
                        <select name="rate_by" style="height: 40px;padding: 5px;">
                            <option value="day">Day</option>
                            <option value="week">Week</option>
                            <option value="month">Month</option>
                            <option value="year">Year</option>
                            <option value="klg">Klg</option>
                            <option value="pcs">Pcs</option>
                        </select>
                    </div>
                    </div>
                </div> -->

            </div>
            <div class="add-listing-section">

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-12">
                    	<select name="supp_id">
                    		<option value="">Choose a Place/Branch</option>
                    		<?php 
                    			if($branches){
                    				foreach ($branches as $key => $value) { 
                    					$address = unserialize($value->supp_address);
                    					?>
                    					<option value="<?= $value->supp_id ?>"><?= $address['address'].', '.$address['state']['name'].', '.$address['city']; ?></option>
                    		<?php
                    				}
                    			}
                    		?>
                    	</select>
                    </div>
                </div>
            </div>
            <div class="add-listing-section margin-top-45">
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Images</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                    <div class="change-photo-btn" >
	                    <div class="photoUpload">
	                        <span><i class="fa fa-upload"></i> Upload Photo</span>
	                        <input id="file-input" class="upload" type="file" multiple="multiple" name="photo[]" >
	                    </div>
	                </div>
                </div>
                
                <div id="preview"></div>
                

            </div>

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>  
            
        
    </div>

    <!-- Copyrights -->
    <?php $this->load->view('inc/copyrights'); ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>