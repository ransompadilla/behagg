<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $page2; ?></h2>
                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs">
                        <ul>
                            <li>
                                <a href="<?php echo site_url('user/branch_list'); ?>"><?php echo ($page1) ?></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('user/q/'.$var); ?>"><?php echo ($page2) ?></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

<div class="row">
    <div class="col-lg-12">
    <?php 
    if($branch != ""):
        $loc = unserialize($branch->supp_address);
        $abbrev = $loc['state']['abbrev'];
        $name = $loc['state']['name'];
    ?>
    <div class="dashboard-list-box">
                    
                        <ul>
                        <li >
                                        <div class="list-box-listing">
                                            <div class="list-box-listing-img"><a href="#list<?php echo $branch->supp_id;?>" class="popup-with-zoom-anim">
                                                <?php
                                                
                                                if($branch->media != ''):
                                                    $media = unserialize($branch->media);
                                                        if(array_key_exists('images', $media) && $media['images'] != ''):
                                                            $display = $media['images'];
                                                ?>
                                                    <img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $branch->supp_name ?>">
                                                <?php   else: ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php
                                                        endif;
                                                else:
                                                ?>
                                                    <img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
                                                <?php 
                                                endif;
                                                ?>
                                                </a>
                                            </div>
                                            <div class="list-box-listing-content">
                                                <div class="inner">
                                                    <h3><a href="#"><?php echo $branch->supp_name; ?></a></h3>
                                                    <div><?php echo $branch->supp_desc; ?></div>
                                                    <span><?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></span>
                                                    
                                                    <!--div class="star-rating" data-rating="3.5">
                                                        <div class="rating-counter">(12 reviews)</div>
                                                    </div-->
                                                </div>
                                            </div>
                                        <div class="buttons-to-right">
                                            <a href="<?php echo site_url('user/edit_branch/'.$branch->supp_id); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>

                                            <a href="#" class="btnDeleteBranch button gray" id="<?php echo $branch->supp_id."_".$branch->supp_name; ?>"><i class="sl sl-icon-close"></i> Delete</a>
                                        </div>

                                        </div>
                                    </li>
                        
                        </ul>
        </div>
        <?php else:?>
            <div>
            <p class="center"><stong>No Data Found</stong></p>
            </div>
        <?php endif; ?>
    </div>
    <div class="col-lg-12">

    <h2> Your Livestocks &nbsp; &nbsp; <a href="<?php echo site_url('user/q/'.$var.'/add-livestock-category'); ?>"><i class="sl sl-icon-plus"></i></a></h2>
    	<?php
	    if($categories != '' && $branch != ''){?>
	   
	    <?php foreach ($categories as $key => $val) { ?>
	       		<div class="col-lg-4 col-md-12">
						<a href="<?php echo site_url('user/q/'.$var.'/'.$val->cat_description.'.'.$val->livestock_id) ?>" class="listing-item-container">
							<div class="listing-item">
									<?php 
									$media = unserialize($val->cat_img);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $val->cat_name ?>">
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php 
									endif;
									?>
																
								<div class="listing-item-content">
									<h3><?php echo $val->cat_name ?><i class="verified-icon"></i></h3>
									
								</div>
								<span class="like-icon"></span>
							</div>
							
						</a>
					</div>
	    <?php } ?>
	    	
	    <?php } ?>
    </div>
    <div class="col-lg-12">
    	<div id="load-category"></div>
    </div>
    
    <!-- Copyrights -->
    <?php $this->load->view('inc/copyrights'); ?>

</div>
