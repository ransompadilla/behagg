<div id="forsale-product<?= $prod->prod_id ?>" class="modal fade" role="dialog">
		<div class="modal-content" style="background: #fefefe;">
			<span class="popclose">&times;</span>
			<h4>Product CODE: <span class="color-a0a0a0"><?= $result['code'] ?></span> </h4><hr>
			<?php echo form_open_multipart(site_url('livestocks/product-forsale/'.$var.'/'.$var2.'/'.$var3)); ?>
			<input type="hidden" name="prod_id" value="<?= $prod->prod_id ?>">
			<input type="hidden" name="prod_code" value="<?= $prod->prod_code ?>">
			<input type="hidden" name="supp_id" value="<?= $prod->supp_id ?>">
			<input type="hidden" name="livestock_id" value="<?= $prod->livestock_id ?>">
			<input type="text" name="price_rate" placeholder="Price rate">
			<button type="submit" class="button">Submit</button>
			<?php echo form_close(); ?>
		</div>
	</div>