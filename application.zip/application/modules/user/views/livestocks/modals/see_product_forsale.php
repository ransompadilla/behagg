	
<?php if($product_forsale){ foreach ($product_forsale as $k => $prod) { ?>
						<!-- SEE PRODUCT MODAL -->
			    		<div id="see-product-forsale<?= $prod->prod_id ?>" class="modal fade" role="dialog">
			    			<?php 
			    				$data = array('ph.prod_id' => $prod->prod_id);
			    				$product_history = $this->livestocks->getProductHistory($data); ?>
								  <!-- Modal content -->
								  <div class="modal-content" style="background: #fefefe;">

								  	<span class="popclose">&times;</span>
								  	<!-- <h3><span>ROOM: <i class="color-a0a0a0"><?= $prod->sub_title;?></i></span></h3> -->
								  	<hr>
								  	<!-- <?php echo form_open_multipart(site_url('livestocks/edit-product/'.$branch->supp_id.'/'.$val->livestock_id)); ?> -->
								  	<div class="row">
								  	<div class="col-sm-6">
								  		<h4>CODE: <span class="color-a0a0a0"><?= $result['code'] ?></span></h4>
								  	</div>
									<div class="col-sm-6">
									  	<h4>AGE: <span class="color-a0a0a0"><?= $result['age'] ?></span></h4>
									</div>
								  	<div class="col-sm-6 product_code">
								  		<h4>Mother CODE: <span class="color-a0a0a0"><?= $prod->mother ?></span></h4>
								  	</div>
								  	<div class="col-sm-6">
								  		<div class="row">
								  			<div class="col-sm-9">
								  				<h4>Status: <?= ($prod->status == 0 ? '<span style="color: #a0a0a0">Normal</span>' : ($prod->status == 1 ? '<span style="color: green">Pregnant</span>': '<span style="color: red">Uncondition</span>') ) ?></h4>
								  			</div>
								  			<div class="col-sm-3">
								  				<a href="#change-product-status<?= $prod->prod_id ?>" data-toggle="modal"><i class="fa fa-edit"></i></a>
								  			</div>
								  		</div>
								  	</div>
								  	
								  	<div class="col-sm-12">
								  		<input type="hidden"  name="prod_id" value="<?= $prod->prod_id ?>" />
								  		<input type="hidden"  name="sub_id" value="<?= $prod->sub_id ?>" />
								  		
								  	</div>
								  	<div class="col-sm-6">
								  	<h4>Date of Birth: <span class="color-a0a0a0"><?= Date('F j, Y', strtotime($prod->date_birth)) ?></span></h4>
								  	</div>
								  	<div class="col-sm-6">
								  		<h4>Gender: <span class="color-a0a0a0"><?= ($prod->gender == 'M'  ? 'Male':'Female' ) ?></span></h4>
								  	</div>
								  	<hr>

								  	<div class="col-lg-12">

								  		<div style="text-align: center" class="color-a0a0a0">
								  		_________________ History _________________
								  		<br>
								  		</div>
								  		<ul>
								  		<?php if($product_history){ foreach ($product_history as $key => $ph) { ?>
								  			<li style="background: #d0d0d0; margin: 5px; padding: 0px 10px 0px 10px">
								  				<?= $ph->details ?> at <?= Date('F j, Y', strtotime($ph->date)) ?>
								  			</li>
								  		<?php } } ?>
								  		</ul>
								  	</div>
								    </div>
								    <div class="popcontent">
								    	<a href="#forsale<?= $prod->prod_id ?>" data-toggle="modal" class="button" style="width: 100%; text-align: center"><?= ($prod->for_sale == 0 ? '<i class="fa fa-money"></i> For sale' : ($prod->for_sale == 1 ? '<i class="fa fa-edit"></i>  Mark as sold':'sold') ) ?> </a>
								    </div>
								    <!-- <?php echo form_close(); ?> -->
								  </div>
								</div>
				<?php } } ?>