
<!-- EDIT Product MODAL -->
			    		<div id="edit-product<?= $prod->prod_id ?>" class="modal fade" role="dialog">

								  <!-- Modal content -->
								  <div class="modal-content" style="background: #e0e0e0;">

								  	<span class="popclose">&times;</span>
								  	
								  	<h3>Edit Product</h3>

								  	<hr>
								  	<?php echo form_open_multipart(site_url('livestocks/edit-product/'.$var.'/'.$var2.'/'.$var3)); ?>
								  	<div class="col-sm-6 product_code">
								  		<h4>CODE</h4>
								  		<input type="text" name="pcode" value="<?=$result['code'] ?>" readonly/>
								  	</div>
								  	<div class="col-sm-6">
								  		<!-- <h4>Status</h4>
								  		<div class="p_status" >
								  		<?php 
								  			$status = array('Normal', 'Pregnant', 'Uncondition');
								  		?>
								  		<select name="status">
								  			<option value="0" <?php if($prod->status == 0){ echo 'selected'; }else{ echo '';} ?> ><?= $status[0] ?></option										  			<option value="1" <?php if($prod->status == 1){ echo 'selected'; }else{ echo '';} ?> ><?= $status[1] ?></option>
										  	<option value="2" <?php if($prod->status == 2){ echo 'selected'; }else{ echo '';} ?> ><?= $status[2] ?></option>
										</select>
								  		</div> -->								  		
								  	</div>
								  	<div class="col-sm-12">
								  		<input type="hidden"  name="prod_id" value="<?= $prod->prod_id ?>" />
								  		<input type="hidden"  name="sub_id" value="<?= $prod->sub_id ?>" />
								  		<h4>From / Mother CODE</h4>
								  		<select name="mother">
								  			<option value="Unknown" <?php if($prod->mother == 'Unknown'){ echo 'selected'; }else{echo '';} ?> >Unknown</option>
								  			<?php if($preg_list){foreach ($preg_list as $key => $preg) { ?>
								  				<option value="<?= $preg->prod_code ?>" <?php if($prod->mother == $preg->prod_code){ echo 'selected'; }else{echo '';} ?> ><?= $preg->prod_code ?></option>
								  			<?php } } ?>
								  		</select>
								  	</div>
								  	<div class="col-sm-12">
								  	<h4>Date Of Birth</h4>
								  	<input type="date" name="date_birth" value="<?= $prod->date_birth ?>" required="" />
								  	</div>
								  	<div class="col-sm-12">
								  		<h4>Gender</h4>
								  		<select name="gender" required="">
								  			<option value="">Gender</option>
								  			<option value="M" <?php if($prod->gender === 'M'){ echo 'selected'; }else{echo '';} ?> >Male</option>
								  			<option value="F" <?php if($prod->gender === 'F'){ echo 'selected'; }else{echo '';} ?> >Female</option>
								  		</select>
								  	</div>
								  	
								  	<hr>
								  	
								    <div class="popcontent">
								    	
								    		<div class="col-sm-6">
								    			<button type="submit" class="button" style="width: 100%"><i class="fa fa-edit"></i> Update</button>
								    		</div>
								    		<div class="row">
								    		<div class="col-sm-6">
								    			<button type="button" class="popclose button" style="width: 100%"> Cancel</button>
								    		</div>
								    	</div>
								    </div>
								    <?php echo form_close(); ?>
								  </div>
								</div>