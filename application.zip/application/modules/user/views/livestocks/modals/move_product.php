<!-- MOVE PRODUCT -->	
						<div id="move-product<?= $prod->prod_id ?>" class="modal fade" role="dialog">
							<div class="modal-content" style="background: #e0e0e0;">
								<?php echo form_open_multipart(site_url('livestocks/move-product/'.$var.'/'.$var2.'/'.$var3)); ?>
									<input type="hidden" name="prod_id" value="<?= $prod->prod_id.'-'.$prod->prod_code ?>">
									<input type="hidden" name="p_old" value="<?= $result['age'] ?>">
									<span class="popclose">&times;</span>
								  	<h4>Move <i class="fa fa-arrow-right"></i></h4>
								  	<hr>
								  	<div class="row">
								  		<div class="col-sm-4">
								  			<h4>Code:<?= $result['code'] ?></h4>
								  		</div>
								  		<div class="col-sm-3">
								  			<h3 style="text-align: center">Move <i class="fa fa-arrow-right"></i></h3>
								  		</div>
								  		<div class="col-sm-5">
								  			<div class="row">
								  				<div class="col-sm-9">
								  					<?php if($sub_categories){ ?>
								  					<select name="to_sub_id" style="width: 100%; padding: 0px 5px 0px 5px;">
											  			<?php foreach ($sub_categories as $k => $sub_cat) { ?>
											  					<option value="<?= $sub_cat->sub_id.'-'.$sub_cat->sub_title ?>"><?= $sub_cat->sub_title ?></option>
											  			<?php } ?>
											  		</select>
											  		<?php } ?>
								  				</div>
								  				<div class="col-sm-3 move">
								  					<h3><button type="submit" class="button"><i class="fa fa-arrow-right"></i></button></h3>
								  				</div>
								  			</div>
								  			
								  		</div>
								  	</div>
					   			<?php echo form_close(); ?>
							</div>
						</div>	