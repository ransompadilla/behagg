<div id="change-product-status<?= $prod->prod_id ?>" class="modal fade" role="dialog">
		<div class="modal-content" style="background: #fefefe;">
			<span class="popclose">&times;</span>
			<div class="change-status-modal">
			<h4 id="change-success-msg">Change Product Status</h4>
			<hr>
				<div class="change-status">
					<?php $status = array('Normal', 'Pregnant', 'Uncondition'); ?>
					<select class="new_status" name="new_status">
						<?php foreach ($status as $key => $stat) { ?>
							<option value="<?= $key.'-'.$prod->prod_id.'-'.$prod->status ?>" <?= ($prod->status == $key ? 'selected':'' ) ?> >
								<?= $stat ?>
							</option>
						<?php } ?>
					</select>
				</div>
				<div class="status-details">
					<h4>Details</h4>
					<textarea id="status_details" name="status_details"></textarea>
					<input id="date_change_status" type="date" name="date" />
				</div>
				<div class="row">
					<div class="col-sm-6">
						<button type="button" class="btnChangeProductStatus button" style="width: 100%">Submit <i class="fa fa-sent"></i></button>
					</div>
					<div class="col-sm-6">
						<a href="<?php echo site_url('user/q/'.$var.'/'.$var2.'/'.$var3) ?>" class="button" style="width: 100%; text-align: center;">Cancel <i class="fa fa-sent"></i></a>
					</div>
				</div>
		</div>
	</div>
	</div>