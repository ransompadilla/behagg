<!-- Add Product MODAL -->
    		<div id="add-product<?= $sub_cat->sub_id ?>" class="modal fade" role="dialog">

					  <!-- Modal content -->
					  <div class="modal-content" style="background: #e0e0e0;">

					  	<span class="popclose">&times;</span>
					  	<h3><span>ROOM: <?= $sub_cat->sub_title;?></span></h3>

					  	<hr>
					  	<?php echo form_open_multipart(site_url('livestocks/add-product/'.$var.'/'.$var2.'/'.$var3)); ?>
					  	<input type="hidden" id="sub_id" name="sub_id" value="<?= $sub_cat->sub_id ?>" />
					  	<div class="col-sm-12">
					  		<h4>From / Mother</h4>
					  		<select name="mother">
					  			<option value="Unknown">Unknown</option>
					  			<?php if($preg_list){foreach ($preg_list as $key => $preg) { ?>
					  				<option value="<?= $preg->prod_code ?>"><?= $preg->prod_code ?></option>
					  			<?php } } ?>
					  		</select>
					  	</div>
					  	<h4>Date Of Birth</h4>
					  	<input type="date" id="date_birth" name="date_birth" required="" />
					  	<div class="col-sm-12">
					  		<select name="gender" required="">
					  			<option value="">Gender</option>
					  			<option value="M">Male</option>
					  			<option value="F">Female</option>
					  		</select>
					  	</div>
					  	<div class="col-sm-6 product_code">
					  		<h4>CODE</h4>
					  		<input type="hidden" id="ptitle" name="ptitle" value="<?= $sub_cat->sub_title ?>" />
					  		<input type="hidden" id="prod_code" name="pcode" value="<?= $prod_code ?>" />
					  		<div id="p_code"></div>
					  	</div>
					  	<div class="col-sm-6">
					  		<div class="product_qty">
					  		<input type="number" id="prod_qty" name="qty" placeholder="Qty" required="" />
					  		</div>
					  		
					  	</div>
					  	<hr>
					  	
					    <div class="popcontent">
					    	<div class="row">
					    		<div class="col-sm-4"></div>
					    		<div class="col-sm-4">
					    			<button type="submit" class="button" style="width: 100%">Submit</button>
					    		</div>
					    	</div>
					    </div>
					    <?php echo form_close(); ?>
					  </div>
					</div>
			