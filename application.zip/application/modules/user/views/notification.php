<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo $pagename;?></h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><?php echo $pagename;?></li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    
    <!-- Listings -->
    <div class="col-lg-12">
    	<!-- Reply to review popup -->
            <div id="small-dialog" class="zoom-anim-dialog mfp-hide">
                <div class="small-dialog-header">
                    <h3>Subscribe</h3>
                </div>
                <div class="message-reply margin-top-0">
                	<!-- Row / Start -->
					<div class="row">
						<div class="col-md-12">
							<div class="pricing-container margin-top-30">

								<!-- Plan #3 -->         
								<div class="plan featured" style="min-height:600px;">

									<div class="listing-badges">
										<span class="featured">Featured</span>
									</div>

									<div class="plan-price">
										<h3>Basic Plan</h3>
										<span class="value"> $20 for 15 days </span>
										<span class="period">One time fee for one listing</span>
									</div>
									<div class="plan-features">
										<ul>
											<li>Create listings</li>
											<li>Browse all listings</li>
											<li>Send messages to anyone</li>
											<li>Receive messages from featured members only</li>
											<li>Can Upload Videos</li>
											<li>listing will be featured on front page slider</li>
											<li>Mobile number access**</li>
											<li>Social media content access**</li>
										</ul>
										<a href="<?php echo site_url('plan/pay/'.$basic);?>" class="button">Get Started </a>

									</div>
								</div>

								<!-- Plan #3 -->
								<div class="plan featured" style="min-height:600px;">
														 <div class="listing-badges">
										<span class="featured">Featured</span>
									</div>
									<div class="plan-price">
										<h3>Full Plan</h3>
										<span class="value">$30 for 30 days </span>
										<span class="period" style="color:#fff !important;">One time fee for one listing</span>
									</div>

									<div class="plan-features">
										<ul>
											<li>Create listings</li>
											<li>Browse all listings</li>
											<li>Send messages to anyone</li>
											<li>Receive messages from featured members only</li>
											<li>Can Upload Videos</li>
											<li>listing will be featured on front page slider</li>
											<li>Mobile number access**</li>
											<li>Social media content access**</li>
										</ul>
										<a href="<?php echo site_url('plan/pay/'.$full);?>" class="button">Get Started </a>
									</div>
								</div>

							</div>
						</div>
					</div>
                </div>
            </div>
        <div class="dashboard-list-box margin-top-0">

            <ul>

                <li>
                    <div class="comments listing-reviews">
                        <ul>
                        	<?php 
                        		if($notification):
                        			foreach ($notification as $notif):
                        			
	                        			$strDate = strtotime($notif->notif_date);
	                            		$notif_date = date('F j, Y @ h:i A', $strDate); 
	                            		if($notif->notif_status == 1): ?>
		                            		<li style="background: #e0e0e0; padding: 10px;">
				                                 
				                                <div class="col-md-11 comment-content"><div class="arrow-comment"></div>
				                                    <div class="comment-by">Admin <div class="comment-by-listing">@ <a href="#">Aussie Flat</a></div> <span class="date"><?= $notif_date;?></span>
				                                        <!-- <div class="star-rating" data-rating="5"></div> -->
				                                    </div>
				                                    <p><?php echo $notif->notif_message;?></p>
				                                    
				                                    <a href="#small-dialog" class="rate-review popup-with-zoom-anim"><i class="sl sl-icon-like"></i> Subscribe</a>
				                                </div>
				                            </li>
				                    <?php else: ?>
					                     	<li>
				                               
				                                <div class="col-md-11 comment-content"><div class="arrow-comment"></div>

				                                    <div class="comment-by">Admin <div class="comment-by-listing">@ <a href="#">Aussie Flat</a></div> <span class="date"><?= $notif_date;?></span>
				                                        <!-- <div class="star-rating" data-rating="5"></div> -->
				                                    </div>
				                                    <p><?php echo $notif->notif_message;?></p>
				                                    
				                                    <a href="#small-dialog" class="rate-review popup-with-zoom-anim"><i class="sl sl-icon-like"></i> Subscribe</a>
				                                </div>
				                            </li>
	                            	<?php endif;?>
                        	<?php endforeach;?>
                        	
                        	<?php endif;?>
                            
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    <!-- Copyrights -->
    <div class="col-md-12 text-center">
        <div class="copyrights">© 2017 Listeo. All Rights Reserved.</div>
    </div>
</div>
