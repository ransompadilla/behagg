<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Edit Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Edit Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<div class="container">
<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/edit-listing/'.$list_id)); ?>
            <input type="hidden" name="listing_id" value="<?php echo $list_id ?>" />
           
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            //$notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                    <h3><i class="sl sl-icon-doc"></i> Basic Informations</h3>
                </div>

                <!-- Title -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Company Name</h5>
                        <input type="input" name="com_name" class="search-field" value="<?php echo $listing->com_name; ?>" >
                    </div>
                </div>  


            </div>
            <!-- Section / End -->


              <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> Details</h3>
                </div>
                
                <?php 
                // **options**  
                    $loc = unserialize($listing->location);
                //print_r($more_options);
                ?>
                <!-- Description -->
                <div class="form">
                    <div class="row with-forms">
                        <div class="col-md-12">
                            <h5>Description</h5>
                            <textarea class="WYSIWYG" name="description" cols="40" rows="3" id="summary" spellcheck="true"><?php echo $listing->description; ?></textarea>
                        </div>
                        <!-- Address -->
                        <div class="col-md-12">
                            <h5>Location</h5>
                            <div id="location"></div>
                            <div class="col-md-4">
                                <input name="address" type="text" value="<?php echo $loc['address']; ?>" placeholder="e.g. 964 School Street">
                            </div>
                            <div class="col-md-4">
                                <input type="hidden" id="estate" value="<?php echo $loc['state']['name']; ?>">
                                <select name="state" id="state">
                                    <option value="">Select State</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <input type="hidden" id="ecity" value="<?php echo $loc['city']; ?>">
                                <select name="city" id="city">
                                    <option value="">Select City</option>
                                </select>
                            </div>
                        </div>

                       
                    </div>
                </div>                       


            </div>
            <!-- Section / End -->
            
             <div class="margin-top-45">
                <button class="button preview" type="submit">NEXT<i class="fa fa-arrow-circle-right"></i></button>
                    <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            <?php echo form_close(); ?>
                <!--  form  -->
                <!-- =============== -->
                <!-- END FORM -->
                <!-- =============== -->
        </div>
    </div>
    <!-- Copyrights -->
    
    <?php include 'inc/copyrights.php'; ?>
</div>
</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>