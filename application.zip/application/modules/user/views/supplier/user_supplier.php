
<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                	<div class="right-side">
                	<div class="user-menu" >
                		<div class="load-count-junk">
						 <?= $count_junk ?>
						 </div>
						<div class="dashboard-list-box">
							<?php include 'junk_suppliers.php'; ?>
						</div>
                	</div>
                	</div>
                	<h2><?php echo $pagename; ?></h2>
                </div>
            </div>
        </div>
        <!-- Notice -->
        <div class="row">
            <div class="col-md-12">
            	<div id="notify" class="notify" align="center">
					<?php 
					if($this->session->flashdata('notify') != '' ){
						$notify = $this->session->flashdata('notify');
						if($notify['status'] == true){
							echo '<div class="notification success closeable">
								<p>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}else{
							echo '<div class="notification error closeable">
								<p><span>Error! </span>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}
					}
					?>
						
				</div>
            </div>
        </div>
        <div class="row">

            <div class="col-lg-12">
                <div class="dashboard-list-box">
                    <?php 
						if($mysupplier != ""): ?>
						<ul id="supplier-list">
						<?php
								foreach($mysupplier as $val):	
									$val = (object) $val;
									$loc = unserialize($val->address);
									$abbrev = $loc['state']['abbrev'];
									$name = $loc['state']['name'];
								?>
									<li id="<?= $val->id ?>">
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="<?php echo site_url('user/livestocks/'.$val->name.'/'.$val->id);?>">
												<?php
												
												if($val->media != ''):
													$media = unserialize($val->media);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php 
												endif;
												?>
												</a>
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->name; ?></a></h3>
													<div><?php echo $val->description; ?></div>
													<span><i class="fa fa-map-marker"></i> <?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></span>
													
													<!--div class="star-rating" data-rating="3.5">
														<div class="rating-counter">(12 reviews)</div>
													</div-->
												</div>
											</div>
										<div class="buttons-to-right">
											<a href="#loading-modal" data-toggle="modal" class="btnJunkSupplier button gray" id="<?php echo $val->id."-".$val->user_id."-".$val->name; ?>"><i class="sl sl-icon-trash"></i> Junk</a>
										</div>

										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
                </div>
            </div>
            
            <!-- Copyrights -->
    	<?php $this->load->view('inc/copyrights'); ?>
        </div>
 	<?php include 'my_supplier.php'; ?>