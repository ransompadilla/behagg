<?php 
	if($mysupplier != ""): 

		foreach($mysupplier as $val): 
			$val = (object) $val;
			$loc = unserialize($val->address);
			$abbrev = $loc['state']['abbrev'];
			$name = $loc['state']['name'];
			?>

		<div id="list<?php echo $val->id;?>" class="zoom-anim-dialog mfp-hide">
            
            <div class="message-reply margin-top-0">
            	<div class="row">
            		<div class="col-sm-6">

						<h2><?php echo $val->name;?></h2>
						<h4><i class="fa fa-map-marker"></i> <?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></h4>
            			<?php
						if($val->media != ''):
							$media = unserialize($val->media);
							if(array_key_exists('images', $media) && $media['images'] != ''):
								$display = $media['images'];
						?>
							<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
							<?php 	else: ?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
							<?php
							endif;
							else:
							?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
							<?php 
						endif;
						?>
						<h4><?php echo $val->description;?></h4>
						
            		</div>
            		<div class="col-sm-6">
            			<div class="row">
            				<div class="col-sm-4"><h2>Products </h2></div>
            				<div class="col-sm-4"></div>
            				<div class="col-sm-4" id="shwCart">
	            				<?= $val->a_wish_count ?>
            				</div>
            			</div>
									
						
						<?php 
						if($livestocks){?> 
						<ul>
						<?php
							foreach ($livestocks as $key => $value) { 
								$value = (object) $value;
								if($val->id == $value->supp_id){
						?>
						<div class="row">
						<div class="col-lg-12">
			                <div class="dashboard-list-box">
			                 	<li >
									<div class="list-box-listing">
									<div class="list-box-listing-img">

									<?php
															
									if($value->p_img != ''):
										$media = unserialize($value->p_img);
										if(array_key_exists('images', $media) && $media['images'] != ''):
										$display = $media['images'];
															?>
										<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $value->p_name ?>">
										<?php 	else: ?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
										<?php
										endif;
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php endif;?>
									</div>
									<div class="list-box-listing-content">
										<div class="inner">
										<h3><?= $value->p_name; ?></h3>
										<div><?= $value->p_desc; ?></div>
										<span><?= $value->p_price ?>/<?= $value->p_per ?></span>				
										<!-- <div class="star-rating" data-rating="2.8">
										<div class="rating-counter">(12 reviews)</div>
										</div> -->
										<br>
										<div class="rating-counter<?= $value->p_id?>"><?= $value->wish_count ?></div>
										</div>
									</div>

									<div class="buttons-to-right">
										<!-- <a href="#qtyModal" data-toggle="modal" class="button gray"><i class="sl sl-icon-list"></i> Add to Cart</a> -->
										<a href="#qtyModal<?=$value->p_id?>" data-toggle="modal" class="button gray"><i class="sl sl-icon-note"></i> Add to WishList</a>
									</div>
									</div>
								</li>
									
			                </div>
			            </div>
			        </div>
			        <!-- QTY MODAL -->
			        <div id="qtyModal<?= $value->p_id?>" class="modal fade" role="dialog">

					  <!-- Modal content -->
					  <div class="modal-content">
					  	<span class="popclose">&times;</span>
					  	<h3><span style="color:#f0f0f0;">Product: <?= $value->p_name;?></span></h3>
					  	<hr>
					  	<input type="number" id="qty<?= $value->p_id ?>" name="qty" placeholder="Qty" />
					    <div class="popcontent">
					    	<div class="row">
					    		<div class="col-sm-4"></div>
					    		<div class="col-sm-4">
					    			<button type="button" data-target="#loading-modal" data-toggle="modal" id="<?php echo $value->p_id."_".$val->user_id."_".$val->id; ?>" class="addToWishList button" style="width: 100%">Submit</button>
					    		</div>
					    	</div>
					    </div>
					  </div>
					</div>
						<?php include 'my_wishlist.php';
								}
							}
						?>
					</ul>
					<?php
						}
						?>
            		</div>
            	</div>
            </div>
    	</div>
 <?php 
	endforeach; 
  endif; 
 ?>