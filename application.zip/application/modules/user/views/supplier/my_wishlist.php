<!-- CART MODAL -->
					<div class="apped-modal">
					<div id="myCart<?= $val->id?>" class="modal fade" role="dialog" >

					  <!-- Modal content -->
					  <div class="modal-content" style="float:right;margin: 0; background: #f0f0f0">
					  	<span class="popclose">&times;</span>
					  	<h3>My Cart</h3>

					  	<hr>
					  	<div class="row">
					  	<div class="col-md-12">
					  	<ul style="padding: 0; margin-top: -20px;">
						<div id="load-html">
					  	<!-- content -->
					  		<?php 
					  		$itemsOnCart = $this->wishlist->viewCartItems($val->id);
						if($itemsOnCart != ''){?> 

						<?php
						$total = 0;
							foreach ($itemsOnCart as $key => $item) { 
								$item = (object) $item;
								
								if($val->id == $value->supp_id){
									$sub_total = ($item->p_price * $item->qty);
									$total += $sub_total;
						?>
							<div class="dashboard-list-box">
			                 	<li  style="padding:0px 3px 0px 3px;margin: -10px;">
									<div class="list-box-listing">
									<div class="list-box-listing-img">

									<?php
															
									if($item->p_img != ''):
										$media = unserialize($item->p_img);
										if(array_key_exists('images', $media) && $media['images'] != ''):
										$display = $media['images'];
															?>
										<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $item->p_name ?>" >
										<?php 	else: ?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
										<?php
										endif;
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php endif;?>
									</div>
									<div class="list-box-listing-content">
										<div class="inner col-sm-6">
											<h3><?= $item->p_name; ?></h3>
											<span>Price: <?= $item->p_price ?>/<?= $item->p_per ?></span>	
											<!-- <div class="star-rating" data-rating="2.8">
											<div class="rating-counter">(12 reviews)</div>
											</div> -->
										</div>
										<div class="col-sm-6">
											<h3></h3>
											<div>Qty: <?= $item->qty ?> <?= $item->p_per ?></div>
											<div>Sub Total: <?= $sub_total ?> </div>
										</div>
									
									</div>
								</div>
								</li>
							</div>
						<?php	
								}
							}
						?>
					<?php } ?>
					</div>
					</ul>
					<!-- <ul style="padding: 0; margin-top: -20px;">
						
						<div class="row">
						<div class="col-lg-12">
			                <div class="dashboard-list-box " id="load-html">
			                 		
			                </div>
			            </div>
			        	</div>
						
					</ul> -->
					</div>
					</div>
					    <div class="popcontent" style="margin-top:20px;">
					    	<div class="row">
					    		<div class="col-sm-4">
					    			<button type="button" data-target="#orderNow<?= $val->user_id?>" data-toggle="modal" class="button" style="width: 100%">Order Now</button>
					    		</div>
					    		<div class="col-sm-4"></div>
					    		<div class="col-sm-4" id="load-total"><h3>Total: <?= $total ?> </h3></div>
					    	</div>
					    </div>
					  </div>

					</div>
				</div>

			        <!-- ORDERNOW MODAL -->
			        <div id="orderNow<?= $val->user_id?>" class="modal fade" role="dialog">

					  <!-- Modal content -->
					  <div class="modal-content" style="margin: 90px 0px 90px 280px;">
					  	<span class="popclose">&times;</span>
					  	<h3><strong>TO: </strong><span style="color: #f0f0f0;"><?= $val->name;?></span></h3>
					  	<hr>
					  	<h4><span style="color: #a0a0a0;">Order Type:</span></h4>
					  	<select id="order_type" name="order_type" class="order_type">
					  		<option value="pick-up">Pick UP</option>
					  		<option value="delivery">Delivery</option>
					  	</select>
					  	<h4><span style="color: #a0a0a0;">Payment Method:</span></h4>
					  	<select id="payment_method" name="payment_method">
					  		<option value="cash-on-pick-up">Cash on pick-up</option>
					  		<option value="paypal">Paypal</option>
					  	</select>
					    <div class="popcontent">
					    	<div class="row">
					    		<div class="col-sm-4"></div>
					    		<div class="col-sm-4">
					    			<a href="#loading-modal" data-toggle="modal" id="<?= $val->user_id.'-'.$val->id; ?>" class="btnOrder button" style="width: 100%; text-align: center;">Order</a>
					    		</div>
					    	</div>
					    </div>
					  </div>
					</div>