<div class="row">
            <div class="col-lg-12">
                <div class="dashboard-list-box" >

                    <?php 
						if($junkSupplier != ""): ?>
						<ul id="junk-supplier-list" style="background: #e0e0e0;">
							<li style="background: #d0d0d0;">
								<h3>Junk List</h3>
							</li>
						<?php
								foreach($junkSupplier as $val):	
									$val = (object) $val;
									$loc = unserialize($val->address);
									$abbrev = $loc['state']['abbrev'];
									$name = $loc['state']['name'];
								?>
									<li id="junk-<?= $val->id ?>">
										<div class="list-box-listing">
											<div class="list-box-listing-img">
												<?php
												
												if($val->media != ''):
													$media = unserialize($val->media);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php 
												endif;
												?>
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><?php echo $val->name; ?></h3>
													<div><?php echo $val->description; ?></div>
													<div><i class="fa fa-map-marker"></i> <?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></div>
												</div>
											</div>
										<div class="buttons-to-right">
											<a href="#loading-modal" data-toggle="modal" id="<?= $val->id.'-'.$val->user_id ?>" class=" btnUnJunkSupplier button gray"><i class="sl sl-icon-trash"></i> UnJunk</a>
										</div>

										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
				</div>
		</div>
</div>