<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $pagename; ?></h2>
                </div>
            </div>
        </div>

        <!-- Notice -->
        <div class="row">
            <div class="col-md-12">
            	<div id="notify" class="notify" align="center">
					<?php 
					if($this->session->flashdata('notify') != '' ){
						$notify = $this->session->flashdata('notify');
						if($notify['status'] == true){
							echo '<div class="notification success closeable">
								<p>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}else{
							echo '<div class="notification error closeable">
								<p><span>Error! </span>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}
					}
					?>
						
				</div>
            </div>
        </div>
        <div class="row">
            <!-- Payments -->
            <div class="col-lg-12">
                <div class="dashboard-list-box">
                    <?php 
						if($branch != ""): ?>
						<ul>
									<li >
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="#list<?php echo $val->id;?>" class="popup-with-zoom-anim">
												<?php
												
												if($val->media != ''):
													$media = unserialize($val->media);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
												<?php 
												endif;
												?>
												</a>
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->name; ?></a></h3>
													<div><?php echo $val->description; ?></div>
													<span><?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></span>
													
													<!--div class="star-rating" data-rating="3.5">
														<div class="rating-counter">(12 reviews)</div>
													</div-->
												</div>
											</div>
										<div class="buttons-to-right">
											<a href="<?php echo site_url('user/edit_branch/'.$val->id); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>

											<a href="#" class="btnDeleteBranch button gray" id="<?php echo $val->id."_".$val->name; ?>"><i class="sl sl-icon-close"></i> Delete</a>
										</div>

										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
                </div>
            </div>
            <!-- Copyrights -->
    	<?php $this->load->view('inc/copyrights'); ?>
        </div>
 <?php 
	if($branch != ""): 

		foreach($branches as $val): 
			$val = (object) $val;
			$loc = unserialize($val->address);
			$abbrev = $loc['state']['abbrev'];
			$name = $loc['state']['name'];
			?>

		<div id="list<?php echo $val->id;?>" class="zoom-anim-dialog mfp-hide">
            
            <div class="message-reply margin-top-0">
            	<div class="row">
            		<div class="col-sm-6">

						<h2><?php echo $val->name;?></h2>
						<h4><i class="fa fa-map-marker"></i> <?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")"; ?></h4>
            			<?php
						if($val->media != ''):
							$media = unserialize($val->media);
							if(array_key_exists('images', $media) && $media['images'] != ''):
								$display = $media['images'];
						?>
							<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->name ?>">
							<?php 	else: ?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
							<?php
							endif;
							else:
							?>
							<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
							<?php 
						endif;
						?>
						<h4><?php echo $val->description;?></h4>
						
            		</div>
            		<div class="col-sm-6">
						<h2>Products </h2>
						<?php 
						if($livestocks){?> 
						<ul>
						<?php
							foreach ($livestocks as $key => $value) { 
								$value = (object) $value;
								if($val->id == $value->supp_id){
						?>
						<div class="row">
						<div class="col-lg-12">
			                <div class="dashboard-list-box">
			                 	<li >
									<div class="list-box-listing">
									<div class="list-box-listing-img">
									<?php
															
									if($value->p_img != ''):
										$media = unserialize($value->p_img);
										if(array_key_exists('images', $media) && $media['images'] != ''):
										$display = $media['images'];
															?>
										<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $value->p_name ?>">
										<?php 	else: ?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
										<?php
										endif;
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php endif;?>
									</div>
									<div class="list-box-listing-content">
										<div class="inner">
										<h3><?= $value->p_name; ?></h3>
										<div><?= $value->p_desc; ?></div>
										<span><?= $value->p_price ?>/<?= $value->p_per ?></span>				
										<!--div class="star-rating" data-rating="3.5">
										<div class="rating-counter">(12 reviews)</div>
										</div-->
										</div>
									</div>
									<div class="buttons-to-right">
										<a href="<?php echo site_url('user/edit_product/'.$value->p_id); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>
										<a href="#" class="btnDeleteProduct button gray" id="<?php echo $value->p_id."_".$value->p_name."_".$val->name; ?>"><i class="sl sl-icon-close"></i> Delete</a>
									</div>
									</div>
								</li>
									
			                </div>
			            </div>
			        </div>
						<?php	
								}
							}
						?>
					</ul>
					<?php
						}
						?>
            		</div>
            	</div>
            </div>
    	</div>
 <?php 
	endforeach; 
  endif; 
 ?>
