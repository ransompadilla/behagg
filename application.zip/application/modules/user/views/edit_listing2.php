<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Edit Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Edit Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/edit-listing2')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                </div>
            <!-- Add Livestocks -->
            <div class="add-listing-section">

                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> Add New</h3>
                </div>
                <div class="row with-forms">
                    <div class="col-md-10">
                        <input type="input" name="input-livestock" class="input-livestock search-field" placeholder="Name">
                    </div>
                    <div class="col-md-2 ">
                        <button class="addNewLivestock" type="button" style="height: 50px;width: 100%;">Add</button>
                    </div>
                    <div class="col-md-12 ">
                        <ul class="append-livestock">
                        </ul>
                    </div>
                </div>  
            </div>
            <!-- Section -->
            <div class="add-listing-section">
                
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Pricing</h3>
                    <!-- Switcher -->
                   <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <div class="row with-forms append-newlivestock">
                
                <?php 
                    if($listing){
                            $livestock = unserialize($listing->livestock);
                            if($livestock['livestock'] != ""){
                                foreach ($livestock['livestock'] as $key => $stock) { ?>
                                    <div id="<?= $key ?>" class="col-md-6 ">
                                        <div class="row">
                                          <div class="col-sm-1">
                                            <div class="img-wrap">
                                              <span class="removeLivestock close" name="<?= $key ?>" >&times;</span>
                                            </div>
                                          </div>
                                          <div class="col-sm-11">
                                            <input type="hidden" id="key" name="key" value="<?= count($livestock['livestock']); ?>" >
                                            <input type="text" name="livestock[]" placeholder="Name" value="<?= $stock['name'] ?>" required>
                                          </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="col-sm-3">
                                                    <label style="float: right;">Price:</label>
                                                </div>
                                                <div class="col-sm-9">
                                                    <input type="text" placeholder="Price" name="livestock_price<?=$key?>" value="<?= $stock['price'] ?>" style="height: 30px;" required>
                                                </div>
                                                
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-sm-3">
                                                    <label style="float: right;">Per:</label>
                                                </div>
                                                <div class="col-sm-5">
                                                    <div class="fm-input">
                                                        <input type="number" name="livestock_num<?=$key?>" value="<?= $stock['num'] ?>" style="height: 30px;padding: 5px;" required>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <select name="livestock_per<?=$key?>" style="height: 30px;padding: 5px;">
                                                        <?php
                                                         $per = array('klg', 'pcs', 'cont');
                                                         foreach ($per as $key => $value):?>
                                                            <option value="<?= $value?>" <?= ($stock['per'] == $value) ? 'selected' : '' ?> ><?= $value?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                <?php   
                                }
                            }
                            ?>
                        <?php
                    }
                ?>

                </div>
                <!-- Row / End -->

            </div>
            <!-- Section / End -->
            <div class="add-listing-section">
                            
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Add-Ons Pricing</h3>
                <div class="row with-forms">
                    <div class="col-md-10">
                        <input type="input" name="input-add-on" class="input-add-on search-field" placeholder="Add-Ons">
                    </div>
                    <div class="col-md-2 ">
                        <button class="addOns" type="button" style="height: 50px;width: 100%;">Add</button>
                    </div>
                   
                </div>  
                </div>
                <!-- Row -->
                <div class="row with-forms append-new-addon">
                
                <?php 
                    if($listing){
                            $livestock = unserialize($listing->livestock);
                            if($livestock['add_on'] != ""){
                                foreach ($livestock['add_on'] as $key => $add_on) { ?>
                                    <div id="<?= $key ?>" class="col-md-6 ">
                                        <div class="row">
                                          <div class="col-sm-1">
                                            <div class="img-wrap">
                                              <span class="removeAddOn close" name="<?= $key ?>" >&times;</span>
                                            </div>
                                          </div>
                                          <div class="col-sm-11">
                                            <input type="hidden" id="key" name="key" value="<?= count($livestock['add_on']); ?>" >
                                            <input type="text" name="product[]" placeholder="Product" value="<?= $add_on['product'] ?>" required>
                                          </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="col-sm-3">
                                                    <label style="float: right;">Price:</label>
                                                </div>
                                                <div class="col-sm-9">
                                                    <input type="text" placeholder="Price" name="add_on_price<?= $key ?>" value="<?= $add_on['price'] ?>" style="height: 30px;" required>
                                                </div>
                                                
                                            </div>
                                            <div class="col-md-6">
                                                <div class="col-sm-3">
                                                    <label style="float: right;">Per:</label>
                                                </div>
                                                <div class="col-sm-5">
                                                    <div class="fm-input">
                                                        <input type="number" name="add_on_num<?= $key ?>" value="<?= $add_on['num'] ?>" style="height: 30px;padding: 5px;" required>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <select name="add_on_per<?= $key ?>" style="height: 30px;padding: 5px;">
                                                        <?php
                                                         $per = array('klg', 'pcs', 'cont');
                                                         foreach ($per as $key => $value):?>
                                                            <option value="<?= $value?>" <?= ($add_on['per'] == $value) ? 'selected' : '' ?> ><?= $value?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                <?php   
                                }
                            }
                            ?>
                        <?php
                    }
                ?>

                </div>
                <!-- Row / End -->

            </div>    

           
            <!-- Section -->
            <div class="add-listing-section margin-top-45" style="overflow:hidden">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Photos</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                </div>
                <div class="submit-section">                    
                    <!-- Row -->
                    <div class="row with-forms"> 
                        <div class="col-md-12">  
                            Add Photos                
                            <input id="file-input" type="file" multiple="multiple" name="photo[]">
                            <div id="preview"></div>
                        </div>
                    </div>
                    <div class="row with-forms" style="border-top:1px solid #ddd;padding-top:20px;margin-top:20px">
                        <?php // *** photos *** //
                            if($listing){
                                $media  = unserialize($listing->media);
                        ?>
                        <h4>Uploaded Photos</h4>
                         
                        <?php 
                            if(array_key_exists("images",$media) && $media['images'] != ''):
                                for($i=0;$i<count($media['images']);$i++):

                                $getname    = $media['images'][$i];
                                $imgname    = explode('.',$getname);
                        ?>
                            
                            <div class="col-lg-3 col-md-4 col-xs-6">
                                <div class="img-wrap">
                                    <input id="<?= $i ?>" type="hidden" name="current_photo[]" value="<?= $getname ?>">
                                    <span id="<?= $i ?>" class="close" >&times;</span>
                                    <img id="<?= $i ?>" src="<?php echo site_url('uploads/listing/'.$getname); ?>" class="img-thumbnail" alt="<?php echo $imgname[1] ?>">
                                </div>
                            </div>
                        <?php 

                                endfor; 
                            endif;
                        }
                        ?>
                    </div>
                </div>
            </div>
             <!-- Section / End -->

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>