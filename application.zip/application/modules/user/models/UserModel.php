<?php
class UserModel extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

	public $table = 'users';
    public $userdata = ['id','first_name','last_name','email','role','status','account_status','subscription_type','user_type','date_added','date_modified'];
    
	public function authCheck($arr){
	    $this->db->select($this->userdata);
        $this->db->from($this->table);
        $this->db->where($arr);
        $this->db->limit(1);
        $query = $this->db->get();
        
        if ($query->num_rows() == 1) {
            $ret['status'] = true;
            $ret['data'] = $query->row();
            return $ret;
        } else {
            $ret['status'] = false;
            $ret['data'] = '';
            return $ret;
        }
    }
    public function getUserInfo($id){
        $query = $this->db->get_where('users', array('id'=>$id));
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function getUsers(){
        $query = $this->db->get('users');
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function plan_record($id){

        $this->db->select('*');
        $this->db->from('plan_records pr'); 
        $this->db->join('plan p', 'p.plan_id=pr.plan_id', 'inner');
        $this->db->where('pr.user_id', $id);
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function checkDate($id){
        $this->db->order_by('notif_date','desc');
        $query = $this->db->get_where('notification', array('payment_id'=>$id));
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function insertNotification($data = array()){
        $this->db->insert('notification',$data);
        if($this->db->affected_rows() > 0){
            return true;
        }
        else{return false;}
    }
    public function notification($id){
        $this->db->order_by('notif_date','desc');
        $this->db->select('*');
        $this->db->from('notification n'); 
        $this->db->join('payments p', 'p.payment_id=n.payment_id', 'inner');
        $this->db->where('p.payment_id', $id);
        $query = $this->db->get();

        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    public function getPaymentByUser($id){
        $this->db->order_by('payment_date', 'desc');
        $query = $this->db->get_where('payments', array('user_id'=>$id, 'status'=>1));
        if($query->num_rows() > 0){
            return $query->row();
        }else{
            return false;
        }
    }
    
    public function payment_record($id){

        $this->db->select('*');
        $this->db->from('payments pay'); 
        $this->db->join('plan p', 'p.plan_id=pay.plan_id', 'inner');
        $this->db->where('pay.user_id', $id);
        $query = $this->db->get();

        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    public function update_status_payment($id,$data){
        $this->db->where('payment_id',$id);
        $this->db->update('payments',$data);
        if($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public function update_status_notif($id,$data){
        $this->db->where('payment_id',$id);
        $query = $this->db->update('notification',$data);
        if($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public function count_notif($p_id){
        $sql = "SELECT count(payment_id) as notif FROM notification where payment_id = ? and notif_status = 1";
        $query = $this->db->query($sql, array($p_id));
        
        return ($query->num_rows() > 0) ? $query->row() : false;
    }
    public function totalOfPayment($id){
        $sql = "SELECT sum(payment_gross) as payment FROM payments where user_id = ?";
        $query = $this->db->query($sql, array($id));
        
        return ($query->num_rows() == 1) ? $query->row() : false;
    }
    public function getDoneFreePlan($id){
       $query = $this->db->get_where('payments', array('user_id'=>$id, 'plan_id'=>3));
        if($query->num_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    public function updateUserRoleSupplier($data, $where){
        return $this->db->update('users', $data, $where);
    }
    public function getUserRole($data){
        $query = $this->db->get_where('users', $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function getUserInfoBySupplier($supp_id){
        $this->db->select('*');
        $this->db->from('users u'); 
        $this->db->join('supplier s', 's.user_id=u.id', 'inner');
        $this->db->where('s.supp_id', $supp_id);
        $query = $this->db->get('supplier');
        return $query->num_rows() > 0 ? $query->row(): false;
    }
    public function getUserSuppliers($data){
        $this->db->select('*');
        $this->db->from('supplier sup'); 
        $this->db->join('user_listing ul', 'ul.supp_id=sup.supp_id', 'inner');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result(): false;
    }
    public function getUserSupplier($data){
        $this->db->select('*');
        $this->db->from('supplier sup'); 
        $this->db->join('user_listing ul', 'ul.supp_id=sup.supp_id', 'inner');
        $this->db->where($data);
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->row(): false;
    }
}


