<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class User extends MY_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('UserModel');
		$this->load->module('listing/listing');
		$this->load->module('orderedlist/orderedlist');
		$this->load->module('wishlist/wishlist');
		$this->load->module('branches/branches');	
		$this->load->module('livestocks/livestocks');
	}
	
	public function index(){
		return redirect('user/dashboard');
	}
	//ROUTER
	public function q($var, $var2 = "", $var3 = ""){
		$user_id = $this->userAuth()->id;
		$supp_name = "";
		$arr = explode('.', $var);
		for($i=0;$i<count($arr);$i++){
			if($i < (count($arr) - 1)){
				$supp_name .= $arr[$i].' ';
			}
			else{
				$supp_name .= $arr[$i];
			}
		}
		
		$where = array('supp_name'=>$supp_name, 'user_id'=>$user_id);
		$branch = $this->branches->getBranch($where);
		$categories = $this->livestocks->getLivestockCategory(array('cat.supp_id'=>$branch->supp_id));
		if($var3 != ""){
			if($var3 == 'product-forsale'){
				$exp_var2 = explode('.', $var2);
				$this->product_forsale($branch->supp_id, $exp_var2[1], $var, $var2, $var3);
			}
			else{
				$exp_var2 = explode('.', $var2);
				$exp_var3 = explode('.', $var3);
				$this->livestock_room($branch->supp_id, $exp_var2[1], $exp_var3[1], $var, $var2, $var3);
			}
		}
		else if($var2 != ""){
			if($var2 == 'add-livestock-category'){
				$this->add_livestock_category($branch->supp_id, $var);
			}
			else{
				$exp_var2 = explode('.', $var2);
				$this->manage_livestock($branch->supp_id, $exp_var2[1], $var, $var2);
			}
		}
		else{
			$this->your_livestock($branch,$categories, $var);
		}
	}
		
	public function mailtest(){
		$token =  $this->generateRandomString(12);
		$this->sendVerification(20,'brianwebblogger@gmail.com',$token);

	}

	protected function userAuth(){
		if($this->session->userdata('is_logged') != true){
			redirect();
		}
		return $this->session->userdata('user_info');
	}
	protected function getUserInfo($id){
		return $this->UserModel->getUserInfo($id);
	}
	protected function sendVerification($id, $email, $token){
		$dcomp = 'Aussie Flatmates';
		$formname = 'Verification';
		$message = '<div align="left" style="width:700px; height:auto; font-size:12px; color:#333333; letter-spacing:1px; line-height:20px;">
			<div style="border:8px double #c3c3d0; padding:12px;"><div align="center" style="font-size:22px; font-family:Times New Roman, Times, serif; color:#051d38;">'.$dcomp.'</div>
			<div align="center" style="color:#990000; font-style:italic; font-size:13px; font-family:Arial;">('.$formname.')</div><p>&nbsp;</p>
			';

		$message .='<p>Welcome to Aussie Flatmates! Your account has been registered under your "'.$email.'" is now ready to go. All you need to do is to confirm your email address with us.<br/>
		Please, click on below link to confirm your registration at aussieflatmates.com.au</p>';

		$message .='<p><a href="'.base_url().'user/authentication/id/'.$id.'/verification/'.$token.'">Activate Now</a></p>';

		$message .='</div>
					</div>';
		$subject = 'Email Verification';

		$sendna = $this->mailthis($email, $subject, $message);

		if($sendna === true){

			$response['status'] = true;
			$response['msg'] = "<div style='text-center'>Registration Successful. <br />Your account has been created and an activation link has been sent to the email address you entered. Note that you must activate the account by clicking the activation link when you get the email before you can login.
			<br/>If you don't see this email in your inbox within 15 minutes, look for it in your junk mail folder. If you find it there, please mark the email as \"Not Junk\".<br /> Thank you...</div>";
			echo json_encode($response);

		}else{
			$response['status'] = false;
			$response['msg'] = $sendna;
			echo json_encode($response);

		}
	}


	public function signup(){
		$response = array();
		// set validation rules
		$this->form_validation->set_rules('first_name', 'First name', 'trim|required|max_length[35]');
		$this->form_validation->set_rules('last_name', 'Last name', 'trim|required|max_length[35]');
		$this->form_validation->set_rules('age', 'Age', 'trim|required|integer|max_length[3]');
		$this->form_validation->set_rules('gender', 'Gender', 'trim|required|in_list[male,female,other]');
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');			
		$this->form_validation->set_rules('phone', 'Phone', 'trim|required|max_length[14]');			
		$this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[8]');
		$this->form_validation->set_rules('password2', 'Confirm Password', 'trim|matches[password1]');
		

		if($this->form_validation->run()){
			//set variables from the form
			$first_name = strtolower($this->input->post('first_name'));
			$last_name 	= strtolower($this->input->post('last_name'));
			$age 		= strtolower($this->input->post('age'));
			$gender 	= strtolower($this->input->post('gender'));
			$status 	= strtolower($this->input->post('status'));
			$email    	= $this->input->post('email');
			$phone    	= $this->input->post('phone');
			$password 	= sha1($this->input->post('password1'));
			$token 		= $this->generateRandomString(12);

			$accountData = array(
				'first_name' => $first_name,
				'last_name' => $last_name,
				'age' => $age,
				'status' => $status,
				'gender' => $gender,
				'email' => $email,
				'phone' => $phone,
				'password' => $password,
				'role' => 1,
				'account_status' => 1,
				'subscription_type' => 0,
				'token' => $token,
				'date_added' => $this->getCurrentDateTime()
			);

			$id_inserted = $this->UserModel->insert($accountData);
				$id_inserted = true;
			if($id_inserted !== false){
				//$where = array('id'=>$id_inserted);
				//$info = $this->UserModel->getRow($where);
				
				//$this->sendVerification($info->id, $info->email, $info->token);	
					$response['status'] = true;
					$response['msg'] = "To verify your account. Please check your email.";
					echo json_encode($response);
				exit;
			}			
			
		}else{
			$response['status'] = false;
           	$response['msg'] = validation_errors().'-';
			   echo json_encode($response);
			   exit;
		}
			
	}

	public function signin(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$email = strtolower($this->input->post('email'));
			$password = sha1($this->input->post('password'));
            
			$checklogin = $this->UserModel->authCheck(array('email' => $email, 'password'=>$password,'account_status' => 1));
			
			if($checklogin['status'] == true){

				$this->session->set_userdata('user_info', $checklogin['data']);
				$this->session->set_userdata('is_logged', true);

				$response['status'] = true;
				$response['msg'] = "Successful";
				echo json_encode($response);
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Account does not exist or not yet verified.";
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
           	echo json_encode($response);
		}
			
	}

	public function authentication($id, $token ){
		$a_data = array(
			'pagename'		=> 'Email Verification',
			's_navcurrent'	=> ''
		);

		$urr = $this->uri->uri_to_assoc(3);
		$get['id']		= $urr['id'];
		$get['token']	= $urr['verification'];
		$get['account_status']	= 0;
		if(is_numeric($get['id']) && strlen($get['token']) === 12){
			$person_data = $this->UserModel->authCheck($get);

			if($person_data['status'] != false){
				if($person_data['data']->account_status == 0){
					$update['account_status'] = 1;

					$this->UserModel->update($update,$get);

					$this->session->set_userdata('user_info', $person_data['data']);
					$this->session->set_userdata('is_logged', true);

					$response['status'] = true;
					$response['msg'] = 'You have successfully registered with us!';
					$a_data['notify'] = $response;

				}else{
					$response['status'] = false;
					$response['msg'] = 'Verification link used already. Please use login details.';
					$a_data['notify'] = $response;
				}
				
			}else{
				$response['status'] = false;
				$response['msg'] = 'Invalid Link! Please contact the administrator.';
				$a_data['notify'] = $response;
			}
			
		}else{
			$response['status'] = false;
			$response['msg'] = 'Invalid Link! Please contact the administrator.';
			$a_data['notify'] = $response;
		}
		
		$this->pg_display('authentication',$a_data);
	}

	public function logout(){
		$this->session->set_userdata('user_info', '');
		$this->session->set_userdata('is_logged', false);
		$this->session->unset_userdata('user_info');
		$this->session->unset_userdata('is_logged');
		$this->session->sess_destroy();
		redirect('/', 'refresh');
	}
	public function getCountNotif(){
		$user_data = $this->userAuth();
		$p_user = $this->UserModel->getPaymentByUser($user_data->id);
		if($p_user){
			return $this->UserModel->count_notif($p_user->payment_id);
		}
		
	}
	public function manage_notification(){
		$rem_days="";$enddate="";$end="";$ckDate="";$ckStr="";
		$user_data = $this->userAuth();
		$paymentRecord = $this->UserModel->payment_record($user_data->id);
		date_default_timezone_set("Asia/Manila");
        $now = Date('F j, Y');
        $date_now = strtotime($now);
        if($paymentRecord){
        	foreach ($paymentRecord as $payment): 
				$check_date = $this->UserModel->checkDate($payment->payment_id);
				if($check_date){
					$ckStr = strtotime($check_date->notif_date);
					$ckDate .= Date('F j, Y', $ckStr);
				}
				
       			
              	
              if($payment->status == 1):
                $strDate = strtotime($payment->payment_date);
                $start_date = date('F j, Y', $strDate);
				  for($i=0;$i< $payment->days; $i++){
                    $end = $strDate + ($payment->days * 86400);
                    $enddate = date('F j, Y', $end);
                  }
                $rem_days = ($end - $date_now) / 86400;
                $use_days = $payment->days - intval($rem_days);
                $rem_days = intval($rem_days);
                if($rem_days <= 0){
                	$a_data = array(
				        'payment_id'=>$payment->payment_id,
				        'notif_message'=>'Your '.$payment->plan_category.' has been expired, please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        'notif_status'=>1
				        );
				    $result = $this->UserModel->insertNotification($a_data);
				    if($result == true){
				    	$this->UserModel->update_status_payment($payment->payment_id, array('status' => 0));
				    }
                	
                }

                if($now != $ckDate && $payment->status == 1){
                	if($payment->plan_id == 1){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe again to extend your plan before it expired, Or you can upgrade your '.$payment->plan_category.' to Full Plan for 30 Days just click subscribe to see prices. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe again to extend your plan before it expired, Or you can upgrade your '.$payment->plan_category.' to Full Plan for 30 Days just click subscribe to see more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
                	
                	if($payment->plan_id == 2){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe again to extend your plan before it expired. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe again to extend your plan before it expired. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
			        
                	if($payment->plan_id == 3){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
                	return $rem_days.'-'.$payment->plan_category;
                }
              endif;
            endforeach;
        }
        
	}

	public function notification(){
		$user_id = $this->userAuth()->id;

		$a_data = array(
			's_navcurrent'	=> 'notification',
			'pagename'		=> 'Notification'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('notification',$a_data);
	}
	public function dashboard(){
		$user_id = $this->userAuth()->id;

		$a_data = array(
			's_navcurrent'	=> 'dashboard',
			'pagename'		=> 'Dashboard'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('dashboard',$a_data);
	}
	public function payments(){
		$user_id = $this->userAuth()->id;

		$a_data = array(
			's_navcurrent'	=> 'payment-records',
			'pagename'		=> 'Payment Records'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['paymentRecord'] = $this->UserModel->payment_record($user_id);
		$a_data['totalPayment']	= $this->UserModel->totalOfPayment($user_id);
		$this->dash_display('payments',$a_data);
	}
	public function getPaymentRecords(){
		$user_data = $this->userAuth();
		return $a_data['paymentRecord'] = $this->UserModel->payment_record($user_data->id);
	}
	public function getPaymentByUser($id){
		return $this->UserModel->getPaymentByUser($id);
	}
	public function messages($id=''){
		$unread = "";
		$user_data = $this->userAuth();
		
		$this->load->module('messages/messages');
		if($id != ""){
			$a_data['to'] = $this->UserModel->getUserInfo($id);
			$unread = $this->messages->unread_per_user($id, $user_data->id); 
			if($unread > 0){
				$a_data['count'] = $unread;
			}
			else{
				$a_data['count'] = '';
			}
		}
		else{
			$a_data['to'] = "";
		}
		$a_data['message_list'] = $this->messages->load_message_list();
		$a_data['nCount'] = $this->getCountNotif();
		$result = $this->UserModel->getPaymentByUser($user_data->id);
		// if(!$result){
		// 	$random = $this->generateRandomString(40)."zMsCz".$this->generateRandomString(30);
		// 	redirect('page/pricing/'.$random);
		// }

		$this->pg_messages('messages/messages', $a_data);
	}
	public function done_FreePlan(){
		$user_id = $this->userAuth()->id;
		return $this->UserModel->getDoneFreePlan($user_id);
	}
	public function profile(){
		$user_id = $this->userAuth()->id;
		$a_data = array(
			's_navcurrent'	=> 'profile',
			'pagename'		=> 'Profile'
		);
		
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('profile',$a_data);
	}
	
	
public function map_location($location){
		$this->load->library('googlemap_api');
		
		$config['center'] = $location;
		$config['zoom'] = 15;
		$this->googlemap_api->initialize($config);

		$marker = array();
		$marker['position'] = $location;
		$this->googlemap_api->add_marker($marker);
			
		$a_data['maps'] = $this->googlemap_api->create_map();
		
		$a_data['connection'] = $this->googlemap_api->connection();
		return $a_data;
	}
	//new

	public function add_branch(){
		$user_id = $this->userAuth()->id;
		if($_POST){
			$a_data['notify'] = $this->branches->add_branch('save'); 
		}
		$a_data = array(
				's_navcurrent'	=> 'add-branch',
				'pagename'		=> 'Add Branch'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('branch/add_branch',$a_data);
	}
	public function edit_branch($data = ''){
		$user_id = $this->userAuth()->id;
		$a_data = array(
				's_navcurrent'	=> 'edit-product',
				'pagename'		=> 'Edit Product'
		);
		if($_POST){
			$a_data['notify'] = $this->branches->edit_branch('update'); 
		}
		$data = array('supp_id'=>$data);
		$a_data['branch'] = $this->branches->getBranch($data);
		$a_data['nCount'] = $this->getCountNotif();

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('branch/edit_branch',$a_data);
	}
	public function branch_list(){
		$this->load->library('googlemap_api');
		$user_id = $this->userAuth()->id;
		$branch = array();
		$livestock = array();
		$found = false;
		$a_data = array(
				's_navcurrent'	=> 'branch-list',
				'page1'		=> 'My Listings'
		);

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);

		$data = array('user_id'=>$user_id);
		$branches = $this->branches->getBranches($data);
		foreach ($branches as $key => $value) {
				$arr_branch = array(
					'id'=>$value->supp_id,
					'name'=>$value->supp_name,
					'description'=>$value->supp_desc,
					'address'=>$value->supp_address,
					'contact'=>$value->supp_contact,
					'media'=>$value->media
				);
				
			array_push($branch, $arr_branch);
		}
		$a_data['branches'] = $branch;;
		$this->dash_display('branch/branch_list',$a_data);
	}
	
	public function add_livestock_category($supp_id, $s_name){
		$user_id = $this->userAuth()->id;
		$where = array('supp_id'=>$supp_id, 'user_id'=>$user_id);
		$result = $this->branches->getBranch($where);
		if(!$result){show_404();}
		if($_POST){
			$a_data['notify'] = $this->livestocks->add_livestock_category('save', $s_name); 
		}
		$a_data = array(
				's_navcurrent'	=> 'add-livestock-category',
				'pagename'		=> 'Add Livestock Category'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$data = array('user_id'=>$user_id);
		$a_data['categories'] = $this->livestocks->getCategories(); 
		$a_data['supp_id'] = $supp_id;
		$a_data['supp_name'] = $s_name;
		
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/add_livestock_category',$a_data);
	}
	public function your_livestock($branch,$categories, $var){
		$user_id = $this->userAuth()->id;
		
			$a_data = array(
						's_navcurrent'	=> 'your-livestock',
						'page1'		=> 'My Listings',
						'page2'		=> 'Your Livestocks'
				);
			$a_data['branch'] = $branch;
			$a_data['categories'] = $categories;
			//$a_data['products'] = $this->livestocks->getProducts($where);

			$data = array('user_id'=>$user_id);
			$a_data['branches'] = $this->branches->getBranches($data);
			$a_data['var'] = $var;
			$role = array('id'=>$user_id);
			$a_data['supp_id'] = $branch->supp_id;
			$a_data['role'] = $this->UserModel->getUserRole($role);
			$this->dash_display('livestocks/your_livestocks',$a_data);
	}
	public function livestocks($name, $id){
		$user_id = $this->userAuth()->id;
		$a_data = array(
				's_navcurrent'	=> 'supp-livestock',
				'pagename'		=> 'Livestocks'
		);
		$where = array('ul.supp_id'=>$id);
		$where_cat = array('cat.supp_id'=>$id);
		$a_data['branch'] = $this->UserModel->getUserSupplier($where);
		$a_data['categories'] = $this->livestocks->getLivestockCategory($where_cat);
		
		$a_data['rand1'] = $this->generateRandomString(28);
		$a_data['rand2'] = $this->generateRandomString(28);

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('supplier/supplier_livestocks',$a_data);
	}
	public function manage_livestock($supp_id, $livestock_id,$var, $var2){
		$user_id = $this->userAuth()->id;
		$category = array('cat.livestock_id'=>$livestock_id);
		$cat = $this->livestocks->getLivestockByCategory($category);

		$a_data = array(
				's_navcurrent'	=> 'manage-livestock',
				'page1'		=> 'My Listings',
				'page2'		=> 'Your Livestocks',
				'page3'		=> ($cat != "" ? 'Manage '.$cat->cat_description : show_404())
		);
		$where = array('supp_id'=>$supp_id);
		$a_data['branch'] = $this->branches->getBranch($where);
		$a_data['categories'] = $this->livestocks->getLivestockCategory($category);
		$a_data['sub_categories'] = $this->livestocks->getSubCategories(array('cat.livestock_id'=>$livestock_id));
		$a_data['preg_list'] = $this->livestocks->getProducts(array('cat.supp_id'=>$supp_id, 'sub.livestock_id'=>$livestock_id, 'prod.status'=>1));
		$last = $this->livestocks->getLastProductID();
		$a_data['prod_code'] = $user_id.$supp_id.'-'.substr($cat->cat_name, 0,1).$livestock_id.'-'.$last->lastProdID;
		$forsale = array('p_pricing.supp_id'=>$supp_id, 'p_pricing.livestock_id'=>$livestock_id);
		$product_forsale = $this->livestocks->getProductForsale($forsale);
		$a_data['product_forsale'] = $product_forsale;
		$a_data['count_prod_forsale'] = ($product_forsale != "" ? count($product_forsale) : 'No Product For Sale!' );
		$role = array('id'=>$user_id);
		$a_data['var'] = $var;
		$a_data['var2'] = $var2;
		$data = array('user_id'=>$user_id);

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/manage_livestock',$a_data);
	}
	public function livestock($supp_name, $data_id){
		$user_id = $this->userAuth()->id;
		$pg_name = "";
		$arr = explode('z', $data_id);
		$s_name = explode('%20', $supp_name);
		$supp_id = $arr[1];
		$livestock_id = $arr[3];

		$category = array('cat.livestock_id'=>$livestock_id);
		$cat = $this->livestocks->getLivestockByCategory($category);
		$a_data = array(
				's_navcurrent'	=> 'manage-livestock'
		);
		for($i = 0; $i < count($s_name); $i++){$pg_name .= $s_name[$i].' ';}
		$a_data['pagename'] = $pg_name;
		$where = array('supp_id'=>$supp_id);
		$a_data['branch'] = $this->branches->getBranch($where);
		$a_data['categories'] = $this->livestocks->getLivestockCategory($category);
		$a_data['sub_categories'] = $this->livestocks->getSubCategories(array('cat.livestock_id'=>$livestock_id));
		$a_data['preg_list'] = $this->livestocks->getProducts(array('cat.supp_id'=>$supp_id, 'sub.livestock_id'=>$livestock_id, 'prod.status'=>1));
		$last = $this->livestocks->getLastProductID();
		$a_data['prod_code'] = $user_id.$supp_id.'-'.substr($cat->cat_name, 0,1).$livestock_id.'-'.$last->lastProdID;
		
		$data = array('user_id'=>$user_id);

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/manage_livestock',$a_data);
	}
	public function livestock_room($supp_id, $livestock_id, $sub_id, $var, $var2, $var3){
		$user_id = $this->userAuth()->id;
		$category = array('cat.livestock_id'=>$livestock_id);
		$catt = $this->livestocks->getLivestockByCategory($category);
		$arr = explode('.', $var3);
		$a_data = array(
				's_navcurrent'	=> 'add-product',
				'page1'		=> 'My Listings',
				'page2'		=> 'Your Livestocks',
				'page3'		=> ($catt != "" ? 'Manage '.$catt->cat_description : show_404()),
				'page4'		=> $arr[0]
		);
		$products = $this->livestocks->getProducts(array('sub.livestock_id'=>$livestock_id, 'prod.sub_id'=>$sub_id, 'prod.for_sale'=> 0));
		$a_data['p_qty'] = ($products != "" ? count($products) : 0 );
		$a_data['products'] = $products;
		$a_data['sub_cat'] = $this->livestocks->getSubCategoryByID(array('sub_id'=>$sub_id));
		$cat = $this->livestocks->getCategory(array('cat.livestock_id'=>$livestock_id));
		$a_data['sub_id'] = $sub_id;
		$a_data['sub_categories'] = $this->livestocks->getSubCategories(array('cat.livestock_id'=>$livestock_id));
		$a_data['preg_list'] = $this->livestocks->getProducts(array('cat.supp_id'=>$supp_id, 'sub.livestock_id'=>$livestock_id, 'prod.status'=>1));

		$last = $this->livestocks->getLastProductID();
		$a_data['prod_code'] = $user_id.$supp_id.'-'.substr($cat->cat_name, 0,1).$livestock_id.'-'.$last->lastProdID;

		$a_data['var'] = $var;
		$a_data['var2'] = $var2;
		$a_data['var3'] = $var3;
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/livestock_room',$a_data);
	}
	public function product_forsale($supp_id, $livestock_id, $var, $var2, $var3){
		$user_id = $this->userAuth()->id;
		$category = array('cat.livestock_id'=>$livestock_id);
		$catt = $this->livestocks->getLivestockByCategory($category);
		$a_data = array(
				's_navcurrent'	=> 'add-product',
				'page1'		=> 'My Listings',
				'page2'		=> 'Your Livestocks',
				'page3'		=> ($catt != "" ? 'Manage '.$catt->cat_description : show_404()),
				'page4'		=> 'Product Forsale'
		);
		$forsale = array('p_pricing.supp_id'=>$supp_id, 'p_pricing.livestock_id'=>$livestock_id);
		$product_forsale = $this->livestocks->getProductForsale($forsale);
		$a_data['product_forsale'] = $product_forsale;
		$a_data['count_prod_forsale'] = ($product_forsale != "" ? count($product_forsale) : 'No Product For Sale!' );

		$a_data['var'] = $var;
		$a_data['var2'] = $var2;
		$a_data['var3'] = $var3;
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/product_forsale',$a_data);
	}
	public function edit_product($p_id = ''){
		$user_id = $this->userAuth()->id;
		$a_data = array(
				's_navcurrent'	=> 'edit-product',
				'pagename'		=> 'Edit Product'
		);
		if($_POST){
			$a_data['notify'] = $this->livestocks->edit_product('update'); 
		}
		$data = array('prod_id'=>$p_id);
		$a_data['product'] = $this->livestocks->getLivestock($data);
		$a_data['nCount'] = $this->getCountNotif();
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$this->dash_display('livestocks/edit_product',$a_data);
	}
	public function add_delivery(){
		$a_data = array(
				's_navcurrent'	=> 'add-delivery',
				'pagename'		=> 'Add Delivery'
		);
		$this->dash_display('add_delivery',$a_data);
	}
	public function delivery_list(){
		$a_data = array(
				's_navcurrent'	=> 'delivery-list',
				'pagename'		=> 'Delivery List'
		);
		$this->dash_display('delivery_list',$a_data);
	}
	public function order_detail(){
		$a_data = array(
				's_navcurrent'	=> 'order-detail',
				'pagename'		=> 'Order Detail'
		);
		$this->dash_display('order_detail',$a_data);
	}
	public function payment_records(){
		$a_data = array(
				's_navcurrent'	=> 'payment-records',
				'pagename'		=> 'Payment Record'
		);
		$this->dash_display('payment_records',$a_data);
	}

	public function user_supplier(){
		$count = 0;
		$user_id = $this->userAuth()->id;
		$suppliers = array();
		$livestock = array();
		$items_arr = array();
		$a_data = array(
				's_navcurrent'	=> 'my-supplier',
				'pagename'		=> 'My Suppliers'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$mysupplier = $this->UserModel->getUserSuppliers(array('ul.user_id'=>$user_id, 'ul.junk'=>0));
		if($mysupplier){
			foreach ($mysupplier as $key => $value) {
				array_push($items_arr, $this->wishlist->viewCartItems($value->supp_id));
				
				$a_wish = array('user_id'=>$user_id, 'supp_id'=>$value->supp_id);
				$a_wish_count = $this->wishlist->getWishCountAllProduct($a_wish);
				$arr = array(
					'ulist_id'=>$value->ulist_id,
					'id'=>$value->supp_id,
					'name'=>$value->supp_name,
					'description'=>$value->supp_desc,
					'address'=>$value->supp_address,
					'contact'=>$value->supp_contact,
					'media'=>$value->media,
					'user_id'=>$user_id,
					'a_wish_count'=> ($a_wish_count->qty != '') ? 
									 '<div id="showMyCart" style="margin-top: 10px;">
	            						<a href="#myCart'.$value->supp_id.'" data-toggle="modal" class="button gray"><i class="sl sl-icon-list"></i> My Cart ( '.$a_wish_count->qty.' )</a>
	            					  </div>' : 
	            					  '<div style="display:none;"> </div>'
				);
				array_push($suppliers, $arr);
				// $supp = array('supp_id'=>$value->supp_id);
				// $stocks = $this->livestocks->getLivestocks($supp);
				// if($stocks){
				// 	foreach ($stocks as $k => $v) {
				// 		if($value->supp_id == $v->supp_id){
				// 			$found = true;
				// 			$wish = array('prod_id'=>$v->prod_id, 'user_id'=>$user_id, 'supp_id'=>$v->supp_id);
				// 			$wish_count = $this->wishlist->getWishCountByProduct($wish);
							
				// 			$arr_livestock = array(
				// 			'p_id'=>$v->prod_id,
				// 			'p_name'=>$v->prod_name,
				// 			'p_desc'=>$v->prod_description,
				// 			'p_price'=>$v->prod_price,
				// 			'p_per'=>$v->price_per,
				// 			'p_img'=>$v->prod_img,
				// 			'supp_id'=>$v->supp_id,
				// 			'wish_count'=> ($wish_count->qty != '') ? 'wish ( <span><h5>'.$wish_count->qty.'</h5></span> )' : ''
				// 		);
				// 		array_push($livestock, $arr_livestock);
				// 		}
				// 	}
				// }
			}
		}
		$jcount = $this->listing->countJunkSuppliers(array('user_id'=>$user_id, 'junk'=>1));

		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['livestocks'] = $livestock;
		$a_data['mysupplier'] = $suppliers;
		$a_data['itemsOnCart'] = $items_arr;
		$a_data['junkSupplier'] = $this->listing->viewJunkSuppliers();
		$a_data['count_junk'] = $jcount->junk > 0 ? '<div class="user-name"><i class="sl sl-icon-trash"></i> Junk('.$jcount->junk.')</div>' : '';
		$this->dash_display('supplier/user_supplier',$a_data);
	}
	public function my_orderedlist(){
		$user_id = $this->userAuth()->id;
		$a_data = array(
				's_navcurrent'	=> 'my-orderedlist',
				'pagename'		=> 'My Ordered List'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['orderedlist'] = $this->orderedlist->getOrderlistByUser(array('or.user_id'=>$user_id));
		$this->dash_display('order/orderedlist',$a_data);
	}
	public function order_no($num, $id){
		$user_id = $this->userAuth()->id;
		$this->orderedlist->update_readNotification(array('order_id'=>$id));
		$a_data = array(
				's_navcurrent'	=> 'my-order',
				'pagename'		=> 'Order No. <span>'.$num.'</span>'
		);
		$role = array('id'=>$user_id);
		$a_data['role'] = $this->UserModel->getUserRole($role);
		$a_data['order'] = $this->orderedlist->getOrderByOrderNO(array('order_id'=>$id));
		$this->dash_display('order/order',$a_data);	
	}
}
