<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Options extends MY_Controller{
    
    
    public function __construct(){
        parent::__construct();
        $this->load->model('OptionsModel');
    }
    
    public function index(){
        show_404();
    }

    public function getOptions(){
        return $this->OptionsModel->getAll();
    }

}
