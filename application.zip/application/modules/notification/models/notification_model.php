<?php
class Notification_model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}
    public function getNotificationByUser($data){
    	$query = $this->db->get_where('notifications', $data);
    	return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getNotifications(){
        $this->db->order_by('notif_date','desc');
    	$query = $this->db->get('notifications');
    	return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function notification_count($data){
        $sql = "SELECT count(notif_id) as unread FROM notifications WHERE user_id=? and is_read= ?";
        $query = $this->db->query($sql, $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function insert_notifications($data){
        $this->db->insert('notifications', $data);
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function update_UserNotification($data, $where){
    	$this->db->update('notifications', $data, $where);
    	return $this->db->affected_rows() > 0 ? true : false;
    }
}
?>