<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notification extends MY_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('notification_model'); 
		$this->load->model('user/UserModel'); 
		$this->load->model('orderedlist/orderedlist_model');
		$this->load->model('branches/branches_model'); 
	}
	
	public function getNotificationByUser(){
		$notification = array();
		$response = array();
		$user_id = $this->session->userdata('user_info')->id;
		
		//$count = $this->notification_model->notification_count($data);
		$result = $this->notification_model->getNotifications();
		if($result){
			foreach ($result as $key => $res) {
				if($res->user_id == $user_id){
					$data = array($user_id, 0);
					$count = $this->notification_model->notification_count($data);
					$order_id = array('order_id'=>$res->table_id);
					$order = $this->orderedlist_model->getOrderByOrderNO($order_id);
					$branch = $this->branches_model->getBranch(array('supp_id'=>$res->supp_id));
					$type = $order->order_type == 'pick-up' ? 'Pick UP <i class="fa fa-thumbs-o-up"></i>' : 'Deliver <i class="fa fa-truck"></i>';
					$arr = array(
						'order_id'=>$order->order_id,
						'order_num'=>$order->order_num,
						'item_count'=>'Item\'s('.$order->item_count.')',
						'msg'=>$res->status > 0 ? $res->status == 1 ? '<strong>Are Processing Your Order No. </strong>'.$order->order_num : '<strong> Your Order No. </strong>'.$order->order_num.'<strong> Are Ready to '.$type.'</strong>' : '',
						'supp_name'=>$branch->supp_name,
						'time'=>date("M j, g:i A", strtotime($res->notif_date)),
						'is_read'=>$res->is_read,
						'type'=>$order->order_type == 'pick-up' ? 'Pick UP <i class="fa fa-thumbs-up"></i>' : 'Deliver <i class="fa fa-truck"></i>',
						'status'=>$res->status
					);
					array_push($notification, $arr);
					$response = array('notif_status'=>true, 'notification'=>$notification, 'count'=>$count->unread);
				}

			}

		}
		
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function update_UserNotification(){
		$response = array();
		$user_id = $this->session->userdata('user_info')->id;
		$data = array($res->user_id, 0);
		$count = $this->notification_model->notification_count($data);
		$where = array('user_id'=>$user_id, 'is_read'=>0);
		$data = array('is_read'=>1);
		$result = $this->notification_model->update_UserNotification($data, $where);
		if($result){$response = array('status'=>true, 'count'=>$count->unread);}
		else{$response = array('status'=>false);}
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
}

