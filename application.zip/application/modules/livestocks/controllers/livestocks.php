<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Livestocks extends MY_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('livestock_model');
		$this->load->model('branches/branches_model');

	}
	public function add_livestock_category($request, $s_name){
		$response = array();
		if($request == 'save'){	
			$this->form_validation->set_rules('cat_id', 'Category ID', 'trim|required');
			// $this->form_validation->set_rules('rate', 'Rate', 'trim|required');
			// $this->form_validation->set_rules('rate_by', 'Rate By', 'trim|required');
			$this->form_validation->set_rules('supp_id', 'Supplier ID', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$cat_id 	= $this->input->post('cat_id');
				// $rate 		= $this->input->post('rate');
				// $rate_by 	= $this->input->post('rate_by');
				$supp_id 	= $this->input->post('supp_id');

				//add Images
				if($_FILES['photo']['name'] != 0){

					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
					$sub_type = $this->session->userdata('user_info')->subscription_type;

					if($no_of_files > 6 && $sub_type == 0){
						
							
						$response['status'] = false;
						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
						//echo json_encode($response);			

					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
						$this->load->library('upload');
						$myStr = $this->session->userdata('user_info')->first_name;
						$key = mb_substr($myStr, 0, 3);
						for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
							$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
							$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
							$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
							$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

							$config = array(
								'file_name'     => $i.$key.date('ymdhis'),
								'allowed_types' => 'jpg|jpeg|png|gif',
								'max_size'      => 10000,
								'overwrite'     => TRUE,
								'max_width'		=> 1000,
								'max_height'	=> 768,
								'upload_path'	=> 'uploads/listing'
							);
							$this->upload->initialize($config);

							if ( !$this->upload->do_upload('userfile')) :
								$error = $this->upload->display_errors();
								$response['status'] = false;
								$response['msg'] = $error;
								$image_check = false;
								break;

							else :

							$image[] = $this->upload->data('file_name'); 
							// Continue processing the uploaded data

							endif;
						}
						
					}				    		
				}
				//end
				$data_to_insert = array(
					'cat_id' 			=> $cat_id,
					// 'rate' 				=> $rate,
					// 'rate_by' 			=> $rate_by,
					'supp_id' 			=> $supp_id
				);
				
				if($request == 'save'):
					$data_to_insert['cat_img'] = serialize(array('images' => ''));
					$response['msg'] = 'New Category Added! Please add photos to your Livestock Category.';
				else:
					$response['msg'] = 'Livestock Category Updated! Please add photos to your Category.';
				endif;

				if(count($image) > 0 && $image_check == true){
					$data_to_insert['cat_img'] = serialize(array('images' => $image));
					$response['msg'] 		 = ($request == 'save' ? 'New Category Added!' : 'Category Updated!');
				}
				
				unset($_POST);

				$this->livestock_model->add_livestock_category($data_to_insert);
				$response['status'] = true;	
				$response['msg'] = 'New Category Added !';	
				$this->session->set_flashdata('notify',$response);
				redirect('user/q/'.$s_name);

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}
	public function add_sub_category(){
		$sub_title = "";
		$data = $this->input->post('data');
		$result = preg_replace('/[^a-zA-Z0-9]/','', $data[1]);
		$len = strlen($result);
		if($len > 8){
			$sub_title = substr($result, 0, 8);
		}
		else{$sub_title = $result;}

		$d_len = strlen($data[2]);
		if($d_len > 25){
			$description = substr($data[2], 0, 25).'...';
		}
		else{$description = $data[2];}
		$data_to_insert = array(
					'livestock_id' 			=> $data[0],
					'sub_title'			=> $sub_title,
					'sub_description'	=> $data[2]
				);
				
		unset($_POST);
		$this->livestock_model->add_sub_category($data_to_insert);
		$response = array(
					'livestock_id' 		=> $data[0],
					'sub_title'			=> $sub_title,
					'sub_description'	=> $description,
					'var'				=> $data[3],
					'var2'				=> $data[4]
				);
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function add_product($var, $var2, $var3){
		$response = array();
			$this->form_validation->set_rules('date_birth', 'Date of Birth', 'trim|required');
			$this->form_validation->set_rules('gender', 'Product Gender', 'trim|required');
			//$this->form_validation->set_rules('sub_id', 'Sub ID', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$p_title 		= $this->input->post('ptitle');
				$prod_code 		= $this->input->post('prod_code');
				$date_birth 	= $this->input->post('date_birth');
				$sub_id 		= $this->input->post('sub_id');
				$mother 		= $this->input->post('mother');
				$gender 		= $this->input->post('gender');
				for ($i=0; $i < count($prod_code) ; $i++) { 
					$data_to_insert = array(
						'sub_id' 		=> $sub_id,
						'prod_code'		=> $p_title.'-'.$prod_code[$i],
						'date_birth'	=> $date_birth,
						'mother'		=> $mother,
						'gender'		=> $gender
					);
					$this->livestock_model->add_product($data_to_insert);
				}
				
				
				unset($_POST);

				$response['status'] = true;	
				$response['new_sub_title'] = $p_title;	
				$response['msg'] = 'New Product Added!';	
				$this->session->set_flashdata('notify',$response);
				redirect('user/q/'.$var.'/'.$var2.'/'.$var3);

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		return $response;
		
	}
	public function edit_product($var, $var2, $var3){
		$response = array();
			$this->form_validation->set_rules('date_birth', 'Date of Birth', 'trim|required');
			$this->form_validation->set_rules('gender', 'Product Gender', 'trim|required');
			$this->form_validation->set_rules('prod_id', 'Prod ID', 'trim|required');
			$this->form_validation->set_rules('mother', 'From or Mother', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$date_birth 	= $this->input->post('date_birth');
				$prod_id 		= $this->input->post('prod_id');
				$mother 		= $this->input->post('mother');
				$gender 		= $this->input->post('gender');
				$pcode 			= $this->input->post('pcode');
				
				$new_sub_title  = explode('-', $pcode);
					
				
				$data_to_edit = array(
						'date_birth'	=> $date_birth,
						'mother'		=> $mother,
						'gender'		=> $gender
					);
				unset($_POST);
				$where = array('prod_id'=>$prod_id);
				$this->livestock_model->edit_product($data_to_edit, $where);

				$response['status'] = true;	
				$response['msg'] = '<i class="verified-icon"></i> Updated';
				$response['prod_id'] = $prod_id;	
				$this->session->set_flashdata('notify', $response);
				redirect('user/q/'.$var.'/'.$var2.'/'.$var3);

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		return $response;
		
	}
	public function move_product($var, $var2, $var3){
		$response = array();
			$this->form_validation->set_rules('prod_id', 'Prod ID', 'trim|required');
			$this->form_validation->set_rules('to_sub_id', 'To SubID', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$prod_id 		= $this->input->post('prod_id');
				$to_sub_id 		= $this->input->post('to_sub_id');
				$p_old 		= $this->input->post('p_old');
					
				$arr_to_sub = explode('-', $to_sub_id);
				$arr_prod = explode('-', $prod_id);

				$arr = $arr_to_sub[1].'-'.$arr_prod[2].'-'.$arr_prod[3].'-'.$arr_prod[4];

				$data_to_move = array('sub_id'  => $arr_to_sub[0], 'prod_code'=>$arr);
				$where 		  = array('prod_id' => $prod_id);
				unset($_POST);
				$this->livestock_model->edit_product($data_to_move, $where);
				$response['status'] = true;	
				// $response['new_sub_title'] = $arr_to_sub[1];
				// $response['msg'] = 'A '.$p_old.' moved here, from '.$arr_prod[1];	
				$this->session->set_flashdata('notify',$response);
				redirect('user/q/'.$var.'/'.$var2.'/'.$var3);

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		return $response;
		
	}

	public function product_forsale($var, $var2, $var3){
		$response = array();
			$this->form_validation->set_rules('prod_id', 'Prod ID', 'trim|required');
			$this->form_validation->set_rules('prod_code', 'Prod CODE', 'trim|required');
			$this->form_validation->set_rules('supp_id', 'Supplier ID', 'trim|required');
			$this->form_validation->set_rules('livestock_id', 'Livestock ID', 'trim|required');
			$this->form_validation->set_rules('price_rate', 'Price Rate', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$prod_id 		= $this->input->post('prod_id');
				$prod_code 		= $this->input->post('prod_code');
				$supp_id 		= $this->input->post('supp_id');
				$livestock_id 		= $this->input->post('livestock_id');
				$price_rate 	= $this->input->post('price_rate');
				$arr = explode('-', $prod_code);
				$data_to_insert = array(
									'prod_id'		=>$prod_id, 
									'price_rate'	=>$price_rate,
									'supp_id'		=>$supp_id,
									'livestock_id'	=>$livestock_id
								);
				$where 		    = array('prod_id' => $prod_id);
				unset($_POST);
				$this->livestock_model->edit_product(array('for_sale'=>1), $where);
				$this->livestock_model->add_product_pricing($data_to_insert);
				$response['status'] = true;	
				// $response['new_sub_title'] = $arr[0];
				// $response['msg'] = 'Code: '.$prod_code.' is now forsale.';	
				$this->session->set_flashdata('notify',$response);
				redirect('user/q/'.$var.'/'.$var2.'/'.$var3);

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		return $response;
		
	}
	public function change_product_status(){
		$data  = $this->input->post('data');
		$insert_history = array(
						'prod_id'	=> $data[0],
						'details'	=> $data[2],
						'date'		=> $data[3]
					);
		$data_to_edit = array('status'=>$data[1]);
		unset($_POST);
		$where = array('prod_id'=>$data[0]);
		$this->livestock_model->addTo_product_history($insert_history);
		$this->livestock_model->edit_product($data_to_edit, $where);
		$response = array('status'=>true);
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function getProductAge($prod_id){
		$data = array('prod_id'=>$prod_id);
		$prod = $this->livestock_model->getLivestock($data);
		date_default_timezone_set("Asia/Manila");
		$now = Date('F j, Y');
		$date_now = strtotime($now);
		$d_day = Date('j', $date_now);

			  	$mon=0;$age=0;$year=0;$day=0;$str="";
			  	$strDate = strtotime($prod->date_birth);
              	$b_date = date('F j, Y', $strDate);
                $b_day = date('j', $strDate);
                            		
                $o_day = ($date_now - $strDate) / 86400;
                	if($o_day > 0){

	                for ($i=1; $i <= $o_day; $i++) { 
	                	$ctr_date = ($strDate) + (86400 * $i);
	                	$d = Date('j', $ctr_date);

	                	if($b_day == $d){
	                		$mon++;
			           		$year = ($mon / 12);
	                		$day = 0;
	                	}
	                	else{
	                		if($mon > 0){$day++;}
	                		else{$day = $o_day;}
	                	}
	                }
                	}
                    else{$day = 0;}
                    $mon = $mon - (intval($year) * 12);
                   	$y = (intval($year) > 0) ? intval($year).' Year ' : ''; 
                   	$m = ($mon > 0) ? ($mon > 1) ? ($day > 0 ? $mon.' Months & ' : $mon.' Months ' ) : ($day > 0 ? $mon.' Month & ' : $mon.' Month ') : '' ;
					$d = ($day > 0) ? ($day > 1 ? $day.' Days ' : $day.' Day ') : (intval($year) > 0 || $mon > 0 ? '' : 'New Born');
			$response = array(
						'prod_id'	=>$prod->prod_id,
						'code'		=>preg_replace('/[^a-zA-Z0-9]/', '', $prod->prod_code),
						'age'		=>$y.$m.$d,
						'gender'	=> ($prod->gender == 'M' ? 'Male' : 'Female' ),
						'mother'	=>$prod->mother
						);

		return $response;
	}
	// public function edit_product($request){
	// 	$response = array();
	// 	if($request == 'update'){	
	// 		$this->form_validation->set_rules('product', 'Product Name', 'trim|required');
	// 		$this->form_validation->set_rules('description', 'Description', 'trim|required');
	// 		$this->form_validation->set_rules('price', 'Price', 'trim|required');
			
	// 		$image = array();
	// 		$image_check = true;
	// 		$stock = array();
	// 		$addon = array();
	// 		if($this->form_validation->run()){ 
	// 			$product 		= $this->input->post('product');
	// 			$description 	= $this->input->post('description');
	// 			$price 			= $this->input->post('price');
	// 			$per 			= $this->input->post('per');
	// 			$supp_id 		= $this->input->post('supp_id');
	// 			$prod_id 		= $this->input->post('prod_id');
				
	// 			$newImage = $this->input->post('photo');
	// 			$currentImage = $this->input->post('current_photo');
	// 			//edit images
	// 				if($_FILES['photo']['name'] != 0){

	// 					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
	// 					$sub_type = $this->session->userdata('user_info')->subscription_type;

	// 					if($no_of_files > 6 && $sub_type == 0){
							
								
	// 						$response['status'] = false;
	// 						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
	// 						//echo json_encode($response);			

	// 					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
	// 						$this->load->library('upload');
	// 						$myStr = $this->session->userdata('user_info')->first_name;

	// 						$key = mb_substr($myStr, 0, 3);
	// 						for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
	// 							$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
	// 							$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
	// 							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
	// 							$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
	// 							$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

	// 							$config = array(
	// 								'file_name'     => $i.$key.date('ymdhis'),
	// 								'allowed_types' => 'jpg|jpeg|png|gif',
	// 								'max_size'      => 10000,
	// 								'overwrite'     => TRUE,
	// 								'max_width'		=> 1000,
	// 								'max_height'	=> 768,
	// 								'upload_path'	=> 'uploads/listing'
	// 							);
	// 							$this->upload->initialize($config);

	// 							if ( !$this->upload->do_upload('userfile')) :
	// 								$error = $this->upload->display_errors();
	// 								$response['status'] = false;
	// 								$response['msg'] = $error;
	// 								$image_check = false;
	// 								break;

	// 							else :
	// 								if(count($currentImage) > 0){
	// 									$count = count($currentImage);
	// 									$image = $currentImage;
	// 									$image[$count++] = $this->upload->data('file_name'); 
	// 								}
	// 								else{
	// 									$image[] = $this->upload->data('file_name'); 
	// 								}
	// 							// Continue processing the uploaded data

	// 							endif;
	// 						}
							
	// 					}				    		
	// 				}
	// 			//end
	// 			$data_to_update = array(
	// 				'prod_name' 		=> ucfirst($product),
	// 				'prod_description'	=> ucfirst($description),
	// 				'prod_price'		=> $price,
	// 				'price_per'			=> $per
	// 			);

	// 			$response['msg'] = 'Listing Updated! Please add photos to your listing.';
				
	// 			if(count($image) > 0 && $image_check == true){
	// 				$data_to_update['prod_img'] = serialize(array('images' => $image));
	// 				$response['msg'] 		 = ($request == 'save' ? 'New Listing Added!' : 'Listing Updated!');
	// 			}
	// 			else{
	// 				$data_to_update['prod_img'] = serialize(array('images' => $currentImage));
	// 			}
	// 			unset($_POST);
	// 			$prod = array('prod_id'=>$prod_id);
	// 			$this->livestock_model->edit_product($prod, $data_to_update);
	// 			$branch = $this->branches_model->getBranch(array('supp_id'=>$supp_id));
	// 			$response['status'] = true;	
	// 			$response['msg'] = 'You have successfully updated product from '.$branch->supp_name;	
	// 			$this->session->set_flashdata('notify',$response);
	// 			redirect('user/branch_list');

	// 		}else{
	// 			$response['status'] = false;
	// 			$response['value']	= $_POST;
	// 			$response['msg'] = validation_errors();
				
	// 		}
		
	// 	}else{
	// 		//$response['status'] = false;
	// 		//$response['msg'] = 'Invalid Request!';
	// 		show_404();
	// 	}

	// 	if(IS_AJAX){
	// 		echo json_encode($response);
	// 		exit;
	// 	}else{
	// 		return $response;
	// 	}	

	// }
	public function getLivestockCategory($data){
		return $this->livestock_model->getLivestockCategory($data);
	}
	public function getCategory($data){
		return $this->livestock_model->getCategory($data);
	}
	public function getLivestockByCategory($data){
		return $this->livestock_model->getLivestockByCategory($data);
	}
	public function getProducts($data){
		return $this->livestock_model->getProducts($data);
	}
	public function getProductQty($data){
		return $this->livestock_model->getProductQty($data);
	}
	public function getLivestocks($data){
		return $this->livestock_model->getLivestocks($data);
	}
	public function getLivestock($data){
		return $this->livestock_model->getLivestock($data);
	}
	public function getLastProductID(){
		return $this->livestock_model->getLastProductID();
	}
	public function getCategories(){
		return $this->livestock_model->getCategories();
	}
	public function getSubCategoryByID($data){
		return $this->livestock_model->getSubCategoryByID($data);
	}
	public function getSubCategories($data){
		return $this->livestock_model->getSubCategories($data);
	}
	public function getProductHistory($data){
		return $this->livestock_model->getProductHistory($data);
	}
	public function getProductForsale($data){
		return $this->livestock_model->getProductForsale($data);
	}
	public function remove_sub_category(){
		$title = array('sub_title'=>$this->input->post('data'));
		return $this->livestock_model->remove_sub_category($title);
	}
	public function deleteLivestock($data){
		$arr = explode('_', $data);
		$result = $this->livestock_model->deleteLivestock(array('prod_id'=>$arr[0]));
		if($result){
			$response['status'] = true;
			$response['msg'] = 'You have successfully deleted Product named '.$arr[1].' from '.$arr[2];	
			$this->session->set_flashdata('notify',$response);
			redirect('user/branch_list'); 
		}
		else{
			$response['status'] = false;
			$response['msg'] = 'Invalid Argument!';	
			$this->session->set_flashdata('notify',$response);
			redirect('user/branch_list'); 
		}
	}
}
?>