<?php
class Livestock_model extends MY_Model{

	function __construct(){
		parent::__construct();
	}
	public function add_product($data){
		return $this->db->insert('product', $data);
	}
	public function add_product_pricing($data){
		return $this->db->insert('product_pricing', $data);
	}
	public function addTo_product_history($data){
		return $this->db->insert('product_history', $data);
	}
	public function add_livestock_category($data){
		return $this->db->insert('livestock_category', $data);
	}
	public function getProductForsale($data){
		$this->db->select('*');
        $this->db->from('product prod, livestock_category cat'); 
        $this->db->join('product_pricing p_pricing', 'p_pricing.prod_id=prod.prod_id and p_pricing.livestock_id=cat.livestock_id', 'inner');
        $this->db->where($data);
		$query = $this->db->get();
		return $query->num_rows() > 0 ? $query->result() : false;
	}
	public function getLivestockCategory($data){
		$this->db->select('*');
        $this->db->from('category_for_livestock cat_for'); 
        $this->db->join('livestock_category cat', 'cat.cat_id=cat_for.cat_id', 'inner');
        $this->db->where($data);
		$query = $this->db->get();
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getCategory($data){
		$this->db->select('*');
        $this->db->from('category_for_livestock cat_for'); 
        $this->db->join('livestock_category cat', 'cat.cat_id=cat_for.cat_id', 'inner');
        $this->db->where($data);
		$query = $this->db->get();
		return $query->num_rows() > 0 ? $query->row() : false;
	}
	public function getCategories(){
		$query = $this->db->get('category_for_livestock');
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getProductHistory($data){
		$this->db->select('*');
        $this->db->from('product p'); 
        $this->db->join('product_history ph', 'ph.prod_id=p.prod_id', 'inner');
        $this->db->where($data);
		$query = $this->db->get();
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getLivestockByCategory($data){
		$this->db->select('*');
        $this->db->from('category_for_livestock cat_for'); 
        $this->db->join('livestock_category cat', 'cat.cat_id=cat_for.cat_id', 'inner');
        $this->db->where($data);
		$query = $this->db->get();
		return $query->num_rows() > 0 ? $query->row() : false; 
	}
	public function getSubCategoryByID($data){
		$query = $this->db->get_where('sub_category', $data);
		return $query->num_rows() > 0 ? $query->row() : false; 
	}
	public function getLivestocks($data){
		$query = $this->db->get_where('product', $data);
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getLivestock($data){
		$query = $this->db->get_where('product', $data);
		return $query->num_rows() > 0 ? $query->row() : false; 
	}
	public function add_sub_category($data){
		$this->db->insert('sub_category', $data);
		return $this->db->affected_rows() > 0 ? true : false; 
	}
	public function remove_sub_category($data){
		$this->db->delete('sub_category', $data);
		return $this->db->affected_rows() > 0 ? true : false; 
	}
	public function getSubCategories($data){
		$this->db->select('*');
        $this->db->from('category_for_livestock cat_for'); 
        $this->db->join('livestock_category cat', 'cat.cat_id=cat_for.cat_id', 'inner');
        $this->db->join('sub_category sub', 'sub.livestock_id=cat.livestock_id', 'inner');
		$this->db->where($data);
        $query = $this->db->get();
		return $query->num_rows() > 0 ? $query->result() : false; 	
	}
    public function getProducts($data){
        $this->db->select('*');
        $this->db->from('livestock_category cat'); 
        $this->db->join('sub_category sub', 'sub.livestock_id=cat.livestock_id', 'inner');
        $this->db->join('product prod', 'prod.sub_id=sub.sub_id', 'inner');
        $this->db->where($data);
        $this->db->order_by('date_birth');
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getProductQty($data){
       	$this->db->select('*, count(sub_id) as p_qty');
		$query = $this->db->get_where('product', $data);
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getLastProductID(){
    	$this->db->select('*, max(prod_id) as lastProdID');
		$query = $this->db->get('product');
        return $query->num_rows() > 0 ? $query->row() : false;
    }
	public function edit_product($data, $where){
        return $this->db->update('product',$data, $where);
	}
	public function deleteLivestock($data){
		return $this->db->delete('product', $data);
	}
}
?>