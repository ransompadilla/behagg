<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Listing extends MY_Controller {

	public function __construct(){
		parent::__construct();
	
		$this->load->model('ListingModel'); 
		$this->load->model('user/UserModel'); 
		$this->load->model('wishlist/wishlist_model'); 

	}

	public function index(){
		show_404();
	}
	//new
	public function addToMyList($data){
		return $this->ListingModel->addToMyList($data);
	}
	public function getListedList($data){
		return $this->ListingModel->getListedList($data);
	}
	public function countJunkSuppliers($data){
		return $this->ListingModel->countJunkSuppliers($data);
	}
	public function viewJunkSuppliers(){
		$user_id = $this->session->userdata('user_info')->id;
		$suppliers = array();
		
		if($_POST){
			$data = $this->input->post('data');
			$jcount = $this->ListingModel->countJunkSuppliers(array('user_id'=>$data[0], 'junk'=>1));
			$junkSupplier = $this->UserModel->getUserSuppliers(array('ul.user_id'=>$data[0], 'ul.junk'=>$data[1]));
			if($junkSupplier){
				foreach ($junkSupplier as $key => $value) {
					$arr = array(
						'ulist_id'		=>$value->ulist_id,
						'id'			=>$value->supp_id,
						'name'			=>$value->supp_name,
						'description'	=>$value->supp_desc,
						'address'		=>unserialize($value->supp_address),
						'contact'		=>$value->supp_contact,
						'media'			=>unserialize($value->media),
						'user_id'		=>$user_id
					);
					array_push($suppliers, $arr);
				}
			}
			$response = array('status'=>true, 'suppliers'=>$suppliers, 'count_junk'=>$jcount->junk > 0 ? '<div class="user-name"><i class="sl sl-icon-trash"></i> Junk('.$jcount->junk.')</div>' : '');
			//add the header here
			header('Content-Type: application/json');
			echo json_encode($response);
		}
		else{
			$jcount = $this->ListingModel->countJunkSuppliers(array('user_id'=>$user_id, 'junk'=>1));
			$junkSupplier = $this->UserModel->getUserSuppliers(array('ul.user_id'=>$user_id, 'ul.junk'=>1));
			if($junkSupplier){
				foreach ($junkSupplier as $key => $value) {
					$arr = array(
						'ulist_id'		=>$value->ulist_id,
						'id'			=>$value->supp_id,
						'name'			=>$value->supp_name,
						'description'	=>$value->supp_desc,
						'address'		=>$value->supp_address,
						'contact'		=>$value->supp_contact,
						'media'			=>$value->media,
						'user_id'		=>$user_id
					);
					array_push($suppliers, $arr);
				}
			}
			return $suppliers;
		}
	}
	public function junkSupplier(){
		$response = array();
		$arr = $this->input->post('data');
		$data = array('junk'=>1);
		$where = array('supp_id'=>$arr[0], 'user_id'=>$arr[1]);
		$result = $this->wishlist_model->removeFromWishlist($where);
		$result = $this->ListingModel->junkSupplier($data, $where);
		if($result){
			$response = array('supp_id'=>$arr[0], 'user_id'=>$arr[1], 'status'=>true);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}

	public function UnJunkSupplier(){
		$response = array();
		$arr = $this->input->post('data');
		$data = array('junk'=>0);
		$where = array('supp_id'=>$arr[0], 'user_id'=>$arr[1]);
		$result = $this->ListingModel->UnJunkSupplier($data, $where);
		if($result){
			$response = array('supp_id'=>$arr[0], 'status'=>true);
		}
		else{
			$response = array('status'=>false);
		}
		//add the header here
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	//END RANSOM FUNCTION
}

