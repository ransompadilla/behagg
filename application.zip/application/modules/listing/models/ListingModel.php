<?php
class ListingModel extends MY_Model{

	function __construct(){
		parent::__construct();
	}
	//new
	public function addToMyList($data){
		$this->db->insert('user_listing', $data);
		return ($this->db->affected_rows() > 0) ? true : false ;
	}
	public function getListedList($data){
		$query = $this->db->get_where('user_listing', $data);
		return $query->num_rows() > 0 ? true:false;
	}
	//supplier listing
    public function junkSupplier($data, $where){
        $this->db->update('user_listing', $data, $where); 
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function UnJunkSupplier($data,$where){
        $this->db->update('user_listing', $data, $where); 
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function countJunkSuppliers($data){
        $sql = "SELECT count(junk) as junk FROM user_listing where user_id = ? and junk=?";
        $query = $this->db->query($sql, $data);
        return ($query->num_rows() > 0) ? $query->row() : false;
    }
}

?>