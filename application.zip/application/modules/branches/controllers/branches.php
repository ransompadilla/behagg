<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Branches extends MY_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('branches_model');

	}
	public function add_branch($request){
		$response = array();
		if($request == 'save'){	
			$this->form_validation->set_rules('com_name', 'Company Name', 'trim|required');
			$this->form_validation->set_rules('description', 'Description', 'trim|required');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('contact', 'Contact', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$com_name 		= $this->input->post('com_name');
				$description 	= $this->input->post('description');
				$contact 	= $this->input->post('contact');
				$address 	= $this->input->post('address');
				$state 	= $this->input->post('state');
				$city 	= $this->input->post('city');
				$user_id = $this->session->userdata('user_info')->id;

				$arr = explode(",", $state);
				$location = array('address'=>ucfirst($address), 'state'=>array('abbrev'=>$arr[0], 'name'=>$arr[1]), 'city'=>$city);

				$com_name = preg_replace('/[^a-zA-Z0-9]/',' ', $com_name);
				//add Images
				if($_FILES['photo']['name'] != 0){

					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
					$sub_type = $this->session->userdata('user_info')->subscription_type;

					if($no_of_files > 6 && $sub_type == 0){
						
							
						$response['status'] = false;
						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
						//echo json_encode($response);			

					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
						$this->load->library('upload');
						$myStr = $this->session->userdata('user_info')->first_name;
						$key = mb_substr($myStr, 0, 3);
						for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
							$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
							$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
							$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
							$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

							$config = array(
								'file_name'     => $i.$key.date('ymdhis'),
								'allowed_types' => 'jpg|jpeg|png|gif',
								'max_size'      => 10000,
								'overwrite'     => TRUE,
								'max_width'		=> 1000,
								'max_height'	=> 768,
								'upload_path'	=> 'uploads/listing'
							);
							$this->upload->initialize($config);

							if ( !$this->upload->do_upload('userfile')) :
								$error = $this->upload->display_errors();
								$response['status'] = false;
								$response['msg'] = $error;
								$image_check = false;
								break;

							else :

							$image[] = $this->upload->data('file_name'); 
							// Continue processing the uploaded data

							endif;
						}
						
					}				    		
				}
				//end
				$data_to_insert = array(
					'supp_name' 		=> ucfirst($com_name),
					'supp_desc'			=> ucfirst($description),
					'supp_address' 		=> serialize($location),
					'supp_contact'		=> $contact,
					'user_id' 			=> $user_id
				);

				if($request == 'save'):
					$data_to_insert['media'] = serialize(array('images' => ''));
					$response['msg'] = 'New Listing Added! Please add photos to your listing.';
				else:
					$response['msg'] = 'Listing Updated! Please add photos to your listing.';
				endif;

				if(count($image) > 0 && $image_check == true){
					$data_to_insert['media'] = serialize(array('images' => $image));
					$response['msg'] 		 = ($request == 'save' ? 'New Listing Added!' : 'Listing Updated!');
				}
				
				unset($_POST);

				$id_list = $this->branches_model->add_branch($data_to_insert);
				$response['status'] = true;	
				$this->session->set_flashdata('notify',$response);
				redirect('user/branch-list');

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}
	public function edit_branch($request){
		$response = array();
		if($request == 'update'){	
			$this->form_validation->set_rules('com_name', 'Company Name', 'trim|required');
			$this->form_validation->set_rules('description', 'Description', 'trim|required');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('state', 'State', 'trim|required');
			$this->form_validation->set_rules('city', 'City', 'trim|required');
			$this->form_validation->set_rules('contact', 'Contact', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$supp_id 		= $this->input->post('supp_id');
				$com_name 		= $this->input->post('com_name');
				$description 	= $this->input->post('description');
				$contact 	= $this->input->post('contact');
				$address 	= $this->input->post('address');
				$state 	= $this->input->post('state');
				$city 	= $this->input->post('city');
				$user_id = $this->session->userdata('user_info')->id;

				$com_name = preg_replace('/[^a-zA-Z0-9]/',' ', $com_name);
				
				$newImage = $this->input->post('photo');
				$currentImage = $this->input->post('current_photo');

				$arr = explode(",", $state);
				$location = array('address'=>ucfirst($address), 'state'=>array('abbrev'=>$arr[0], 'name'=>$arr[1]), 'city'=>$city);

				//edit images
					if($_FILES['photo']['name'] != 0){

						$no_of_files = sizeof($_FILES['photo']['tmp_name']);
						$sub_type = $this->session->userdata('user_info')->subscription_type;

						if($no_of_files > 6 && $sub_type == 0){
							
								
							$response['status'] = false;
							$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
							//echo json_encode($response);			

						}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
							$this->load->library('upload');
							$myStr = $this->session->userdata('user_info')->first_name;

							$key = mb_substr($myStr, 0, 3);
							for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
								$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
								$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
								$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
								$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
								$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

								$config = array(
									'file_name'     => $i.$key.date('ymdhis'),
									'allowed_types' => 'jpg|jpeg|png|gif',
									'max_size'      => 10000,
									'overwrite'     => TRUE,
									'max_width'		=> 1000,
									'max_height'	=> 768,
									'upload_path'	=> 'uploads/listing'
								);
								$this->upload->initialize($config);

								if ( !$this->upload->do_upload('userfile')) :
									$error = $this->upload->display_errors();
									$response['status'] = false;
									$response['msg'] = $error;
									$image_check = false;
									break;

								else :
									if(count($currentImage) > 0){
										$count = count($currentImage);
										$image = $currentImage;
										$image[$count++] = $this->upload->data('file_name'); 
									}
									else{
										$image[] = $this->upload->data('file_name'); 
									}
								// Continue processing the uploaded data

								endif;
							}
							
						}				    		
					}
				//end
				$data_to_update = array(
					'supp_name' 		=> ucfirst($com_name),
					'supp_desc'			=> ucfirst($description),
					'supp_address' 		=> serialize($location),
					'supp_contact'		=> $contact
				);

				$response['msg'] = 'Listing Updated! Please add photos to your listing.';
				
				if(count($image) > 0 && $image_check == true){
					$data_to_update['media'] = serialize(array('images' => $image));
					$response['msg'] 		 = ($request == 'save' ? 'New Listing Added!' : 'Listing Updated!');
				}
				else{
					$data_to_update['media'] = serialize(array('images' => $currentImage));
				}
				unset($_POST);

				$branch = array('supp_id'=>$supp_id);
				
				$getBranch = $this->branches_model->getBranch($branch);
				$this->branches_model->edit_branch($data_to_update, $branch);

				$response['status'] = true;	
				$response['msg'] = 'You have successfully updated branch '.$getBranch->supp_name;	
				$this->session->set_flashdata('notify',$response);
				redirect('user/branch_list');

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}
	public function getBranches($data){
		return $this->branches_model->getBranches($data);
	}
	public function getBranch($data){
		return $this->branches_model->getBranch($data);
	}
	public function delete_branch($data){
		$arr = explode('_', $data);
		$result = $this->branches_model->delete_branch(array('supp_id'=>$arr[0]));
		if($result){
			$response['status'] = true;
			$response['msg'] = 'You have successfully deleted branch '.$arr[1];	
			$this->session->set_flashdata('notify',$response);
			redirect('user/branch_list'); 
		}
		else{
			$response['status'] = false;
			$response['msg'] = 'Invalid Argument!';	
			$this->session->set_flashdata('notify',$response);
			redirect('user/branch_list'); 
		}
	}
}
?>