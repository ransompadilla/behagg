<?php
class Branches_model extends MY_Model{

	function __construct(){
		parent::__construct();
	}
	public function add_branch($data){
		return $this->db->insert('supplier', $data);
	}
	public function getBranches($data){
		$this->db->order_by('supp_id','desc');
		$query = $this->db->get_where('supplier', $data);
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getBranchesListings(){
		$this->db->order_by('supp_id','desc');
		$query = $this->db->get('supplier');
		return $query->num_rows() > 0 ? $query->result() : false; 
	}
	public function getBranch($data){
		$query = $this->db->get_where('supplier', $data);
		return $query->num_rows() > 0 ? $query->row() : false; 
	}
	public function edit_branch($data, $where){
		return $this->db->update('supplier', $data, $where);
	}
	public function delete_branch($where){
		return $this->db->delete('supplier', $where);
	}
	
}
?>