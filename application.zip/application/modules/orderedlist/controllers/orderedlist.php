<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Orderedlist extends MY_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('orderedlist_model'); 
		$this->load->model('notification/notification_model'); 
		$this->load->model('user/UserModel'); 
	}
	public function getOrderlistByUser($data){
		return $this->orderedlist_model->getOrderlistByUser($data);
	}
	public function count_unread(){
		$user_id = $this->session->userdata('user_info')->id;
		$thread = array();$count=0;
		$supplier = $this->orderedlist_model->getSupplierByUserID(array('user_id'=>$user_id));
		if($supplier){
			foreach ($supplier as $key => $supp) {
			$orderlist = $this->orderedlist_model->getOrderlistBySupplierID(array('supp_id'=>$supp->supp_id));
			if($orderlist){
				foreach ($orderlist as $key => $list) {
					$unread = $this->orderedlist_model->getCountOrderUnread(array(0, $list->supp_id));
					}
				}
				$count += $unread->unread;
			}
		}
		return $count;
	}
	public function load_orderedlist(){
		$user_id = $this->session->userdata('user_info')->id;
		$orderlist = $this->orderedlist_model->getOrderlists();
		$thread = array();$response = array();
		if($orderlist){
			foreach ($orderlist as $key => $list) {

			$user_supp = $this->orderedlist_model->getUserFromSupplier(array('supp_id'=>$list->supp_id));
				if($user_supp->user_id == $user_id){
				
				$user = $this->UserModel->getUserInfo($list->user_id);
				$arr = array(
						'order_id' 		=> $list->order_id,
						'order_num' 	=> $list->order_num,
						'item_count' 	=> 'item\'s('.$list->item_count.')',
						'total' 		=> $list->total,
						'time' 			=> date("M j, g:i A", strtotime($list->order_date)),
						'order_type' 	=> $list->order_type,
						'payment_method'=> $list->payment_method,
						'avatar' 		=> $user->avatar != '' ? $user->avatar : $user->gender == 'male' ? 'happy-client-02.jpg' : 'happy-client-01.jpg',
						'name'			=> ucwords($user->first_name.' '.$user->last_name),
						'type'			=>$list->order_type == 'pick-up' ? 'Pick UP <i class="fa fa-thumbs-up"></i>' : 'Deliver <i class="fa fa-truck"></i>',
						'is_read' 		=> $list->is_read,
						'supp_id' 		=> $list->supp_id,
						'status' 		=> $list->status
						);
					array_push($thread, $arr);
					$response = array(
									'status' => true, 
									'thread' => $thread, 
									'count'	 => $this->count_unread()
								);
				}
			}
		}
		
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function getOrderByOrderNO($data){
		return $this->orderedlist_model->getOrderByOrderNO($data);
	}
	public function update_readNotification($data){
		return $this->orderedlist_model->update_readNotification($data);
	}
	public function process_order(){
		$response = array();
		$data = $this->input->post('data');
		$data = explode('-', $data);
		$update = array('status'=>1); $where=array('order_id'=>$data[0], 'status'=>0);
		$result = $this->orderedlist_model->process_order($update, $where);
		if($result){
			$insert = array(
							'table_name'	=>'order_detail', 
							'table_id'		=>$data[0],
							'status'		=>1, 
							'user_id'		=>$data[1], 
							'supp_id'		=>$data[2]
						);
			$this->notification_model->insert_notifications($insert);
			$response = array('status' => true);
		}
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function process_order_done(){
		$response = array();
		$data = $this->input->post('data');
		$data = explode('-', $data);
		$update = array('status'=>2); $where=array('order_id'=>$data[0], 'status'=>1);
		$result = $this->orderedlist_model->process_order($update, $where);
		if($result){
			$upd = array(
						'status'	=>2, 
						'is_read'	=>0, 
						'notif_date'=>$this->getCurrentDateTime()
						); 
			$whr = array('table_id'=>$data[0]);
			$this->notification_model->update_UserNotification($upd, $whr);
			$response = array('status' => true);
		}
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
}