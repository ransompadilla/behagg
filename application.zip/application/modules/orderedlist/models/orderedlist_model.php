<?php
class orderedlist_model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}
    public function getOrderlistByUser($data){
        $this->db->select('*');
        $this->db->from('supplier sup'); 
        $this->db->join('order_detail or', 'or.supp_id=sup.supp_id', 'inner');
        $this->db->where($data);
        $this->db->order_by('or.order_date','desc');
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getUserFromSupplier($data){
        $query = $this->db->get_where('supplier', $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function getOrderlists(){
        $this->db->order_by('order_date','desc');
        $query = $this->db->get('order_detail');
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getOrderlistBySupplierID($data){
        $this->db->order_by('order_date','desc');
        $query = $this->db->get_where('order_detail', $data);
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getSupplierByUserID($data){
        $query = $this->db->get_where('supplier', $data);
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function getCountOrderUnread($data){
        $sql = "SELECT count(order_id) as unread FROM order_detail WHERE is_read=? and supp_id =?";
        $query = $this->db->query($sql, $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }

    public function last_read($data){
        $sql = "SELECT count(order_id) as order_id FROM order_detail WHERE supp_id=? and is_read= ? ";
        $query = $this->db->query($sql, $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function new_order($last_read, $supp_id){
        $query  =  $this->db->where('supp_id', $supp_id)
                              ->where('order_id  > ', $last_read)
                              ->order_by('order_date', 'desc')
                              ->get('order_detail');
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function getOrderByOrderNO($data){
        $query = $this->db->get_where('order_detail', $data);
        return $query->num_rows() > 0 ? $query->row() : false;
    }
    public function update_readNotification($data){
        $this->db->update('order_detail', array('is_read'=>1), $data);
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function process_order($data, $where){
        $this->db->update('order_detail', $data, $where);
        return $this->db->affected_rows() > 0 ? true : false;
    }
    
}
?>