<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct(){
        parent::__construct();

		if(!$this->check_login()){
			redirect('/');
		}else{			
			if($this->session->userdata('status') != 1){
			redirect('/');
			}
		}
    }


	public function logout(){
		$this->session->sess_destroy();
		
		redirect('/');
		exit;
	}



}