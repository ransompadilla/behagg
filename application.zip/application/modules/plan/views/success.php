<h2>Dear <?php echo $paypal_info['first_name']." ".$paypal_info['last_name'].","; ?></h2>
<p>Your payment was successful, thank you for purchase.</p>
<p>Item : <b><?php echo $paypal_info['item_name']; ?></b></p>
<p>TXN ID : <b><?php echo $paypal_info['txn_id']; ?></b></p>
<p>Amount Paid : <b>$<?php echo $paypal_info['mc_gross']?></b></p>
<p>Payment Status : <b><?php echo $paypal_info['payer_status']; ?></b></p>
<p>Currency : <b><?php echo $paypal_info['mc_currency']; ?></b></p>
<p>Payment Date : <b>
		<?php 
			$d = strtotime($paypal_info['payment_date']);
			$date = date('F j Y @ H:i:sa', $d);
			echo $date; 
		?>
</b></p>
<a href="<?php echo base_url('pricing'); ?>">Back to Pricing</a>