<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages extends MY_Controller {
	protected $smiley_url = 'http://localhost/livestock/public_html/assets/images/smileys';
	public function __construct(){
        parent::__construct();
        $this->load->model('messages_model');
        $this->load->model('user/UserModel');
		$this->load->helper('smiley');
    }

	public function index(){
		show_404();
	}
	//RANSOM FUNCTIONS
	public function messages(){
		//get paginated messages 
		$per_page 	= 5;
		$user		= $this->session->userdata('user_info')->id;
		$buddy 		= $this->input->post('user');
		$limit 		= isset($_POST['limit']) ? $this->input->post('limit') : $per_page ;
		$messages 	= array_reverse($this->messages_model->conversation($user, $buddy, $limit));
		$total 		= $this->messages_model->thread_len($user, $buddy);
		$list_name = $this->UserModel->getUserInfo($buddy);

		$unread = $this->messages_model->unread_per_user($user, $buddy);
		$thread = array();
		foreach ($messages as $message) {
			$owner = $this->UserModel->getUserInfo($message->from);
			$m_arr = array();
			$str = $message->message;
			$len = strlen($str);
			for($i=0;$i<$len;$i++){
				if($i < 20){
					array_push($m_arr, $str[$i]);
				}
			}
			$chat = array(
				'msg' 		=> $message->id,
				'sender' 	=> $message->from, 
				'recipient' => $message->to,
				'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
				'body' 		=>  parse_smileys($message->message, $this->smiley_url),
				'time' 		=> date("M j, g:i a", strtotime($message->time)),
				'type'		=> $message->from == $user ? 'out' : 'in',
				'seen'		=> $message->seen != NULL ? ' seen: '.$this->UserModel->getUserInfo($message->seen)->first_name : '',
				'name'		=> $message->from == $user ? 'You' : ucwords($owner->first_name),
				'list_name'	=> ucwords($list_name->first_name.' '.$list_name->last_name),
				'unread'	=> $unread > 0 ? '('.$unread.')' : ''
				);
			array_push($thread, $chat);
		}

		$chatbuddy = $this->UserModel->getUserInfo($buddy);

		$contact = array(
			'name'=>ucwords($chatbuddy->first_name.' '.$chatbuddy->last_name),
			'id'=>$chatbuddy->id,
			'limit'=>$limit + $per_page,
			'more' => $total  <= $limit ? false : true, 
			'scroll'=> $limit > $per_page  ?  false : true,
			'remaining'=> $total - $limit
			);

			$response = array(
					'success' => true,
					'errors'  => '',
					'message' => '',
					'buddy'	  => $contact,
					'thread'  => $thread
					);
		//add the header here
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	public function save_message(){
		$logged_user = $this->session->userdata('user_info')->id;
		$buddy 		= $this->input->post('user');
		$message 	= $this->input->post('message');
		$unread = $this->messages_model->unread_per_user($logged_user, $buddy);
		if($message != '' && $buddy != '')
		{

		$list_name = $this->UserModel->getUserInfo($buddy);
			$msg_id = $this->messages_model->insertMessage(array(
						'from' 		=> $logged_user,
						'to' 		=> $buddy,
						'message' 	=> $message,
					));
			$msg = $this->messages_model->getMessageByID($msg_id);

			
			$owner = $this->UserModel->getUserInfo($msg->from);
			$chat = array(
				'msg' 		=> $msg->id,
				'sender' 	=> $msg->from, 
				'recipient' => $msg->to,
				'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
				'body' 		=> parse_smileys($msg->message, $this->smiley_url),
				'time' 		=> date("M j, g:i a", strtotime($msg->time)),
				'type'		=> $msg->from == $logged_user ? 'out' : 'in',
				'seen'		=> $msg->seen != NULL ? ' seen: '.$this->UserModel->getUserInfo($msg->seen)->first_name : '',
				'name'		=> $msg->from == $logged_user ? 'You' : ucwords($owner->first_name),
				'list_name'	=> ucwords($list_name->first_name.' '.$list_name->last_name),
				'unread'	=> $unread > 0 ? '('.$unread.')' : ''
				);
			$response = array(
				'success' => true,
				'message' => $chat
				);
		}
		else{
			  $response = array(
				'success' => false,
				'message' => 'Empty fields exists'
				);
		}
		//add the header here
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function updates(){
	    $new_exists = false;
		$user_id 	= $this->session->userdata('user_info')->id;

		$last_seen = $this->messages_model->last_seen($user_id);
		$exists = $this->messages_model->latest_message($user_id, $last_seen->id);

		
		//echo $exists;
		if($exists){
			$new_exists = true;
		}
		// THIS WHOLE SECTION NEED A GOOD OVERHAUL TO CHANGE THE FUNCTIONALITY
	    if ($new_exists) {
	        $new_messages = $this->messages_model->unread($user_id);
			$thread = array();
			$senders = array();
			foreach ($new_messages as $message) {
				if(!isset($senders[$message->from])){
					$senders[$message->from]['count'] = 1; 
				}
				else{
					$senders[$message->from]['count'] += 1; 
				}
				$owner = $this->UserModel->getUserInfo($message->from);
				$list_name = $this->UserModel->getUserInfo($message->from);
				$unread = $this->messages_model->unread_per_user($user_id, $message->from);

				$chat = array(
					'msg' 		=> $message->id,
					'sender' 	=> $message->from, 
					'recipient' => $message->to,
					'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
					'body' 		=> parse_smileys($message->message, $this->smiley_url),
					'time' 		=> date("M j, g:i a", strtotime($message->time)),
					'type'		=> $message->from == $user_id ? 'out' : 'in',
					'seen'		=> $message->seen != NULL ? ' seen: '.$this->UserModel->getUserInfo($message->seen)->first_name : '',
					'name'		=> $message->from == $user_id ? 'You' : ucwords($owner->first_name),
					'list_name'	=> ucwords($list_name->first_name.' '.$list_name->last_name),
					'unread'	=> $unread > 0 ? '('.$unread.')' : ''
					);
				array_push($thread, $chat);
			}

			$groups = array();
			foreach ($senders as $key=>$sender) {
				$sender = array('user'=> $key, 'count'=>$sender['count']);
				array_push($groups, $sender);
			}
			$response = array(
				'success' => true,
				'messages' => $thread,
				'senders' =>$groups
			);

			//add the header here
			header('Content-Type: application/json');
			echo json_encode( $response );
	    } 
	}
	public function load_message_list(){
		$user_id 	= $this->session->userdata('user_info')->id;
		$users = $this->messages_model->getChatMessages($user_id);
		$lst_users = array();

			foreach ($users as $u) {
				$last_m = $this->messages_model->getLastMessage($u->from, $user_id);
				$u_ser = $this->UserModel->getUserInfo($u->from);
				$unread = $this->messages_model->unread_per_user($user_id, $u->from);
				$arr = array(
					'from' 		=> $u->from,
					'name' 		=>  ucwords($u_ser->first_name.' '.$u_ser->last_name), 
					'avatar' 	=> $u_ser->avatar != '' ? $u_ser->avatar : 'no-image.jpg',
					'last_message' => $last_m->from == $user_id ? 'You: '.$last_m->message : $last_m->message,
					'time'		=> date("M j, g:i a", strtotime($last_m->time)),
					'seen'		=> $last_m->seen != NULL && $last_m->seen != $user_id ? ' seen: '.ucfirst($this->UserModel->getUserInfo($last_m->seen)->first_name) : "",
					'unread'	=> $unread > 0 ? '('.$unread.')' : ''
					);
					array_push($lst_users, $arr);
			}
			$response = array(
				'success' => true,
				'users' =>$lst_users
			);
		return $response;
	}
	public function mark_read(){
		$id = $this->input->post('id');
		$buddy = $this->input->post('buddy');
		$this->messages_model->mark_read($id, $buddy);
	}
	public function unread_per_user($to, $from){
		return $this->messages_model->unread_per_user($to, $from);
	}
	public function getChatMessages($id){
		return $this->messages_model->getChatMessages($id);
	}
	public function getUnreadMessages($id){
		return $this->messages_model->getUnreadMessages($id);
	}
	public function getLastMessage($from, $to){
		return $this->messages_model->getLastMessage($from, $to);
	}
	public function seen_message($from, $to){
		return $this->messages_model->seen_message($from, $to);
	}
}
