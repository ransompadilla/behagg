<?php
class Messages_model extends MY_Model{

	function __construct(){
		parent::__construct();
	}
	//People Message List
	public function getChatMessages($id){


		$this->db->where('to', $id);
		$this->db->distinct();
		$this->db->select('from');
		$query = $this->db->get('messages');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	
	public function getUnreadMessages($id){
		$query = $this->db->where('to', $id);
		$query = $this->db->where('seen', NULL);
		$query = $this->db->get('messages');
		//$query = $this->db->get_where('chat', array('from'=>$id));
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	public function getLastMessage($from, $to){
		$this->db->order_by('time', 'desc');
		$this->db->where('from', $from);
		$this->db->where('to', $to);
		$this->db->or_where('from', $to);
		$this->db->where('to', $from);
		$query = $this->db->get('messages');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	
	}
	public function seen_message($from, $to){
		$this->db->where('from', $to);
		$this->db->where('to', $from);
		$this->db->or_where('from', $to);
		$this->db->update('messages', array('seen'=>$from));
	}
	
	//Conversation
	public function conversation($user, $chatbuddy, $limit = 5){
        $this->db->where('from', $user);
        $this->db->where('to', $chatbuddy);
        $this->db->or_where('from', $chatbuddy);
        $this->db->where('to', $user);
        $this->db->order_by('time', 'desc');
        $messages = $this->db->get('messages', $limit);

        $this->db->where('to', $user)->where('from',$chatbuddy)->update('messages', array('is_read'=>'1', 'seen'=>$user));
        return $messages->result();
	}
	public function thread_len($user, $chatbuddy){
        $this->db->where('from', $user);
        $this->db->where('to', $chatbuddy);
        $this->db->or_where('from', $chatbuddy);
        $this->db->where('to', $user);
        $this->db->order_by('time', 'desc');
        $messages = $this->db->count_all_results('messages');
        return $messages;
	}
	public function insertMessage($data = array()){
		$this->db->insert('messages', $data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}
	public function getMessageByID($message_id){
		$this->db->where('id', $message_id);
		$query = $this->db->get('messages');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	public function last_seen($id){
		$this->db->order_by('time','desc');
		$query = $this->db->get_where('messages', array('to'=>$id, 'seen <>'=>NULL, 'is_read >'=>0));
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	public function latest_message($user, $last_seen){
		$message  =  $this->db->where('to', $user)
							  ->where('id  > ', $last_seen)
							  ->order_by('time', 'desc')
							  ->get('messages', 1);

		if($message->num_rows() > 0){
			return true;
		}
		else{
			return false;
		}
	}
	public function unread($user){
		$messages  =  $this->db->where('to', $user)
							  ->where('is_read', '0')
							  ->order_by('time', 'asc')
							  ->get('messages');

		return $messages->result();
	}
	public function mark_read($id, $buddy){
		$this->db->where('id', $id)->update('messages', array('is_read'=>'1', 'seen'=>$buddy));
	}
	public function unread_per_user($to, $from){
		$count  =  $this->db->where('to', $to)
							->where('from', $from)
							->where('is_read', '0')
							->count_all_results('messages');
		return $count;
	}
}

?>