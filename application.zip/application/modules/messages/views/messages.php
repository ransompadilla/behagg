<!-- Titlebar -->

        <div id="header-container" class="fixed fullwidth dashboard messages-section row">
            
            <!-- Listings -->
            <div class="list-people col-md-3">
               
                <div class="user-menu">
                    <div class="user-name">
                    <a href="<?php echo base_url('user/dashboard'); ?>">
                        <span>
                            <img src="<?php echo base_url();?>assets/images/dashboard-avatar.jpg" alt="">
                        </span>
                            <?php echo ucfirst($this->session->userdata('user_info')->first_name).' '.ucfirst($this->session->userdata('user_info')->last_name).'.'; ?>
                    </a>
                    </div>
                </div>
                <a href="<?php echo base_url('/'); ?>" ><img src="<?php echo base_url();?>assets/images/logo/livestock-logo.png" alt=""></a>
                <div class="search-input">
                     <input type="text" name="" placeholder="Search" />
                </div>

                <div class="messages-container margin-top-0">
                    <div>
                        <ul class="message-list">
                            <?php 
                if($message_list && $message_list['success']){
                  foreach ($message_list['users'] as $mList) {
                    if($mList['from'] != $this->session->userdata('user_info')->id){?>
                    <li class="message-list unread">
                        <a id="<?php echo $mList['from'];?>" href="<?php echo site_url('user/messages/'.$mList['from']);?>">
                            <div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>
                            <div id="message-name"><?php echo $mList['name'] ?> <?php echo $mList['unread'] ?><span id="m-date"><?php echo $mList['time'];?></span></div>
                            
                            <div id="message-content"> <?php echo $mList['last_message'];?></div>
                            <div id="span-seen"> <?php echo $mList['seen'];?></div>
                        </a>
                   </li>
                <?php
                    }
                  }
                }
                ?>
                        </ul>
                    </div>
                </div>

            </div>
            <!-- <img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" width="15" /></span> -->
            <?php if($to != ""):?>
            <div class="col-md-9" >
                <div id="chat-container" >
                        <div id="chat-box">
                        <div class="chat-box-header">
                            
                            <span class="user-status is-online"></span>
                            <span class="display-name">
                                <?= ucfirst($to->first_name).' '.ucfirst($to->last_name) ?>
                            </span>
                            <small></small>
                        </div>

                        <div class="chat-container">
                            <div class="chat-content">
                                <ul class="chat-box-body"></ul>
                            </div>
                            <div class="chat-textarea input-section">
                                <input type="hidden" id="to" name="to" value="<?php if($to != ''){echo $to->id;}?>" />
                               <input type="text" id="input-message" name="input-message" placeholder="Write Messages...">
                                <button class="message-send">Send</button>
                            </div>
                        </div>
                        </div>
                    </div>
               <!--  <div class="row">
                    <div class="col-sm-7 input-section">
                        
                    </div>
                    <div class="col-sm-5">
                        
                    </div>
                </div> -->
            </div>
        <?php endif;?>
        </div>