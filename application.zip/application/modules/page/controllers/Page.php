<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Page extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('page_model');
        $this->load->model('branches/Branches_model');
        $this->load->model('livestocks/livestock_model');
        $this->load->module('listing/listing');	
		$this->load->module('user/user');	
    }

	public function index($page=''){
	    
		if($page === ''){
			$a_data = array(
				's_navcurrent'	=> 'home',
				'pagename'		=> 'Home'
			);
			$a_data['rand1'] = $this->generateRandomString(42);
			$a_data['rand2'] = $this->generateRandomString(28);

			$this->pg_display('main',$a_data);
		}else{
			redirect($page);
		}
	}

	public function about(){
		$a_data = array(
			's_navcurrent'	=> 'about',
			'pagename'		=> 'About'
		);
		$this->pg_display('about',$a_data);
	}

	public function listings(){
		$a_data = array();
		$arr_listing = array();
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		); 
		$a_data['rand1'] = $this->generateRandomString(8);
		$a_data['rand2'] = $this->generateRandomString(8);
	

		if(isset($_GET['search'])){
			$res = $this->listing->getListings();
			foreach ($res as $key => $val) {
			$arr = array(
				'id_list'=>$val->id_list.'||'.$val->com_name.'||'.$val->description.'||'.$val->location.'||'.$val->livestock.'||'.$val->media
				
			);
			$result = preg_replace('/[^a-zA-Z0-9]/',' ', $_GET['search']);
			$exp = explode(' ', $result);
			
					$matches  = preg_grep ('/'.$result.'/i', $arr);
					if($matches != null){
						$match_explode = explode('||', $matches['id_list']);
							$arr1 = array('id_list'=>$match_explode[0]);
							
							array_push($arr_listing, $arr1);
					}

		  }

		$a_data['search_result'] = $arr_listing;
		$a_data['listings'] = '';
		}
		else{
		  	$a_data['listings'] = $this->branches_model->getBranchesListings();
		  	$a_data['search_result'] = '';
		 }
			
		$a_data['u_info'] = ''; 
		$this->pg_display('listings',$a_data);
	}

	public function listing($lst_id){ 
		$from = $this->session->userdata('user_info')->id;
		$arr = explode('z', $lst_id);
		$id = $arr[1];
		$list_id=$id;
		$a_data['rand1'] = $this->generateRandomString(42);
		$a_data['rand2'] = $this->generateRandomString(28);
		if(!$this->session->userdata('user_info')){
			redirect('opps');
		}
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		);
		
		$supp = array('supp_id' => $id);
		$a_data['listing'] = $this->branches_model->getBranch($supp);

		$a_data['livestocks'] = $this->livestocks->getLivestocks($supp);
		$location = unserialize($a_data['listing']->supp_address);

		$arr = array('user_id'=>$from, 'supp_id'=>$list_id);
		$result = $this->listing->getListedList($arr);
		if($result){
			$a_data['string'] = '<button type="button" class="button fullwidth margin-top-25">Listed!</button>';
		}else{$a_data['string'] = '<button type="button" id="'.$list_id.'" class="addToMyList button fullwidth margin-top-25">Add to MyList</button>';}
		$a_data['u_info'] = $this->UserModel->getUserInfoBySupplier($list_id); 
		// if($a_data['listing'] == '' ){
		// 	show_404();
		// }
		// ---- MAP PART --- //
		
		$this->load->library('googlemap_api');
		
			$complate_add = $location['address'].", ".$location['city'].", ".$location['state']['name'];
			$config['center'] = $complate_add;
			$config['zoom'] = 15;
			$this->googlemap_api->initialize($config);

			$marker = array();
			$marker['position'] = $complate_add;
			$this->googlemap_api->add_marker($marker);
			
			$a_data['maps'] = $this->googlemap_api->create_map();
		
			$a_data['connection'] = $this->googlemap_api->connection();
		

		$this->pg_display('property-list',$a_data);
		
	}
	public function addToMyList(){
		$arr_result = array();
		$user_id = $this->session->userdata('user_info')->id;
		$supp_id = $this->input->post('supp_id');
		$arr = array('user_id'=>$user_id, 'supp_id'=>$supp_id);
		$result = $this->listing->addToMyList($arr);
		$response = array('status'=>true, 'msg'=>'Successfully added!');
		
		//add the header here
			header('Content-Type: application/json');
			echo json_encode( $response );
	}
	public function justifyMyList(){
		$arr = array('user_id'=>$user_id, 'supp_id'=>$supp_id);
		$result = $this->listing->getListedList($arr);
		if($result == true){
			$response = array('status'=>true);
		}
		else{
			$response = array('status'=>false);
		}
		//add the header here
			header('Content-Type: application/json');
			echo json_encode( $response );
	}
	public function pricing($data = ""){
		$a_data = array(
			's_navcurrent'	=> 'pricing',
			'pagename'		=> 'Pricing'
		);
		if($data != ""){
            $findme = array(0=>'zMsCz',1=>'UsrLsT',2=>'Lst');
            $pos = strpos($data, $findme[0]);
            $pos1 = strpos($data, $findme[1]);
            $pos2 = strpos($data, $findme[2]);
			
    			if($pos){
    				$a_data['message'] = "You wish to view your messages ? Please try our free plan or choose the best plan. thanks!";
    			}
    			else if($pos1){
    				$a_data['message'] = "You wish to manage your Listings ? Please try our free plan or choose the best plan. thanks!";
    			}
    			else if($pos2){
    				$a_data['message'] = "You wish to make listings? Please try our free plan or choose the best plan. thanks!";
    			}
    			else{show_404();}
			
		}
		else{
			$a_data['message']	= "";
		}

		$a_data['free'] 	= $this->generateRandomString(10)."z3z".$this->generateRandomString(10);
		$a_data['basic'] 	= $this->generateRandomString(10)."z1z".$this->generateRandomString(10);
		$a_data['full'] 	= $this->generateRandomString(10)."z2z".$this->generateRandomString(10);
		$done_free = $this->user->done_FreePlan();
		if($done_free == true){
			$a_data['done_free'] = true;
		}
		else{$a_data['done_free'] = false;}
		$this->pg_display('pricing',$a_data);
	}
	
	public function contact(){
		$a_data = array(
			's_navcurrent'	=> 'contact',
			'pagename'		=> 'Contact'
		);
		$this->pg_display('contactpage',$a_data);
	}
	public function terms_conditions(){
		$a_data = array(
			's_navcurrent'	=> 'terms-conditions',
			'pagename'		=> 'Terms and Conditions'
		);
		$this->pg_display('terms-conditions',$a_data);
	}

	public function signup(){
		$a_data = array(
			's_navcurrent'	=> 'signup',
			'pagename'		=> 'Register'
		);
		$this->pg_display('signup',$a_data);
	}
	public function signin(){
		$a_data = array(
			's_navcurrent'	=> 'signin',
			'pagename'		=> 'Login'
		);
		$this->pg_display('signin',$a_data);
	}
}

