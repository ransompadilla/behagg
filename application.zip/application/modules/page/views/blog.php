<section class="container">
	<div class="row text-center">
		<h1><?php echo $pagename?></h1>
		<p class="notification success">Email Account Successfully Verified. <br /> Please click the link below to login your account.<br /> <a href="<?php echo site_url();?>">AussieFlatmates.Com</a></p>
	</div>	
</section>
	



			