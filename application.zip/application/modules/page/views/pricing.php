<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>



<div class="container">

<!-- Row / Start -->
<div class="row">
	<?php
		if($message != ""):
	 ?>
	 <div class="notification success closeable">
		<strong>Hi <?php echo ucfirst($this->session->userdata('user_info')->first_name);?>!</strong> <?php echo $message;?>
		<a class="close"></a>
	 </div>
	
	<?php endif; ?>
<hr>
	<div style="background:tomato; margin-left:30%; margin-right:30%; padding:10px; color:#FFF; text-align:center;"><h4 style="color:#fff"> 30 day Guarantee*</h4>
		Find a room or flatmate in 30 days 
		If not, we will give u another premium
		memberships for another 30 days free
	</div>

	<div class="col-md-12">
		<div class="pricing-container margin-top-30">

		<!-- Plan #1 -->
		<?php if($done_free == true):?>
			<div class="plan">

				<div class="plan-price" style="min-height:224px;">
					<h3>Free Account</h3>
					<span class="value"></span>
					<span class="period">Free of charge one standard listing active for 30 days</span>
				</div>

				<div class="plan-features" style="min-height:374px;">
					<ul>
						<li>Create listings</li>
						<li>30 Days Availability</li>
						<li>View all listings</li>
						<li>Send messages to Anyone</li>
					</ul>
				<button onClick="return confirm('You can no longer use free plan, please use our other plan. Thanks!');" class="button border" style="margin-top:37%;">Get Started</button>
				</div>

			</div>
		<?php else: ?>
			<div class="plan">

				<div class="plan-price" style="min-height:224px;">
					<h3>Free Account</h3>
					<span class="value"></span>
					<span class="period">Free of charge one standard listing active for 30 days</span>
				</div>

				<div class="plan-features" style="min-height:374px;">
					<ul>
						<li>Create listings</li>
						<li>30 Days Availability</li>
						<li>View all listings</li>
						<li>Send messages to Anyone</li>
					</ul>
				<a class="button border" href="<?php echo site_url('plan/pay/'.$free);?>" style="margin-top:37%;">Get Started</a>
				</div>

			</div>
		<?php endif; ?>
			<!-- Plan #3 -->         
			<div class="plan featured" style="min-height:600px;">

				<div class="listing-badges">
					<span class="featured">Featured</span>
				</div>

				<div class="plan-price">
					<h3>Basic Plan</h3>
					<span class="value"> $20 for 15 days </span>
					<span class="period">One time fee for one listing</span>
				</div>
				<div class="plan-features">
					<ul>
						<li>Create listings</li>
						<li>Browse all listings</li>
						<li>Send messages to anyone</li>
						<li>Receive messages from featured members only</li>
						<li>Can Upload Videos</li>
						<li>listing will be featured on front page slider</li>
						<li>Mobile number access**</li>
						<li>Social media content access**</li>
					</ul>
					<a href="<?php echo site_url('plan/pay/'.$basic);?>" class="button">Get Started </a>

				</div>
			</div>

			<!-- Plan #3 -->
			<div class="plan featured" style="min-height:600px;">
									 <div class="listing-badges">
					<span class="featured">Featured</span>
				</div>
				<div class="plan-price">
					<h3>Full Plan</h3>
					<span class="value">$30 for 30 days </span>
					<span class="period" style="color:#fff !important;">One time fee for one listing</span>
				</div>

				<div class="plan-features">
					<ul>
						<li>Create listings</li>
						<li>Browse all listings</li>
						<li>Send messages to anyone</li>
						<li>Receive messages from featured members only</li>
						<li>Can Upload Videos</li>
						<li>listing will be featured on front page slider</li>
						<li>Mobile number access**</li>
						<li>Social media content access**</li>
					</ul>
					<a href="<?php echo site_url('plan/pay/'.$full);?>" class="button">Get Started </a>
				</div>
			</div>

		</div>
	</div>
</div>
<!-- Row / End -->
<div style="padding:20px 10px;">
*Pls note that this Guarantee is for one active 
Listings only.<br>
** Access to mobile numbers and social content is not made available by all listing owners
</div>
</div>




			