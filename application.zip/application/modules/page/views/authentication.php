<section class="container">
	<div class="row text-center">
		<h1><?php echo $pagename?></h1>
		<p class="notification success">Email Account Successfully Verified. </p>
	</div>	
</section>
	



			