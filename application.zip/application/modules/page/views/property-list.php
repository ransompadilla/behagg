<!-- Content
================================================== -->




<div class="container">
	<div class="row sticky-wrapper">


		<div class="col-lg-8 col-md-8 padding-right-30">
<?php
if($listing){
	$loc = unserialize($listing->supp_address);
	$abbrev = $loc['state']['abbrev'];
	$name = $loc['state']['name'];
?>
			<!-- Titlebar -->
			<div id="titlebar" class="listing-titlebar">
				<div class="listing-titlebar-title">
					<h2><?php echo $listing->supp_name;?></h2>
					<span>
						<a href="#listing-location" class="listing-address">
							<i class="fa fa-map-marker"></i>
							<?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")";?>
						</a>
					</span>
					<div class="star-rating" data-rating="5" style="display:none">
						<div class="rating-counter"><a href="#listing-reviews">(31 reviews)</a></div>
					</div>
				</div>
			</div>

			<!-- Listing Nav -->
			<div id="listing-nav" class="listing-nav-container" style="display:none">
				<ul class="listing-nav">
					<li><a href="#listing-overview" class="active">Overview</a></li>
					<li><a href="#listing-pricing-list">Pricing</a></li>
					<li><a href="#listing-location">Location</a></li>
					<li><a href="#listing-reviews">Reviews</a></li>
					<li><a href="#add-review">Add Review</a></li>
				</ul>
			</div>
			
			<!-- Overview -->
			<div id="listing-overview" class="listing-section">
				<!-- Categories Carousel -->
				<div class="fullwidth-carousel-container margin-top-25">
						<!-- Item -->
					<?php 
					$media = unserialize($listing->media);
					if(array_key_exists('images',$media) && $media['images'] != ''){
					?>

					<div class="fullwidth-slick-carousel category-carousel">

						<?php for($i=0;$i<count($media['images']);$i++){
						?>
							<div class="fw-carousel-item">
								<div class="category-box-container">
									<a href="#" class="category-box" data-background-image="<?php echo site_url('uploads/listing/'.$media['images'][$i]); ?>" >

									<div class="category-box-content">
									</div>
										<!-- <span class="category-box-btn">Browse</span> -->
									</a>
								</div>
							</div>
						<?php 
							}?>
							
					</div>
					<?php
					}else{ ?>
						<div class="row">
							<div class="col-md-12">No Category Found</div>
						</div>
					
					<?php 
					}
					?>
				</div>
				<br>
				<?php echo $listing->supp_desc;?>
				
				<!-- Livestock -->
				<h3 class="listing-desc-headline">Livestocks</h3>
				
					<?php 
					if($livestocks){
					?>
					<ul>
					<?php
						foreach ($livestocks as $value) { ?>

						<div class="row">
						<div class="col-lg-12">
			                <div class="dashboard-list-box">
			                 	<li >
									<div class="list-box-listing">
									<div class="list-box-listing-img">
									<?php
															
									if($value->prod_img != ''):
										$media = unserialize($value->prod_img);
										if(array_key_exists('images', $media) && $media['images'] != ''):
										$display = $media['images'];
															?>
										<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $value->prod_name ?>">
										<?php 	else: ?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
										<?php
										endif;
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php endif;?>
									</div>
									<div class="list-box-listing-content">
										<div class="inner">
										<h3><?= $value->prod_name; ?></h3>
										<div><?= $value->prod_description; ?></div>
										<span>Price: <?= $value->prod_price ?>/<?= $value->price_per ?></span>				
										<!--div class="star-rating" data-rating="3.5">
										<div class="rating-counter">(12 reviews)</div>
										</div-->
										</div>
									</div>
									</div>
								</li>
									
			                </div>
			            </div>
			        </div>
							<?php	
						}
						?>
					</ul>
					<?php
						}
					?>
			</div>

			

		
			<!-- Location -->
			<div id="listing-location" class="listing-section">
				<h3 class="listing-desc-headline margin-top-60 margin-bottom-30">Location</h3>

				<div id="singleListingMap-container">  
				<?php 
					if($connection == TRUE):
						echo $maps['js'];
						echo $maps['html'];
					else: ?>
					<h3>No Internet Connection, map cant load...</h3>  
				<?php endif;?>

                   
				</div>
			</div>
				
	<?php } ?>
		</div>

		<!-- Sidebar
		================================================== -->
		<?php include 'inc/sidebar.php'; ?>
		<!-- Sidebar / End -->

	</div>
</div>