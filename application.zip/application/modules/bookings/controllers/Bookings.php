<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bookings extends MY_Controller {

	public function __construct(){
        parent::__construct();
        if(!$this->check_login())
			redirect('/');
    }

	public function index(){
		$a_data = array(
			's_navcurrent'	=> 'bookings',
			'pagename'		=> 'Bookings'
		);

		$this->dash_display('bookings',$a_data);
	}


}

