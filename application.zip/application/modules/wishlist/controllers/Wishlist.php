<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Wishlist extends MY_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('wishlist_model');
	}

	public function addToWishList(){
		$data = $this->input->post('data');
		$arr = array(
				'prod_id'	=>$data[0],
				'user_id'	=>$data[1],
				'supp_id'	=>$data[2],
				'qty'		=>$data[3]
			);
		
		$result = $this->wishlist_model->addToWishList($arr);
		if($result == true) {
			$wish = array('prod_id'=>$data[0], 'user_id'=>$data[1], 'supp_id'=>$data[2]);
			$wish_count = $this->wishlist_model->getWishCountByProduct($wish);

			$a_wish = array('user_id'=>$data[1], 'supp_id'=>$data[2]);
			$a_wish_count = $this->wishlist_model->getWishCountAllProduct($a_wish);
			$response = array(
						'a_wish_count'=> ($a_wish_count->qty != '') ? 
									 '<div id="showMyCart" style="margin-top: 10px;">
	            						<a href="#myCart'.$data[2].'" data-toggle="modal" class="button gray"><i class="sl sl-icon-list"></i> My Cart ( '.$a_wish_count->qty.' )</a>
	            					  </div>' : 
	            					  '<div id="showMyCart" style="display:none;"> </div>',
						'wish_count' => 'wish ( <span><h5>'.$wish_count->qty.'</h5></span> )',
						'prod_id'	 => $data[0],
						'supp_id'	 => $data[2],
						'p_count'	 => $wish_count->p_count,
						'status'	 => true
						);
		}
		else{$response = array('a_wish_count'	=>'', 
							   'wish_count'		=>'',
							   'prod_id'		=>'',
							   'status'			=>false
							);
		}
		//add the header here
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	public function viewCartItems($supp_id){
		$user_id = $this->session->userdata('user_info')->id;
		$items_arr = array();
		$items = $this->wishlist_model->viewCartItems($user_id, $supp_id);
		if($items){
			foreach ($items as $item) {
				$arr = array(
					'p_id'		=>$item->prod_id,
					'p_name'	=>$item->prod_name,
					'p_desc'	=>$item->prod_description,
					'p_price'	=>$item->prod_price,
					'p_per'		=>$item->price_per,
					'p_img'		=>$item->prod_img,
					'qty'		=>$item->qty

				);
				array_push($items_arr, $arr);
			}
		}
		return $items_arr;
	}
	public function viewCartItems2(){
		$user_id = $this->session->userdata('user_info')->id;
		$response = array();
		$data = $this->input->post('data');
		$items_arr = array();
		$items = $this->wishlist_model->viewCartItems($user_id, $data['supp_id']);
		if($items){
			foreach ($items as $item) {
				$arr = array(
					'p_id'		=>$item->prod_id,
					'p_name'	=>$item->prod_name,
					'p_desc'	=>$item->prod_description,
					'p_price'	=>$item->prod_price,
					'p_per'		=>$item->price_per,
					'p_img'		=>unserialize($item->prod_img),
					'qty'		=>$item->qty,
					'supp_id'	=>$data['supp_id']

				);
				array_push($items_arr, $arr);
			}
			$response = array('status'=>true, 'items'=>$items_arr);
		}
		else{
			$response = array('status'=>false, 'items'=>'');
		}
		
		//add the header here
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	public function wishlistToOrder(){
		$first = ucfirst(substr($this->session->userdata('user_info')->first_name, 0, 1));
		$last = ucfirst(substr($this->session->userdata('user_info')->last_name, 0, 1));
		$response = array(); $order = array(); $prodlist = array();$total=0;
		$data = $this->input->post('data');
        $date = strtotime($this->getCurrentDateTime());
		$order_num = $first.''.$last.''.$data[0].''.$data[1].'-'.$date;
		$items_count = 0;
		$myOrder = $this->wishlist_model->viewCartItems($data[0], $data[1]);
		if($myOrder){
			$item_count = count($myOrder);
			foreach ($myOrder as $key => $item) {
				$sub_total = ($item->prod_price * $item->qty);
				$total += $sub_total;
				$arr = array(
					'prod_id'	=>$item->prod_id,
					'name'		=>$item->prod_name,
					'img'		=>$item->prod_img,
					'qty'		=>$item->qty,
					'price'		=>$item->prod_price,
					'per'		=>$item->price_per,
					'sub_total'	=>$sub_total
				);
				array_push($prodlist, $arr);
			}
			$order = array(
						'order_num'		=>$order_num,
						'product'		=>serialize($prodlist),
						'item_count'	=>$item_count, 
						'total'			=>$total, 
						'user_id'		=>$data[0], 
						'supp_id'		=>$data[1], 
						'order_type'	=>$data[2], 
						'payment_method'=>$data[3]
					);
			$result = $this->wishlist_model->wishlistToOrder($order);
			if($result){
				$wish_list = array('user_id'=>$data[0], 'supp_id'=>$data[1]);
				$this->wishlist_model->removeFromWishlist($wish_list);
				$response = array(
					'status'		=>true,
					'order_num'		=>$order_num,
					'product'		=>serialize($prodlist), 
					'item_count'	=>$item_count, 
					'total'			=>$total, 
					'user_id'		=>$data[0], 
					'supp_id'		=>$data[1], 
					'order_type'	=>$data[2], 
					'payment_method'=>$data[3]
				);
			}
		}
		
		header('Content-Type: application/json');
		echo json_encode($response);	
	}
	public function getWishCountAllProduct($data){
		return $this->wishlist_model->getWishCountAllProduct($data);
	}
	public function getWishCountByProduct($data){
		return $this->wishlist_model->getWishCountByProduct($data);
	}
}
?>