<?php
class wishlist_model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}
	public function addToWishList($data){
        $this->db->insert('wishlist', $data);
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function getWishCountByProduct($data){
        $sql = "SELECT count(prod_id) as p_count, sum(qty) as qty FROM wishlist where prod_id=? and user_id = ? and supp_id=?";
        $query = $this->db->query($sql, $data);
        return ($query->num_rows() > 0) ? $query->row() : false;
    }
    public function getWishCountAllProduct($data){
        $sql = "SELECT sum(qty) as qty FROM wishlist where user_id = ? and supp_id=?";
        $query = $this->db->query($sql, $data);
        return ($query->num_rows() > 0) ? $query->row() : false;
    }
    public function viewCartItems($user_id, $supp_id){
        $this->db->select('*, sum(w.qty) as qty');
        $this->db->from('product p'); 
        $this->db->join('wishlist w', 'w.prod_id=p.prod_id', 'inner');
        $this->db->where('w.user_id', $user_id);
        $this->db->where('w.supp_id', $supp_id);
        $this->db->group_by('w.prod_id');
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result() : false;
    }
    public function removeFromWishlist($data){
        $this->db->delete('wishlist', $data); 
        return $this->db->affected_rows() > 0 ? true : false;
    }
    public function wishlistToOrder($data){
        $this->db->insert('order_detail', $data); 
        return $this->db->affected_rows() > 0 ? true : false;
    }
}