<!DOCTYPE html>
<?php
    echo $head;
?>
<html>
    <body>
        <!-- loader -->
        <div id="loading" style="display:none">
            <img id="loading-image" src="<?php echo site_url('assets/images/spinner.gif') ?>" alt="Loading..." />
        </div>
            
        <div id="wrapper">
            <?php 
            echo $header;  
            
            if($pagename == 'Home'){    
                include 'banner.php';
            }
            
            echo $body; 
            ?>            
        
        <?php echo $footer; ?>
        </div>        
    </body>
</html>
