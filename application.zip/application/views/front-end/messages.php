<!DOCTYPE html>
<?php
    echo $head;
?>
<html>
    <body>
        <!-- loader -->
        <div id="loading" style="display:none">
            <img id="loading-image" src="<?php echo site_url('assets/images/spinner.gif') ?>" alt="Loading..." />
        </div>
            
        <div id="wrapper">
   

            <?php 
           	 echo $body; 
            ?>            
        
        </div> 
<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chosen.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/slick.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/rangeslider.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/counterup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery.slimscroll.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/au-state.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/statejson.json"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/myscript.js"></script>       
    </body>
</html>
