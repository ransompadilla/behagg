<header id="header-container">
	<!-- Header -->
	<div id="header">
		<div class="container">
			
			<!-- Left Side Content -->
			<div class="left-side">
				
				<!-- Logo -->
				<div id="logo">
					<a href="<?php echo base_url('/'); ?>"><img src="<?php echo site_url('assets/images/logo/livestock-logo.png') ?>" alt="" ></a>
				</div>

				<!-- Mobile Navigation -->
				<div class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</div>


				<?php include 'nav.php'; ?>
				<div class="clearfix"></div>
				<!-- Main Navigation / End -->
				
			</div>
			<!-- Left Side Content / End -->


			<!-- Right Side Content / End -->
			<div class="right-side">
				<div class="header-widget">
					<?php if($this->session->userdata('is_logged') == null && $this->session->userdata('is_logged') == false){ ?>
						<a href="<?php echo site_url('signin'); ?>" class="sign-in">Login</a>
						<a href="<?php echo site_url('signup'); ?>" class="sign-in">Register</a>
						<!--a href="<?php echo site_url('dashboard'); ?>" class="button border with-icon">Add Listing <i class="sl sl-icon-plus"></i></a-->
					<?php }else{ ?>
						<a href="<?php echo site_url('user/dashboard'); ?>" class="sign-in"><i class="sl sl-icon-user"></i> <?php echo ucfirst($this->session->userdata('user_info')->first_name).' '.ucfirst(substr($this->session->userdata('user_info')->last_name, 0,1)).'.'; ?></a>
					<?php } ?>



					
				</div>
			</div>
			<!-- Right Side Content / End -->



		</div>
	</div>
	<!-- Header / End -->

</header>