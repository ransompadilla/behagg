<div class="main-search-container" data-background-image="assets/images/banner-cap.jpg" style='background-image: url("assets/images/main-search-background-01.jpg");'>
	<div class="main-search-inner">

		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>FIND SHARE ACCOMMODATION EASY</h2>
					<h4>Discover the Easy way for Aussie's to find the perfect ROOM to RENT, Apartment or a house to share, with the search tools designed for both locals, student’s and tourists. </h4>
					<form method="GET" action="<?php echo site_url('listings'); ?>">
					<div class="main-search-input">

						<div class="main-search-input-item">
							<input type="text" placeholder="What are you looking for?" name="search" />
						</div>
						<div class="main-search-input-item">
							<select id="au_state" name="state">
								<option value="false">Select Location</option>	
								
							</select>
						</div>

						<div class="main-search-input-item">
							<select  name="category">
								<option value="all">All Categories</option>	
								<?php
								foreach($categories as $val){
									echo "<option value=\"".$rand1.'i'.$val->cat_id.'i'.$rand2."\">".ucfirst($val->cat_name)."</option>";
								}
								?>
							</select>
						</div>

						<button class="button" type="submit">Search</button>
						</form>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>