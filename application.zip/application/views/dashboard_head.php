<head>
<!-- Basic Page Needs
================================================== -->

<title>Livestock</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script>var base_url = '<?php echo base_url() ?>';</script>
<!-- CSS
================================================== -->
<link rel="icon" href="<?php echo base_url();?>assets/images/logo/icon.png" type="image/ico">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" hlref="<?php echo base_url();?>assets/css/colors/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chat.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropzone.min.css">

<!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css"> -->

 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>


</head>
