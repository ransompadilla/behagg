<!-- Copyrights -->
<div class="col-md-12">
    <div class="copyrights">© 2018 Aussie. All Rights Reserved.</div>
</div>

