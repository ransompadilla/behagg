<!DOCTYPE html>
<?php
    echo $head;
?>
<html>
    <body>
        <!-- LOADING-MODAL -->
                    <div id="loading-modal" class="modal fade" role="dialog">
                        <img id="loading-image" src="<?php echo site_url('assets/images/spinner.gif') ?>" alt="Loading..." />
                    </div>
        <div id="wrapper">
            
            <header id="header-container" class="fixed fullwidth dashboard">

            <div style="margin-left: 30%;position: absolute;">
                <?php 
                if($data):
                    $enddate="";$end="";$status="";$str="";
                    $paymentRecord = $data;
                    date_default_timezone_set("Asia/Manila");
                    $now = Date('F j, Y');
                    $date_now = strtotime($now);

                    foreach ($paymentRecord as $payment): 
                        if($payment->status == 1):
                            $strDate = strtotime($payment->payment_date);
                            $start_date = date('F j, Y', $strDate);

                                //
                            for($i=0;$i< $payment->days; $i++){
                                $end = $strDate + ($payment->days * 86400);
                                $enddate = date('F j, Y', $end);
                            }
                            $rem_days = ($end - $date_now) / 86400;
                            $use_days = $payment->days - intval($rem_days);
                            
                            ?>
                            <h5><?=$str?><b><?=$payment->plan_category?>(<?=$payment->days?>D):</b> <?= intval($rem_days)?> Days More &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <b>End Date: </b><?= $enddate?></h5>
            <?php
                        endif;
                    endforeach;
                endif;
            ?>
            </div>
            <?php echo $header; ?>
            <div id="dashboard">
                <?php echo $nav;?>
                <div class="dashboard-content">
                    <?php echo $body;?>
                </div>            
            </div>          
        </div>
<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chosen.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/slick.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/rangeslider.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/counterup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery.slimscroll.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/au-state.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/statejson.json"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/myscript.js"></script>        
    
    </body>
</html>
