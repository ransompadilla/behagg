<!-- Navigation
    ================================================== -->

    <!-- Responsive Navigation Trigger -->
    <a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Dashboard Navigation</a>

    <div class="dashboard-nav">
        <div class="dashboard-nav-inner">

            <?php if($role->role == 2): ?>
              
                <ul data-submenu-title="Main">
                   
                    <li <?php if($s_navcurrent == 'dashboard'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/dashboard'); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>

                    <li <?php if($s_navcurrent == 'messages'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/messages'); ?>"><i class="sl sl-icon-envelope-open"></i> Messages <!-- <span class="nav-tag messages">2</span> --></a></li>
                    <!--li <?php //if($s_navcurrent == 'bookings'){ echo 'class="active"'; } ?> ><a href="<?php //echo base_url('bookings'); ?>"><i class="fa fa-calendar-check-o"></i> Bookings</a></li-->
                    <li <?php if($s_navcurrent == 'order-detail'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/order_detail'); ?>"><i class="sl sl-icon-layers"></i>Order List <!-- <span class="nav-tag green">6</span> --></a></li>

                    <li <?php if($s_navcurrent == 'payment-records'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/payment_records'); ?>"><i class="sl sl-icon-layers"></i>Payment Records <!-- <span class="nav-tag green">6</span> --></a></li>

                </ul>
                <ul data-submenu-title="Delivery">
                    <li <?php if($s_navcurrent == 'add-delivery' || $s_navcurrent == 'delivery-list'){ echo 'class="active"'; } ?> ><a><i class="sl sl-icon-plus"></i>Delivery</a>
                        <ul>                            
                            <li <?php if($s_navcurrent == 'add-delivery'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/add_delivery'); ?>"><i class="sl sl-icon-settings"></i> Add Delivery</a></li>
                            <li <?php if($s_navcurrent == 'delivery-list'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/delivery_list'); ?>"><i class="sl sl-icon-settings"></i>  Delivery Records</a></li>                       
                        </ul>
                    </li>                  
                </ul>
                
                <ul data-submenu-title="Listings">
                    <li <?php if($s_navcurrent == 'add-branch' || $s_navcurrent == 'branch-list' || $s_navcurrent == 'add-product' || $s_navcurrent == 'add-livestock-category'){ echo 'class="active"'; } ?> ><a><i class="sl sl-icon-plus"></i> My List</a>
                        <ul>                            
                            <li <?php if($s_navcurrent == 'add-branch'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/add-branch'); ?>"><i class="sl sl-icon-direction"></i> List a Place </a></li>
                            
                            <li <?php if($s_navcurrent == 'branch-list'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/branch_list'); ?>"><i class="sl sl-icon-layers"></i> My Listings </a></li>
                            
                        </ul>
                    </li>
                </ul>
                 

                <ul>
                    <li <?php if($s_navcurrent == 'payment-records'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/payments'); ?>"><i class="sl sl-icon-layers"></i>Subscription Records <!-- <span class="nav-tag green">6</span> --></a></li>

                    <li <?php if($s_navcurrent == 'reviews'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('reviews'); ?>"><i class="sl sl-icon-star"></i> Reviews</a></li>
                    <li <?php if($s_navcurrent == 'pricing'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('pricing'); ?>"><i class="sl sl-icon-like"></i> Pricing</a></li>
                </ul> 
            
            <?php endif; ?>
            
            <?php if($role->role == 1): ?>
               
                <ul data-submenu-title="Main">
                   
                    <li <?php if($s_navcurrent == 'dashboard'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/dashboard'); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>

                    <li <?php if($s_navcurrent == 'my-supplier'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/user-supplier'); ?>"><i class="fa fa-building-o"></i>My Supplier <!-- <span class="nav-tag green">6</span> --></a></li>
                    <!-- <li <?php //if($s_navcurrent == 'bookings'){ echo 'class="active"'; } ?> ><a href="<?php //echo base_url('bookings'); ?>"><i class="fa fa-calendar-check-o"></i> Wish List</a></li> -->
                    <li <?php if($s_navcurrent == 'my-orderedlist'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/my-orderedlist'); ?>"><i class="sl sl-icon-layers"></i>My OrderedList <!-- <span class="nav-tag green">6</span> --></a></li>

                    <li <?php if($s_navcurrent == 'payment-records'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/payment_records'); ?>"><i class="sl sl-icon-layers"></i>Payment Records <!-- <span class="nav-tag green">6</span> --></a></li>

                </ul>
            <?php endif; ?>

            <?php // ------------ADMIN NAV ------------- //
            if($role->role == 0): ?>
                <ul data-submenu-title="Main">
                    <li <?php if($s_navcurrent == 'dashboard'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('usexr/dashboard'); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>
                    <li <?php if($s_navcurrent == 'messages'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/messages'); ?>"><i class="sl sl-icon-envelope-open"></i> Messages <!-- <span class="nav-tag messages">2</span> --></a></li>
                    <!--li <?php //if($s_navcurrent == 'bookings'){ echo 'class="active"'; } ?> ><a href="<?php //echo base_url('bookings'); ?>"><i class="fa fa-calendar-check-o"></i> Bookings</a></li-->
                </ul>

                <ul data-submenu-title="Listings">
                    <li <?php if($s_navcurrent == 'user-listing'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/listings'); ?>"><i class="sl sl-icon-layers"></i>Listings <!-- <span class="nav-tag green">6</span> --></a>    
                    </li>
                    <li <?php if($s_navcurrent == 'reviews'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('reviews'); ?>"><i class="sl sl-icon-star"></i> Reviews</a></li>
                </ul> 

                <ul data-submenu-title="Users">
                    <li <?php if($s_navcurrent == 'add-user'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/add-user'); ?>"><i class="sl sl-icon-plus"></i> Add User</a></li>
                    <li <?php if($s_navcurrent == 'user-active-users'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/active-users'); ?>"><i class="sl sl-icon-user"></i>Active Users <!-- <span class="nav-tag green">6</span> --></a>    
                    </li>
                    <li <?php if($s_navcurrent == 'Inactive'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/inactive-users'); ?>"><i class="sl sl-icon-user"></i> Inactive Users</a></li>
                </ul> 
            <?php endif; ?>
            
        </div>
    </div>
    <!-- Navigation / End -->